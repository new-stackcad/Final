"""
agents/
=======
LangGraph-based Ride Optimisation Agent.

Package structure
-----------------
agent_state.py      RideOptState — shared state flowing through graph
geometry_checks.py  Config-level feasibility checks (Tool 3 preflight)
tools.py            Tools 1-7 — wrap existing backend modules
nodes.py            LangGraph nodes + routing functions
ride_opt_agent.py   Graph assembly + run_ride_opt_agent() entry point

External entry point
--------------------
    from agents.ride_opt_agent import run_ride_opt_agent
"""

from agents.ride_opt_agent import run_ride_opt_agent

__all__ = ["run_ride_opt_agent"]
