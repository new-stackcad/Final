"""
nodes.py
========
LangGraph graph nodes for the Ride Optimisation Agent.

Each node:
  1. Updates state.current_node
  2. Calls one or more tools
  3. Records its routing decision in state.decisions
  4. Returns the updated state

Routing functions (conditional edges) sit at the bottom.
They read state and return the name of the next node.

Node map
--------
  ingest_code   → ingest_data  |  END (parse/validate failed)
  ingest_data   → preflight    |  END (CSV load failed)
  preflight     → optimise     |  preflight (retry once) | END (hard fail)
  optimise      → postprocess  |  END (optimiser crashed)
  postprocess   → END

AWS / LLM nodes are stubbed out and commented.
Uncomment and wire in when AWS credentials are available.
"""

from __future__ import annotations
import os
from typing import Literal

from agents.agent_state import RideOptState
from agents.tools import (
    tool_code_ingestion,
    tool_data_ingestion,
    tool_preflight,
    tool_optimiser,
    tool_post_processor,
)

# ---------------------------------------------------------------------------
# Optional AWS / LLM imports — commented out until credentials available
# ---------------------------------------------------------------------------
# from langchain_aws import ChatBedrock
# from langchain_core.messages import HumanMessage
#
# def _get_llm():
#     return ChatBedrock(
#         model_id="anthropic.claude-sonnet-4-5",
#         region_name=os.environ.get("AWS_DEFAULT_REGION", "us-east-1"),
#     )


# ===========================================================================
# NODE 1 — ingest_code
# ===========================================================================
def node_ingest_code(state: RideOptState) -> RideOptState:
    state.current_node = "ingest_code"
    state = tool_code_ingestion(state)

    if state.model_valid:
        state.decide(
            "ingest_code", "→ ingest_data",
            f"Model parsed OK — n_states={state.user_model.n_states}"
        )
        state.status = "running"
    else:
        state.decide(
            "ingest_code", "→ END",
            f"Validation failed: {'; '.join(state.model_errors)}"
        )
        state.status = "failed"
        state.error  = "\n".join(state.model_errors)

    return state


# ===========================================================================
# NODE 2 — ingest_data
# ===========================================================================
def node_ingest_data(state: RideOptState) -> RideOptState:
    state.current_node = "ingest_data"
    state = tool_data_ingestion(state)

    if state.signals_loaded:
        state.decide(
            "ingest_data", "→ preflight",
            f"Road signals loaded: {list(state.signals.keys())}"
        )
    else:
        state.decide(
            "ingest_data", "→ END",
            f"CSV load failed: {state.signals_error}"
        )
        state.status = "failed"
        state.error  = state.signals_error

    return state


# ===========================================================================
# NODE 3 — preflight
# ===========================================================================
def node_preflight(state: RideOptState) -> RideOptState:
    state.current_node = "preflight"
    state = tool_preflight(state)
    pf    = state.preflight

    if pf.passed:
        state.decide(
            "preflight", "→ optimise",
            f"All checks passed | est total ≈ {pf.est_total_seconds:.0f}s"
        )

    elif not pf.geometry_ok and state.retry_count == 0:
        # Geometry violations but haven't retried yet —
        # log the violations and still proceed with a warning
        # (user may have intentionally set unusual params)
        state.decide(
            "preflight", "→ optimise (with geometry warnings)",
            f"Geometry violations: {pf.violations} — proceeding with warning"
        )
        pf.passed = True  # allow continuation with warning attached

    elif not pf.test_integration_ok and state.retry_count < state.max_retries:
        # Test integration failed — retry once with tighter solver settings
        state.retry_count += 1
        state.log(
            f"  Test integration unstable — tightening solver "
            f"(retry {state.retry_count}/{state.max_retries})"
        )
        # Tighten DT for retry
        state.user_model.cfg["DT"] = float(
            state.user_model.cfg.get("DT", 0.001)
        ) * 0.5
        state.decide(
            "preflight", "→ preflight (retry)",
            f"Tightened DT to {state.user_model.cfg['DT']:.4f} — retrying"
        )

    else:
        state.decide(
            "preflight", "→ END",
            f"Preflight hard fail after {state.retry_count} retries"
        )
        state.status = "failed"
        state.error  = (
            f"Pre-flight failed. "
            f"Geometry OK: {pf.geometry_ok}. "
            f"Integration OK: {pf.test_integration_ok}. "
            f"Violations: {pf.violations}"
        )

    return state


# ===========================================================================
# NODE 4 — optimise
# ===========================================================================
def node_optimise(state: RideOptState) -> RideOptState:
    state.current_node = "optimise"

    def log_cb(msg: str):
        state.log(msg)

    try:
        state = tool_optimiser(state, log_cb=log_cb)

        if state.opt_done and state.opt_result is not None:
            state.decide(
                "optimise", "→ postprocess",
                f"Optimisation complete | "
                f"evals={state.opt_result.n_evals} | "
                f"pareto_size={len(state.opt_result.df_pareto)}"
            )
        else:
            raise RuntimeError("Optimiser returned no result")

    except Exception as e:
        state.decide(
            "optimise", "→ END",
            f"Optimiser crashed: {e}"
        )
        state.status = "failed"
        state.error  = str(e)

    return state


# ===========================================================================
# NODE 5 — postprocess
# ===========================================================================
def node_postprocess(state: RideOptState) -> RideOptState:
    state.current_node = "postprocess"

    try:
        state = tool_post_processor(state)
        state.status = "done"
        state.decide(
            "postprocess", "→ END",
            f"Outputs saved | plots={len(state.plot_files)} | "
            f"status={state.agent_summary.status}"
        )

    except Exception as e:
        state.log(f"  [ERROR] Post-processing failed: {e}")
        # Still mark done — optimisation succeeded even if plots failed
        state.status = "done"
        state.error  = f"Post-processing partial failure: {e}"
        state.decide(
            "postprocess", "→ END (partial)",
            f"Plots/serialisation failed but results available: {e}"
        )

    return state


# ===========================================================================
# NODE — stub for AWS LLM diagnosis (uncomment when AWS ready)
# ===========================================================================
# def node_llm_diagnose(state: RideOptState) -> RideOptState:
#     """
#     Called when preflight fails or results are degenerate.
#     Sends error context to Claude via AWS Bedrock and gets a diagnosis.
#     """
#     state.current_node = "llm_diagnose"
#     llm = _get_llm()
#
#     prompt = f"""
#     A vehicle ride optimisation ODE failed during pre-flight testing.
#     ODE code (first 500 chars): {state.ode_code[:500]}
#     Error: {state.error}
#     Config violations: {state.preflight.violations if state.preflight else 'none'}
#
#     Suggest what is likely wrong and what the user should fix.
#     Be specific and brief. Max 3 bullet points.
#     """
#     response = llm.invoke([HumanMessage(content=prompt)])
#     state.log(f"[LLM Diagnosis] {response.content}")
#     return state
#
#
# def node_llm_summarise(state: RideOptState) -> RideOptState:
#     """
#     Called after postprocess. Generates a natural language summary
#     of the Pareto front for the Expert Assistant agent.
#     """
#     state.current_node = "llm_summarise"
#     llm  = _get_llm()
#     summ = state.agent_summary
#
#     prompt = f"""
#     A vehicle suspension optimisation run completed.
#     Mode: {summ.mode}
#     Best RMS: z={summ.best_rms['rms_z']:.4f}  x={summ.best_rms['rms_x']:.4f}
#               y={summ.best_rms['rms_y']:.4f}  total={summ.best_rms['rms_total']:.4f}
#     Best parameters: {summ.best_params}
#     Pareto solutions: {summ.pareto_size}
#     Warnings: {summ.warnings}
#
#     Give a 2-3 sentence engineering interpretation of these results.
#     Focus on what the optimal parameters suggest about the suspension behaviour.
#     """
#     response = llm.invoke([HumanMessage(content=prompt)])
#     state.log(f"[LLM Summary] {response.content}")
#     if state.agent_summary:
#         state.agent_summary.llm_summary = response.content
#     return state


# ===========================================================================
# ROUTING FUNCTIONS (conditional edges)
# ===========================================================================

def route_after_ingest_code(
    state: RideOptState,
) -> Literal["ingest_data", "__end__"]:
    if state.model_valid:
        return "ingest_data"
    return "__end__"


def route_after_ingest_data(
    state: RideOptState,
) -> Literal["preflight", "__end__"]:
    if state.signals_loaded:
        return "preflight"
    return "__end__"


def route_after_preflight(
    state: RideOptState,
) -> Literal["optimise", "preflight", "__end__"]:
    pf = state.preflight
    if pf is None:
        return "__end__"
    if pf.passed:
        return "optimise"
    # Retry once if test integration failed
    if not pf.test_integration_ok and state.retry_count < state.max_retries:
        return "preflight"
    return "__end__"


def route_after_optimise(
    state: RideOptState,
) -> Literal["postprocess", "__end__"]:
    if state.opt_done and state.opt_result is not None:
        return "postprocess"
    return "__end__"
