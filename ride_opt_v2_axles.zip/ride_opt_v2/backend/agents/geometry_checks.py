"""
geometry_checks.py
==================
Generic pre-flight feasibility checks on the user CONFIG dict.
Called by Tool 3 (preflight) before any expensive ODE solve.

Returns a list of violation strings. Empty list = all checks passed.
These checks are config-level — they catch bad numbers before the
solver even starts, saving wasted computation time.
"""

from __future__ import annotations
from typing import Dict, List
import os


def run_geometry_checks(cfg: Dict) -> List[str]:
    """
    Run all feasibility checks on cfg.
    Returns list of violation strings — empty means all passed.
    """
    violations: List[str] = []

    def _check(cond: bool, msg: str):
        if not cond:
            violations.append(msg)

    # ── Masses must be positive ───────────────────────────────────────────
    for key in ("m_s", "m_c"):
        if key in cfg:
            _check(cfg[key] > 0, f"{key} must be > 0, got {cfg[key]}")

    # ── Inertia tensor positive-definiteness ──────────────────────────────
    if all(k in cfg for k in ("I_sxx", "I_syy", "I_sxy")):
        det = cfg["I_sxx"] * cfg["I_syy"] - cfg["I_sxy"] ** 2
        _check(det > 0,
               f"Sprung mass inertia tensor not positive-definite "
               f"(I_sxx*I_syy - I_sxy^2 = {det:.3g})")

    # ── Stiffnesses must be positive ──────────────────────────────────────
    stiffness_keys = [k for k in cfg if k.startswith("K_")]
    for key in stiffness_keys:
        _check(cfg[key] > 0, f"{key} must be > 0, got {cfg[key]}")

    # ── Damping must be non-negative ──────────────────────────────────────
    damping_keys = [k for k in cfg if k.startswith("C_")]
    for key in damping_keys:
        _check(cfg[key] >= 0, f"{key} must be >= 0, got {cfg[key]}")

    # ── Damper shape parameters ───────────────────────────────────────────
    if "cs_minus" in cfg:
        _check(cfg["cs_minus"] > 0,
               f"cs_minus must be > 0, got {cfg['cs_minus']}")
    if "asym_ratio" in cfg:
        _check(cfg["asym_ratio"] > 1.0,
               f"asym_ratio must be > 1, got {cfg['asym_ratio']}")
    if "gamma_c" in cfg:
        _check(0 < cfg["gamma_c"] < 1,
               f"gamma_c must be in (0,1), got {cfg['gamma_c']}")
    if "gamma_r" in cfg:
        _check(0 < cfg["gamma_r"] < 1,
               f"gamma_r must be in (0,1), got {cfg['gamma_r']}")

    # ── Track widths positive ─────────────────────────────────────────────
    for key in ("WT1", "WT2", "WT3"):
        if key in cfg:
            _check(cfg[key] > 0, f"{key} must be > 0, got {cfg[key]}")

    # ── Geometry distances positive ───────────────────────────────────────
    for key in ("lf", "L12", "L23", "l_cf", "l_cr", "l_cfcg", "l_crcg"):
        if key in cfg:
            _check(cfg[key] > 0, f"{key} must be > 0, got {cfg[key]}")

    # ── Baumgarte params (only if geometry is being used) ─────────────────
    if "baum_omega" in cfg:
        _check(cfg["baum_omega"] > 0,
               f"baum_omega must be > 0, got {cfg['baum_omega']}")
    if "baum_zeta" in cfg:
        _check(cfg["baum_zeta"] > 0,
               f"baum_zeta must be > 0, got {cfg['baum_zeta']}")

    # ── Simulation time ───────────────────────────────────────────────────
    if "T_END" in cfg and "T_IGNORE" in cfg:
        _check(cfg["T_END"] > cfg["T_IGNORE"],
               f"T_END ({cfg['T_END']}) must be greater than T_IGNORE ({cfg['T_IGNORE']})")

    # ── CSV file existence (only check if paths are set) ──────────────────
    csv_keys = [
        "axlefront_left_csv",  "axlefront_right_csv",
        "axlerear1_left_csv",  "axlerear1_right_csv",
        "axlerear2_left_csv",  "axlerear2_right_csv",
    ]
    for key in csv_keys:
        path = cfg.get(key, "")
        if path:  # only check if a path was actually provided
            _check(os.path.isfile(path),
                   f"CSV not found: {key} → {path}")

    return violations
