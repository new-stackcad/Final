"""
model.py  –  PhysicsLSTM surrogate architecture.

Architecture summary
────────────────────
Road signals [B,T,6]
    └─ CausalCNN encoder  →  [B,T,road_dim=32]
                                     ┐
                                     ├── concat → [B,T,road_dim+param_dim]
                                     ┘
Design params [B,8]
    └─ ParamMLP           →  [B,param_dim=128]
         └─ also initialises LSTM hidden state (h0, c0)

LSTM (2 layers, hidden=256)  →  [B,T,256]
    ├─ StateHead  →  state_pred  [B,T,6]   (z_c th_c ph_c z_s th_s ph_s)
    └─ AccelHead  →  accel_pred  [B,T,3]   (qdd_z_c qdd_th_c qdd_ph_c)
"""

from __future__ import annotations
from typing import Tuple

import torch
import torch.nn as nn

from config import TRAIN_CFG


# ─────────────────────────────────────────────────────────────
# Building blocks
# ─────────────────────────────────────────────────────────────

class CausalCNNEncoder(nn.Module):
    """
    1-D causal (left-padding) CNN.
    Input:  [B, T, in_ch]
    Output: [B, T, out_dim]
    No future timesteps leaking into current output.
    """

    def __init__(self, in_ch: int = 6, out_dim: int = 32,
                 n_layers: int = 3, kernel: int = 7):
        super().__init__()
        ch = [in_ch] + [64] * (n_layers - 1) + [out_dim]
        layers = []
        for i in range(n_layers):
            pad = kernel - 1      # causal left pad
            layers += [
                nn.ConstantPad1d((pad, 0), 0.0),
                nn.Conv1d(ch[i], ch[i + 1], kernel_size=kernel, padding=0),
                nn.GELU(),
                nn.BatchNorm1d(ch[i + 1]),
            ]
        self.net = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, T, C]  →  transpose for Conv1d  →  transpose back
        return self.net(x.transpose(1, 2)).transpose(1, 2)


class ParamMLP(nn.Module):
    """Maps 8 design params → condition vector."""

    def __init__(self, n_params: int = 8,
                 hidden: int = 64, out_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(n_params, hidden), nn.GELU(),
            nn.Linear(hidden, hidden),   nn.GELU(),
            nn.Linear(hidden, out_dim),
        )

    def forward(self, p: torch.Tensor) -> torch.Tensor:
        return self.net(p)


class ResidualHead(nn.Module):
    """Small 2-layer MLP with skip connection for output heads."""

    def __init__(self, in_dim: int, out_dim: int, hidden: int = 128):
        super().__init__()
        self.fc1  = nn.Linear(in_dim, hidden)
        self.act  = nn.GELU()
        self.fc2  = nn.Linear(hidden, out_dim)
        self.skip = nn.Linear(in_dim, out_dim, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.fc2(self.act(self.fc1(x))) + self.skip(x)


# ─────────────────────────────────────────────────────────────
# Main surrogate
# ─────────────────────────────────────────────────────────────

class PhysicsLSTM(nn.Module):
    """
    Parameter-conditioned physics-informed LSTM surrogate.
    """

    def __init__(self,
                 road_dim:    int   = TRAIN_CFG["road_dim"],
                 param_dim:   int   = TRAIN_CFG["param_dim"],
                 lstm_hidden: int   = TRAIN_CFG["lstm_hidden"],
                 lstm_layers: int   = TRAIN_CFG["lstm_layers"],
                 dropout:     float = TRAIN_CFG["dropout"],
                 n_states:    int   = 6,
                 n_accels:    int   = 3):
        super().__init__()

        self.road_enc  = CausalCNNEncoder(in_ch=6, out_dim=road_dim)
        self.param_mlp = ParamMLP(n_params=8, hidden=64, out_dim=param_dim)

        lstm_in = road_dim + param_dim
        self.lstm = nn.LSTM(lstm_in, lstm_hidden, lstm_layers,
                            batch_first=True,
                            dropout=dropout if lstm_layers > 1 else 0.0)

        # Initialise LSTM h0, c0 from param embedding
        self.h0_proj = nn.Linear(param_dim, lstm_hidden * lstm_layers)
        self.c0_proj = nn.Linear(param_dim, lstm_hidden * lstm_layers)

        self.state_head = ResidualHead(lstm_hidden, n_states)
        self.accel_head = ResidualHead(lstm_hidden, n_accels)

        self.lstm_hidden = lstm_hidden
        self.lstm_layers = lstm_layers

        # Weight init
        self._init_weights()

    def _init_weights(self):
        for name, p in self.named_parameters():
            if "weight_ih" in name:
                nn.init.xavier_uniform_(p)
            elif "weight_hh" in name:
                nn.init.orthogonal_(p)
            elif "bias" in name:
                nn.init.zeros_(p)

    def forward(self, road: torch.Tensor,
                param: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        road  : [B, T, 6]   normalised road signals
        param : [B, 8]       normalised parameters
        ──────────────────────────────────────────────
        returns
            state_pred : [B, T, 6]
            accel_pred : [B, T, 3]
        """
        B = road.shape[0]

        # Road features
        road_feat = self.road_enc(road)                          # [B, T, road_dim]

        # Param embedding → broadcast over T
        p_emb = self.param_mlp(param)                           # [B, param_dim]
        p_exp = p_emb.unsqueeze(1).expand(-1, road.shape[1], -1)# [B, T, param_dim]

        # LSTM input  -- .contiguous() required before cuDNN LSTM
        lstm_in = torch.cat([road_feat, p_exp], dim=-1).contiguous()  # [B, T, lstm_in]

        # Initialise hidden states from param embedding
        h0 = (self.h0_proj(p_emb)
              .view(B, self.lstm_layers, self.lstm_hidden)
              .permute(1, 0, 2).contiguous())
        c0 = (self.c0_proj(p_emb)
              .view(B, self.lstm_layers, self.lstm_hidden)
              .permute(1, 0, 2).contiguous())

        lstm_out, _ = self.lstm(lstm_in, (h0, c0))              # [B, T, hidden]

        state_pred = self.state_head(lstm_out)                   # [B, T, 6]
        accel_pred = self.accel_head(lstm_out)                   # [B, T, 3]

        return state_pred, accel_pred

    @property
    def n_params(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


# ─────────────────────────────────────────────────────────────
# Physics-informed loss
# ─────────────────────────────────────────────────────────────

class PhysicsLoss(nn.Module):
    """
    L = λ_s·MSE(state)  +  λ_a·MSE(accel)
      + λ_r·MSE(rms)    +  λ_p·fd_consistency

    fd_consistency: penalises mismatch between finite-difference
    second derivative of predicted state and predicted acceleration.
    This is a soft physics constraint — no full EOM evaluation needed.
    """

    def __init__(self,
                 lambda_state: float = TRAIN_CFG["lambda_state"],
                 lambda_accel: float = TRAIN_CFG["lambda_accel"],
                 lambda_rms:   float = TRAIN_CFG["lambda_rms"],
                 lambda_phys:  float = TRAIN_CFG["lambda_phys"]):
        super().__init__()
        self.ls = lambda_state
        self.la = lambda_accel
        self.lr = lambda_rms
        self.lp = lambda_phys

    def forward(self,
                state_pred: torch.Tensor,   # [B, T, 6]
                accel_pred: torch.Tensor,   # [B, T, 3]
                state_true: torch.Tensor,
                accel_true: torch.Tensor,
                rms_true:   torch.Tensor,   # [B, 1]
                h_seat:     float = 0.6,
                dt:         float = 0.016,  # matches downsample=4 × DT=0.004
                ) -> Tuple[torch.Tensor, dict]:

        mse = nn.functional.mse_loss

        l_state = mse(state_pred, state_true)
        l_accel = mse(accel_pred, accel_true)

        # RMS loss  (operate in normalised space to avoid scale issues)
        # We just compare predicted vs target RMS of the accel signal
        rms_pred = torch.sqrt((accel_pred[..., 0]**2).mean(dim=1, keepdim=True) + 1e-8)
        rms_targ = torch.sqrt((accel_true[..., 0]**2).mean(dim=1, keepdim=True) + 1e-8)
        l_rms = mse(rms_pred, rms_targ)

        # Finite-difference consistency (bounce DOF, index 0)
        l_phys = torch.tensor(0.0, device=state_pred.device)
        if state_pred.shape[1] > 2:
            q_zc   = state_pred[:, :, 0]                     # [B, T]
            fd_acc = (q_zc[:, 2:] - 2*q_zc[:, 1:-1] + q_zc[:, :-2]) / (dt**2)
            l_phys = mse(fd_acc, accel_pred[:, 1:-1, 0])

        total = (self.ls * l_state + self.la * l_accel
                 + self.lr * l_rms   + self.lp * l_phys)

        return total, {
            "loss_total": total.item(),
            "loss_state": l_state.item(),
            "loss_accel": l_accel.item(),
            "loss_rms":   l_rms.item(),
            "loss_phys":  l_phys.item(),
        }
