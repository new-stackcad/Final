"""
plotter.py
==========
All plots generated automatically after every optimisation or ODE run.
No manual steps required.

Public API
----------
generate_all_plots(result, cfg, t_eval, out_dir) -> List[str]
    Writes all PNGs into out_dir/plots/ and returns list of file paths.

generate_time_history(params, cfg, t_eval, label, out_dir) -> str
    Runs one ODE case and saves a 3-row time-history plot.
"""

from __future__ import annotations
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from typing import Dict, List

from data_config import PARAM_KEYS, default_bounds
from solver import run_one_case, compute_seat_rms_axes


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _savefig(fig, path: str, dpi: int = 150):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fig.savefig(path, dpi=dpi, bbox_inches="tight")
    plt.close(fig)
    return path


# ---------------------------------------------------------------------------
# NSGA-II specific plots
# ---------------------------------------------------------------------------
def plot_pareto_2d(df: pd.DataFrame, out_dir: str) -> List[str]:
    """Three 2-D Pareto projections."""
    bounds = {"rms_z": (0, 5), "rms_x": (0, 5), "rms_y": (0, 5)}
    pairs  = [("rms_z", "rms_x"), ("rms_z", "rms_y"), ("rms_x", "rms_y")]
    labels_axis = {
        "rms_z": "RMS_z vertical [m/s²]",
        "rms_x": "RMS_x longitudinal [m/s²]",
        "rms_y": "RMS_y lateral [m/s²]",
    }
    paths = []
    for a, b in pairs:
        fig, ax = plt.subplots(figsize=(6, 5))
        ax.scatter(df[a], df[b], s=60, c="steelblue", edgecolors="k", linewidths=0.5, zorder=5)
        for _, row in df.iterrows():
            ax.annotate(row["label"], (row[a], row[b]),
                        fontsize=7, ha="left", va="bottom",
                        xytext=(3, 3), textcoords="offset points")
        ax.set_xlabel(labels_axis[a]); ax.set_ylabel(labels_axis[b])
        ax.set_title(f"Pareto Front  ({a} vs {b})")
        ax.grid(True, alpha=0.35)
        plt.tight_layout()
        fname = os.path.join(out_dir, "plots", f"pareto_{a}_{b}.png")
        paths.append(_savefig(fig, fname))
    return paths


def plot_pareto_3d(df: pd.DataFrame, out_dir: str) -> str:
    fig = plt.figure(figsize=(8, 6))
    ax  = fig.add_subplot(111, projection="3d")
    sc  = ax.scatter(df["rms_z"], df["rms_x"], df["rms_y"],
                     c=df["rms_total"], cmap="plasma", s=60, edgecolors="k", linewidths=0.4)
    plt.colorbar(sc, ax=ax, label="RMS_total [m/s²]", shrink=0.6)
    for _, row in df.iterrows():
        ax.text(row["rms_z"], row["rms_x"], row["rms_y"], row["label"], fontsize=7)
    ax.set_xlabel("RMS_z [m/s²]"); ax.set_ylabel("RMS_x [m/s²]"); ax.set_zlabel("RMS_y [m/s²]")
    ax.set_title("3-D Pareto Front  (NSGA-II)")
    plt.tight_layout()
    return _savefig(fig, os.path.join(out_dir, "plots", "pareto_3d.png"))


def plot_hypervolume(hv_history: List[float], out_dir: str) -> str:
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(range(1, len(hv_history) + 1), hv_history,
            marker="o", linewidth=2, color="mediumslateblue")
    ax.set_xlabel("Generation"); ax.set_ylabel("Hypervolume indicator")
    ax.set_title("NSGA-II Hypervolume Convergence")
    ax.grid(True, alpha=0.4)
    plt.tight_layout()
    return _savefig(fig, os.path.join(out_dir, "plots", "convergence_hv.png"))


def plot_generation_scatter(eval_log: List[Dict], df_pareto: pd.DataFrame, out_dir: str) -> str:
    valid = [e for e in eval_log if e.get("rms_z", 99) < 90]
    if not valid:
        return ""
    zv = np.array([e["rms_z"] for e in valid])
    xv = np.array([e["rms_x"] for e in valid])
    gv = np.array([e.get("gen", 0) for e in valid])

    fig, ax = plt.subplots(figsize=(7, 5))
    sc = ax.scatter(zv, xv, c=gv, cmap="viridis", s=20, alpha=0.7, edgecolors="none")
    plt.colorbar(sc, ax=ax, label="Generation")
    ax.scatter(df_pareto["rms_z"], df_pareto["rms_x"],
               s=120, marker="*", color="red", zorder=5, label="Final Pareto")
    ax.set_xlabel("RMS_z vertical [m/s²]"); ax.set_ylabel("RMS_x longitudinal [m/s²]")
    ax.set_title("Population Evolution — all generations (z vs x)")
    ax.legend(); ax.grid(True, alpha=0.4)
    plt.tight_layout()
    return _savefig(fig, os.path.join(out_dir, "plots", "generation_scatter.png"))


# ---------------------------------------------------------------------------
# Shared plots (used by both modes)
# ---------------------------------------------------------------------------
def plot_parallel_coordinates(df: pd.DataFrame, bounds: Dict, out_dir: str) -> str:
    norm_df = df.copy()
    for k in PARAM_KEYS:
        if k not in df.columns:
            continue
        lo, hi = bounds[k]
        norm_df[k] = (df[k] - lo) / max(hi - lo, 1e-12)

    n    = len(df)
    cmap = cm.get_cmap("plasma", max(n, 1))
    xs   = list(range(len(PARAM_KEYS)))

    fig, ax = plt.subplots(figsize=(13, 5))
    for i in range(n):
        vals = [norm_df[k].iloc[i] for k in PARAM_KEYS if k in norm_df.columns]
        ax.plot(xs[:len(vals)], vals, color=cmap(i), linewidth=1.4, alpha=0.85,
                label=df["label"].iloc[i])
    ax.set_xticks(xs[:len(PARAM_KEYS)])
    ax.set_xticklabels(PARAM_KEYS, rotation=25, ha="right", fontsize=9)
    ax.set_ylabel("Normalised value in search range [0–1]")
    ax.set_title("Parallel Coordinates — Pareto Parameter Sets")
    ax.axhline(0.05, color="red",    linestyle=":", linewidth=0.8, label="Near lo bound")
    ax.axhline(0.95, color="orange", linestyle=":", linewidth=0.8, label="Near hi bound")
    ax.legend(fontsize=7, loc="upper right", ncol=2)
    ax.grid(True, axis="y", alpha=0.3)
    plt.tight_layout()
    return _savefig(fig, os.path.join(out_dir, "plots", "param_parallel.png"))


def plot_rms_bars(df: pd.DataFrame, out_dir: str) -> str:
    labels = df["label"].tolist()
    x = np.arange(len(labels)); w = 0.25
    fig, ax = plt.subplots(figsize=(max(9, len(labels) * 1.5), 5))
    ax.bar(x - w,  df["rms_z"], w, label="RMS_z (vertical)",     color="steelblue",  edgecolor="k")
    ax.bar(x,      df["rms_x"], w, label="RMS_x (longitudinal)", color="darkorange", edgecolor="k")
    ax.bar(x + w,  df["rms_y"], w, label="RMS_y (lateral)",      color="seagreen",   edgecolor="k")
    ax.set_xticks(x); ax.set_xticklabels(labels, rotation=20, ha="right")
    ax.set_ylabel("RMS acceleration [m/s²]")
    ax.set_title("Per-Axis RMS — Pareto Solutions")
    ax.legend(); ax.grid(True, axis="y", alpha=0.4)
    plt.tight_layout()
    return _savefig(fig, os.path.join(out_dir, "plots", "pareto_rms_bars.png"))


def plot_bayesian_convergence(convergence: List[float], out_dir: str) -> str:
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(range(1, len(convergence) + 1), convergence,
            marker=".", linewidth=1.8, color="coral")
    ax.set_xlabel("Evaluation #"); ax.set_ylabel("Best RMS_total so far [m/s²]")
    ax.set_title("Bayesian Optimisation Convergence")
    ax.grid(True, alpha=0.4)
    plt.tight_layout()
    return _savefig(fig, os.path.join(out_dir, "plots", "convergence_bayesian.png"))


# ---------------------------------------------------------------------------
# Time-history plot
# ---------------------------------------------------------------------------
def generate_time_history(
    params: Dict,
    cfg: Dict,
    t_eval: np.ndarray,
    label: str,
    out_dir: str,
) -> str:
    """Run one ODE solve and save a 3-row seat-acceleration time history."""
    try:
        df  = run_one_case(params, cfg, t_eval)
        rms = compute_seat_rms_axes(df, cfg)
        h   = cfg["hcp"]

        az  = df["qdd_z_c"].values
        ax_ = -h * df["qdd_th_c"].values
        ay  =  h * df["qdd_ph_c"].values
        t   = df["t"].values

        fig, axes = plt.subplots(3, 1, figsize=(11, 8), sharex=True)
        colors = ["steelblue", "darkorange", "seagreen"]
        ylabels = ["z̈ seat [m/s²]", "ẍ seat [m/s²]", "ÿ seat [m/s²]"]
        for ax_obj, sig, col, yl in zip(axes, [az, ax_, ay], colors, ylabels):
            ax_obj.plot(t, sig, linewidth=0.6, color=col)
            ax_obj.set_ylabel(yl); ax_obj.grid(True, alpha=0.35)
        axes[2].set_xlabel("Time [s]")
        fig.suptitle(
            f"{label}  |  z={rms['rms_z']:.4f}  x={rms['rms_x']:.4f}  "
            f"y={rms['rms_y']:.4f}  total={rms['rms_total']:.4f}  [m/s²]",
            fontsize=10,
        )
        plt.tight_layout()
        safe_label = label.replace(" ", "_").replace("/", "-")
        fname = os.path.join(out_dir, "plots", f"seat_accel_{safe_label}.png")
        return _savefig(fig, fname)
    except Exception as e:
        print(f"[WARN] time-history failed for {label}: {e}")
        return ""


# ---------------------------------------------------------------------------
# Master generator — call this from main.py
# ---------------------------------------------------------------------------
def generate_all_plots(
    result,          # OptResult from optimiser.py
    cfg: Dict,
    t_eval: np.ndarray,
    out_dir: str,
) -> List[str]:
    """
    Generate every plot appropriate for the optimisation mode.
    Returns list of PNG file paths that were successfully written.
    """
    os.makedirs(os.path.join(out_dir, "plots"), exist_ok=True)
    paths: List[str] = []
    bounds = default_bounds(cfg)

    df = result.df_pareto

    # ---- shared plots ----
    paths.append(plot_rms_bars(df, out_dir))
    paths.append(plot_parallel_coordinates(df, bounds, out_dir))

    # ---- mode-specific ----
    if result.mode == "nsga2":
        paths += plot_pareto_2d(df, out_dir)
        paths.append(plot_pareto_3d(df, out_dir))
        if result.hv_history:
            paths.append(plot_hypervolume(result.hv_history, out_dir))
        if result.eval_log:
            paths.append(plot_generation_scatter(result.eval_log, df, out_dir))

    elif result.mode == "bayesian":
        if result.convergence:
            paths.append(plot_bayesian_convergence(result.convergence, out_dir))

    # ---- time-history for key solutions ----
    key_labels = {"Best_total", "Best_vertical", "Best_longitudinal",
                  "Best_lateral", "Best_total"}
    done: set = set()
    for _, row in df.iterrows():
        if row["label"] in key_labels and row["label"] not in done:
            params = {k: row[k] for k in PARAM_KEYS if k in row}
            p = generate_time_history(params, cfg, t_eval, row["label"], out_dir)
            if p:
                paths.append(p)
            done.add(row["label"])

    return [p for p in paths if p]
