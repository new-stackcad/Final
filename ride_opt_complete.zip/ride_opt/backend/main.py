"""
main.py
=======
FastAPI backend for the Ride Optimisation Web App.

Endpoints
---------
POST /upload-csv          Upload one axle CSV file
POST /run                 Start ODE solve + optimisation (background task)
GET  /status/{job_id}     Poll job status
GET  /stream/{job_id}     Server-Sent Events log stream
GET  /results/{job_id}    Get final result JSON
GET  /plots/{job_id}      List generated plot filenames
GET  /plot/{job_id}/{fn}  Serve a specific plot PNG
GET  /download/{job_id}   Download pareto_front.csv
POST /validate-surrogate  Validate uploaded surrogate files

Run with:
    uvicorn main:app --reload --port 8000
"""

from __future__ import annotations
import asyncio
import copy
import json
import os
import queue
import threading
import time
import uuid
import zipfile
import io
from pathlib import Path
from typing import Dict, List, Optional, Any

import numpy as np
import pandas as pd

from fastapi import (
    FastAPI, BackgroundTasks, UploadFile, File, Form,
    HTTPException, Request,
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import (
    FileResponse, JSONResponse, StreamingResponse,
)
from pydantic import BaseModel

# ---- local modules ----
from data_config import DEFAULT_CFG, PARAM_KEYS, default_bounds
from geometry   import check_geometric_feasibility
from solver     import run_one_case, compute_seat_rms_axes
from optimiser  import run_optimisation
from plotter    import generate_all_plots, generate_time_history
from surrogate_check import validate_surrogate, surrogate_params_json_template

# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------
app = FastAPI(title="Ride Optimisation API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR  = Path("uploads")
RESULTS_DIR = Path("results")
UPLOAD_DIR.mkdir(exist_ok=True)
RESULTS_DIR.mkdir(exist_ok=True)

# In-memory job store
_jobs: Dict[str, Dict] = {}   # job_id -> state dict
_log_queues: Dict[str, queue.Queue] = {}


# ---------------------------------------------------------------------------
# Request / response schemas
# ---------------------------------------------------------------------------
class RunRequest(BaseModel):
    # Optimisation mode
    mode: str = "nsga2"          # "nsga2" | "bayesian"

    # NSGA-II settings
    pop_size: int  = 10
    n_gen:    int  = 5

    # Bayesian settings
    n_calls:   int = 50
    n_initial: int = 10

    # Simulation time
    T_END:    float = 466.945
    T_IGNORE: float = 0.5

    # Vehicle config overrides (any key from DEFAULT_CFG)
    cfg_overrides: Dict[str, Any] = {}

    # CSV file paths on server (returned by /upload-csv)
    csv_paths: Dict[str, str] = {}


# ---------------------------------------------------------------------------
# Helper: build config from request
# ---------------------------------------------------------------------------
def _build_cfg(req: RunRequest) -> Dict:
    cfg = copy.deepcopy(DEFAULT_CFG)
    cfg.update(req.cfg_overrides)
    cfg["T_END"]    = req.T_END
    cfg["T_IGNORE"] = req.T_IGNORE

    # Map uploaded CSV paths
    key_map = {
        "axlefront_left_csv":  "fa_lh",
        "axlefront_right_csv": "fa_rh",
        "axlerear1_left_csv":  "ra1_lh",
        "axlerear1_right_csv": "ra1_rh",
        "axlerear2_left_csv":  "ra2_lh",
        "axlerear2_right_csv": "ra2_rh",
    }
    for cfg_key, short_key in key_map.items():
        if short_key in req.csv_paths:
            cfg[cfg_key] = req.csv_paths[short_key]

    return cfg


# ---------------------------------------------------------------------------
# Background job worker
# ---------------------------------------------------------------------------
def _run_job(job_id: str, req: RunRequest):
    job  = _jobs[job_id]
    logq = _log_queues[job_id]

    def log(msg: str):
        logq.put(msg)
        job["logs"].append(msg)

    try:
        job["status"] = "running"
        log(f"Job {job_id} started | mode={req.mode}")

        cfg = _build_cfg(req)

        # ---- geometry check ----
        violations = check_geometric_feasibility(cfg)
        if violations:
            for v in violations:
                log(f"[CONFIG ERROR] {v}")
            job["status"] = "failed"
            job["error"]  = "; ".join(violations)
            logq.put("__DONE__")
            return

        log("Geometry checks passed.")

        # ---- time array ----
        dt     = cfg.get("DT", 0.001)
        t_eval = np.arange(0.0, req.T_END + dt, dt)
        log(f"t_eval: {len(t_eval)} points, dt={dt}, T_END={req.T_END}")

        opt_settings = {
            "pop_size":  req.pop_size,
            "n_gen":     req.n_gen,
            "n_calls":   req.n_calls,
            "n_initial": req.n_initial,
        }

        result = run_optimisation(
            cfg=cfg,
            t_eval=t_eval,
            mode=req.mode,
            opt_settings=opt_settings,
            log_cb=log,
        )

        # ---- save outputs ----
        out_dir = str(RESULTS_DIR / job_id)
        os.makedirs(out_dir, exist_ok=True)

        csv_path  = os.path.join(out_dir, "pareto_front.csv")
        json_path = os.path.join(out_dir, "run_results.json")
        result.df_pareto.to_csv(csv_path, index=False)

        run_data = {
            "mode":         result.mode,
            "n_evals":      result.n_evals,
            "wall_seconds": result.wall_seconds,
            "pareto":       result.df_pareto.to_dict(orient="records"),
            "hv_history":   result.hv_history,
            "convergence":  result.convergence,
            "eval_log":     result.eval_log[:500],  # cap at 500 for JSON size
        }
        with open(json_path, "w") as f:
            json.dump(run_data, f, indent=2, default=str)

        log("Generating plots …")
        plot_paths = generate_all_plots(result, cfg, t_eval, out_dir)
        log(f"Plots saved: {len(plot_paths)} files")

        job["status"]     = "done"
        job["result"]     = run_data
        job["plot_files"] = [os.path.basename(p) for p in plot_paths if p]
        job["out_dir"]    = out_dir

        log(f"Job complete | evals={result.n_evals} | wall={result.wall_seconds:.1f}s")

    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        log(f"[ERROR] {e}\n{tb}")
        job["status"] = "failed"
        job["error"]  = str(e)

    finally:
        logq.put("__DONE__")


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.get("/")
def root():
    return {"message": "Ride Optimisation API is running."}


@app.post("/upload-csv")
async def upload_csv(
    file: UploadFile = File(...),
    key:  str        = Form(...),   # one of: fa_lh, fa_rh, ra1_lh, ra1_rh, ra2_lh, ra2_rh
):
    """Upload one axle displacement CSV. Returns server path."""
    safe_name = f"{key}_{uuid.uuid4().hex[:8]}_{file.filename}"
    dest      = UPLOAD_DIR / safe_name
    content   = await file.read()
    with open(dest, "wb") as f:
        f.write(content)
    return {"key": key, "server_path": str(dest), "filename": file.filename}


@app.post("/run")
async def start_run(req: RunRequest, background_tasks: BackgroundTasks):
    """Start an optimisation job. Returns job_id immediately."""
    job_id = uuid.uuid4().hex[:12]
    _jobs[job_id] = {
        "status":     "queued",
        "mode":       req.mode,
        "logs":       [],
        "result":     None,
        "plot_files": [],
        "error":      None,
        "created_at": time.time(),
    }
    _log_queues[job_id] = queue.Queue()

    t = threading.Thread(target=_run_job, args=(job_id, req), daemon=True)
    t.start()

    return {"job_id": job_id, "status": "queued"}


@app.get("/status/{job_id}")
def get_status(job_id: str):
    if job_id not in _jobs:
        raise HTTPException(404, "Job not found")
    j = _jobs[job_id]
    return {
        "job_id":     job_id,
        "status":     j["status"],
        "mode":       j["mode"],
        "error":      j["error"],
        "plot_count": len(j["plot_files"]),
    }


@app.get("/stream/{job_id}")
async def stream_logs(job_id: str):
    """Server-Sent Events endpoint — frontend connects here for live logs."""
    if job_id not in _jobs:
        raise HTTPException(404, "Job not found")

    logq = _log_queues[job_id]

    async def event_gen():
        while True:
            try:
                msg = logq.get(timeout=0.3)
                if msg == "__DONE__":
                    yield f"data: __DONE__\n\n"
                    break
                yield f"data: {msg}\n\n"
            except queue.Empty:
                # send keep-alive comment
                yield ": keep-alive\n\n"
                await asyncio.sleep(0.1)
                if _jobs[job_id]["status"] in ("done", "failed"):
                    # drain remaining
                    while not logq.empty():
                        m = logq.get_nowait()
                        if m != "__DONE__":
                            yield f"data: {m}\n\n"
                    yield f"data: __DONE__\n\n"
                    break

    return StreamingResponse(event_gen(), media_type="text/event-stream")


@app.get("/results/{job_id}")
def get_results(job_id: str):
    if job_id not in _jobs:
        raise HTTPException(404, "Job not found")
    j = _jobs[job_id]
    if j["status"] != "done":
        return {"status": j["status"], "error": j["error"]}
    return {"status": "done", "result": j["result"]}


@app.get("/plots/{job_id}")
def list_plots(job_id: str):
    if job_id not in _jobs:
        raise HTTPException(404, "Job not found")
    return {"plots": _jobs[job_id]["plot_files"]}


@app.get("/plot/{job_id}/{filename}")
def serve_plot(job_id: str, filename: str):
    if job_id not in _jobs:
        raise HTTPException(404, "Job not found")
    out_dir = _jobs[job_id].get("out_dir", "")
    path    = os.path.join(out_dir, "plots", filename)
    if not os.path.isfile(path):
        raise HTTPException(404, f"Plot not found: {filename}")
    return FileResponse(path, media_type="image/png")


@app.get("/download/{job_id}")
def download_csv(job_id: str):
    if job_id not in _jobs:
        raise HTTPException(404, "Job not found")
    out_dir = _jobs[job_id].get("out_dir", "")
    path    = os.path.join(out_dir, "pareto_front.csv")
    if not os.path.isfile(path):
        raise HTTPException(404, "CSV not ready")
    return FileResponse(path, media_type="text/csv",
                        filename=f"pareto_front_{job_id}.csv")


@app.get("/download-all/{job_id}")
def download_all(job_id: str):
    """ZIP of all results for this job."""
    if job_id not in _jobs:
        raise HTTPException(404, "Job not found")
    out_dir = _jobs[job_id].get("out_dir", "")
    if not out_dir or not os.path.isdir(out_dir):
        raise HTTPException(404, "Results not ready")

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, _, files in os.walk(out_dir):
            for fname in files:
                fpath = os.path.join(root, fname)
                arcname = os.path.relpath(fpath, out_dir)
                zf.write(fpath, arcname)
    buf.seek(0)
    return StreamingResponse(
        buf,
        media_type="application/zip",
        headers={"Content-Disposition": f"attachment; filename=results_{job_id}.zip"},
    )


@app.post("/validate-surrogate")
async def validate_surrogate_endpoint(
    model_file:  UploadFile = File(...),
    params_file: UploadFile = File(...),
    cfg_json:    str        = Form("{}"),
):
    """
    Upload model.pkl + params.json and validate them against current ODE config.
    Surrogate is disabled by default — this endpoint is for pre-validation only.
    """
    cfg = {**DEFAULT_CFG, **json.loads(cfg_json)}

    pkl_path    = UPLOAD_DIR / f"surrogate_{uuid.uuid4().hex[:8]}.pkl"
    params_path = UPLOAD_DIR / f"surrogate_params_{uuid.uuid4().hex[:8]}.json"

    with open(pkl_path, "wb")    as f: f.write(await model_file.read())
    with open(params_path, "wb") as f: f.write(await params_file.read())

    result = validate_surrogate(str(pkl_path), str(params_path), cfg)
    return {
        "passed":     result.passed,
        "checks":     result.checks,
        "model_type": result.model_type,
        "ode_version":result.ode_version,
        "objectives": result.objectives,
        "summary":    result.summary(),
    }


@app.get("/surrogate-template")
def surrogate_template():
    """Return a template params.json for users training their own surrogate."""
    return surrogate_params_json_template()


@app.get("/default-cfg")
def get_default_cfg():
    """Return the default vehicle config (for frontend population)."""
    bounds = default_bounds(DEFAULT_CFG)
    return {
        "cfg":         DEFAULT_CFG,
        "param_keys":  PARAM_KEYS,
        "bounds":      {k: list(v) for k, v in bounds.items()},
    }
