"""
optimiser.py
============
Two optimisation modes — selected automatically based on user choice:

  MODE A  (multi-objective)  -> NSGA-II via pymoo
      Objectives: RMS_z, RMS_x, RMS_y  (all minimised simultaneously)
      Returns a Pareto front.

  MODE B  (single-objective) -> Bayesian optimisation via scikit-optimize
      Objective: combined weighted RMS_total
      Returns a single best solution + convergence trace.

Public API
----------
run_optimisation(cfg, t_eval, mode, opt_settings, log_cb) -> OptResult
"""

from __future__ import annotations
import copy, time, warnings
import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Callable, Tuple

from data_config import PARAM_KEYS, default_bounds
from solver import run_one_case, compute_seat_rms, compute_seat_rms_axes

warnings.filterwarnings("ignore")

# ---------------------------------------------------------------------------
# Result container
# ---------------------------------------------------------------------------
@dataclass
class OptResult:
    mode: str                          # "nsga2" | "bayesian"
    df_pareto: pd.DataFrame            # Pareto front (nsga2) or single row (bayesian)
    eval_log:  List[Dict]              # every evaluated candidate
    hv_history: List[float]            # hypervolume per generation (nsga2 only)
    convergence: List[float]           # best objective per iteration (bayesian only)
    wall_seconds: float
    n_evals: int

    @property
    def best(self) -> Dict:
        row = self.df_pareto.iloc[0]
        return row.to_dict()


# ===========================================================================
# NSGA-II  (multi-objective)
# ===========================================================================
def _run_nsga2(
    cfg: Dict,
    t_eval: np.ndarray,
    pop_size: int,
    n_gen: int,
    log_cb: Callable,
) -> OptResult:
    from pymoo.core.problem        import ElementwiseProblem
    from pymoo.algorithms.moo.nsga2 import NSGA2
    from pymoo.operators.crossover.sbx    import SBX
    from pymoo.operators.mutation.pm      import PM
    from pymoo.operators.sampling.rnd     import FloatRandomSampling
    from pymoo.optimize                   import minimize as pymoo_minimize
    from pymoo.indicators.hv              import HV
    from pymoo.core.callback              import Callback

    bounds = default_bounds(cfg)
    XL = np.array([bounds[k][0] for k in PARAM_KEYS])
    XU = np.array([bounds[k][1] for k in PARAM_KEYS])
    HV_REF = np.array([5.0, 5.0, 5.0])

    eval_log: List[Dict]  = []
    hv_history: List[float] = []

    class VehicleProblem(ElementwiseProblem):
        def __init__(self):
            super().__init__(n_var=len(PARAM_KEYS), n_obj=3, n_constr=0, xl=XL, xu=XU)

        def _evaluate(self, x, out, *args, **kwargs):
            params = dict(zip(PARAM_KEYS, x.tolist()))
            gen    = getattr(self, "_gen", 0)
            try:
                df = run_one_case(params, cfg, t_eval)
                rms = compute_seat_rms_axes(df, cfg)
                f   = [rms["rms_z"], rms["rms_x"], rms["rms_y"]]
            except Exception as e:
                log_cb(f"[WARN] eval failed: {e}")
                f = [99.0, 99.0, 99.0]
                rms = {"rms_z": 99.0, "rms_x": 99.0, "rms_y": 99.0, "rms_total": 99.0}
            out["F"] = f
            entry = {**params, **rms, "gen": gen, "f": f}
            eval_log.append(entry)
            log_cb(f"  eval {len(eval_log):>4d} | gen={gen} | z={f[0]:.4f} x={f[1]:.4f} y={f[2]:.4f}")

    problem = VehicleProblem()
    gen_counter = [0]

    class HVCallback(Callback):
        def notify(self, algorithm):
            gen_counter[0] = algorithm.n_gen
            for e in eval_log:
                if "gen" not in e or e["gen"] == 0:
                    e["gen"] = algorithm.n_gen
            # compute HV for non-dominated
            F = algorithm.pop.get("F")
            valid = F[np.all(F < 90, axis=1)]
            if len(valid) > 0:
                hv = HV(ref_point=HV_REF)
                hv_history.append(float(hv.do(valid)))
            else:
                hv_history.append(0.0)
            log_cb(f"[GEN {algorithm.n_gen:>3d}/{n_gen}]  pop={len(F)}  HV={hv_history[-1]:.4f}")

    log_cb(f"NSGA-II starting | pop={pop_size} | gen={n_gen} | evals≈{pop_size*(n_gen+1)}")
    t0 = time.time()

    algorithm = NSGA2(
        pop_size=pop_size,
        sampling=FloatRandomSampling(),
        crossover=SBX(prob=0.9, eta=15),
        mutation=PM(eta=20),
        eliminate_duplicates=True,
    )

    result = pymoo_minimize(
        problem, algorithm,
        ("n_gen", n_gen),
        callback=HVCallback(),
        seed=42, verbose=False,
    )

    wall = time.time() - t0
    log_cb(f"NSGA-II done in {wall:.1f}s | total evals={len(eval_log)}")

    # ---- Extract Pareto front ----
    rows = []
    X, F = result.opt.get("X"), result.opt.get("F")
    for i, (xi, fi) in enumerate(zip(X, F)):
        params = dict(zip(PARAM_KEYS, xi.tolist()))
        rows.append({
            **params,
            "rms_z":     float(fi[0]),
            "rms_x":     float(fi[1]),
            "rms_y":     float(fi[2]),
            "rms_total": float(np.sum(fi)),
            "label":     f"P{i+1:02d}",
        })

    df_pareto = pd.DataFrame(rows).sort_values("rms_total").reset_index(drop=True)

    # Label best per axis
    for col, axis in [("rms_z", "Best_vertical"), ("rms_x", "Best_longitudinal"),
                      ("rms_y", "Best_lateral"), ("rms_total", "Best_total")]:
        idx = df_pareto[col].idxmin()
        df_pareto.loc[idx, "label"] = axis

    return OptResult(
        mode="nsga2",
        df_pareto=df_pareto,
        eval_log=eval_log,
        hv_history=hv_history,
        convergence=[],
        wall_seconds=wall,
        n_evals=len(eval_log),
    )


# ===========================================================================
# Bayesian Optimisation  (single-objective)
# ===========================================================================
def _run_bayesian(
    cfg: Dict,
    t_eval: np.ndarray,
    n_calls: int,
    n_initial: int,
    log_cb: Callable,
) -> OptResult:
    from skopt              import gp_minimize
    from skopt.space        import Real
    from skopt.callbacks    import CheckpointSaver
    from skopt.utils        import use_named_args

    bounds    = default_bounds(cfg)
    space     = [Real(bounds[k][0], bounds[k][1], name=k) for k in PARAM_KEYS]
    eval_log: List[Dict]    = []
    convergence: List[float] = []

    @use_named_args(space)
    def objective(**params):
        try:
            df  = run_one_case(params, cfg, t_eval)
            val = compute_seat_rms(df, cfg)
            rms = compute_seat_rms_axes(df, cfg)
        except Exception as e:
            log_cb(f"[WARN] eval failed: {e}")
            val = 99.0
            rms = {"rms_z": 99.0, "rms_x": 99.0, "rms_y": 99.0, "rms_total": 99.0}

        entry = {**params, **rms}
        eval_log.append(entry)
        current_best = min([e["rms_total"] for e in eval_log])
        convergence.append(current_best)
        log_cb(f"  eval {len(eval_log):>4d} | rms_total={val:.4f} | best so far={current_best:.4f}")
        return float(val)

    log_cb(f"Bayesian opt starting | n_calls={n_calls} | n_initial={n_initial}")
    t0 = time.time()

    result = gp_minimize(
        objective, space,
        n_calls=n_calls,
        n_initial_points=n_initial,
        acq_func="EI",
        noise=1e-10,
        random_state=42,
        verbose=False,
    )

    wall = time.time() - t0
    log_cb(f"Bayesian done in {wall:.1f}s | total evals={len(eval_log)}")

    best_params = dict(zip(PARAM_KEYS, result.x))
    best_rms    = compute_seat_rms_axes(
        run_one_case(best_params, cfg, t_eval), cfg
    )
    df_pareto = pd.DataFrame([{
        **best_params,
        **best_rms,
        "label": "Best_total",
    }])

    return OptResult(
        mode="bayesian",
        df_pareto=df_pareto,
        eval_log=eval_log,
        hv_history=[],
        convergence=convergence,
        wall_seconds=wall,
        n_evals=len(eval_log),
    )


# ===========================================================================
# Public entry point
# ===========================================================================
def run_optimisation(
    cfg: Dict,
    t_eval: np.ndarray,
    mode: str = "nsga2",
    opt_settings: Optional[Dict] = None,
    log_cb: Optional[Callable] = None,
) -> OptResult:
    """
    Parameters
    ----------
    cfg          : full vehicle config (with CSV paths already set)
    t_eval       : time evaluation array
    mode         : "nsga2"  |  "bayesian"
    opt_settings : dict with mode-specific knobs (see below)
    log_cb       : callable(str) for live log streaming to frontend

    NSGA-II settings keys   : pop_size (int), n_gen (int)
    Bayesian settings keys  : n_calls (int), n_initial (int)
    """
    if log_cb is None:
        log_cb = print
    if opt_settings is None:
        opt_settings = {}

    if mode == "nsga2":
        return _run_nsga2(
            cfg, t_eval,
            pop_size=int(opt_settings.get("pop_size", 10)),
            n_gen=int(opt_settings.get("n_gen", 5)),
            log_cb=log_cb,
        )
    elif mode == "bayesian":
        return _run_bayesian(
            cfg, t_eval,
            n_calls=int(opt_settings.get("n_calls", 50)),
            n_initial=int(opt_settings.get("n_initial", 10)),
            log_cb=log_cb,
        )
    else:
        raise ValueError(f"Unknown optimisation mode: {mode!r}. Use 'nsga2' or 'bayesian'.")
