import React, { useState, useEffect, useRef, useCallback } from "react";
import Editor from "@monaco-editor/react";
import axios from "axios";

const API = "/api";

// ── default ODE function shown in editor ───────────────────────────────────
const DEFAULT_ODE_CODE = `# Ride Optimisation — ODE configuration
# Edit the parameters below. Do NOT rename the CONFIG dict.
# All fields here will be sent to the backend as cfg_overrides.

CONFIG = {
    # ── Physical parameters ──────────────────────────────────────────────
    "m_s":    22485.0,     # Sprung mass [kg]
    "m_c":    862.0,       # Cabin mass [kg]
    "I_syy":  103787.0,    # Sprung yaw inertia [kg·m²]
    "I_sxx":  8598.0,      # Sprung roll inertia [kg·m²]
    "I_sxy":  763.0,       # Sprung cross inertia [kg·m²]
    "I_xxc":  516.6,       # Cabin roll inertia [kg·m²]
    "I_yyc":  1045.0,      # Cabin pitch inertia [kg·m²]

    # ── Suspension baseline (optimised parameters) ───────────────────────
    "K_f":        474257,  # Front spring stiffness [N/m]
    "C_f":        15000,   # Front damper coefficient [N·s/m]
    "K_2":        1077620, # Rear axle 1 stiffness [N/m]
    "K_3":        1077620, # Rear axle 2 stiffness [N/m]
    "cs_minus":   0.3,     # Damper compression coefficient
    "asym_ratio": 3.0,     # Rebound/compression ratio
    "gamma_c":    0.12,    # Compression saturation factor
    "gamma_r":    0.09,    # Rebound saturation factor

    # ── Cabin mounts ─────────────────────────────────────────────────────
    "K_cfl": 49050.0,  "K_cfr": 49050.0,
    "K_crl": 24525.0,  "K_crr": 24525.0,
    "C_cfl": 5035.0,   "C_cfr": 5035.0,
    "C_crl": 3400.0,   "C_crr": 3400.0,

    # ── Geometry ─────────────────────────────────────────────────────────
    "lf": 5.05,   "L12": 0.54,  "L23": 1.96,
    "a":  0.9,    "b":   1.080,
    "hs": 0.68,   "hcp": 0.1,
    "l_cf": 6.458, "l_cr": 4.5,
    "l_cfcg": 0.871, "l_crcg": 1.087,
    "WT1": 0.814,  "WT2": 1.047, "WT3": 1.047,
    "S_f": 0.814,  "S_tf2": 1.043, "S_tf3": 1.043,
    "s1":  0.6277, "s2":    0.6305,

    # ── Baumgarte stabilisation ───────────────────────────────────────────
    "baum_omega": 10.0, "baum_zeta": 1.0,
}
`;

// ── CSV key labels ─────────────────────────────────────────────────────────
const CSV_KEYS = [
  { key: "fa_lh",  label: "Front Axle — Left"   },
  { key: "fa_rh",  label: "Front Axle — Right"  },
  { key: "ra1_lh", label: "Rear Axle 1 — Left"  },
  { key: "ra1_rh", label: "Rear Axle 1 — Right" },
  { key: "ra2_lh", label: "Rear Axle 2 — Left"  },
  { key: "ra2_rh", label: "Rear Axle 2 — Right" },
];

// ── helpers ────────────────────────────────────────────────────────────────
function parseConfig(code) {
  try {
    const match = code.match(/CONFIG\s*=\s*\{([\s\S]*)\}/);
    if (!match) return {};
    const body = match[1]
      .replace(/#[^\n]*/g, "")
      .replace(/(\w[\w\d_]*)\s*:/g, '"$1":')
      .replace(/,\s*\}/g, "}")
      .replace(/,\s*$/, "");
    return JSON.parse("{" + body + "}");
  } catch {
    return null;
  }
}

function LogLine({ line }) {
  const cls = line.includes("[ERROR]") ? "log-err"
            : line.includes("[WARN]")  ? "log-warn"
            : line.includes("[GEN")    ? "log-info"
            : "";
  return <div className={cls}>{line}</div>;
}

// ── Main App ───────────────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab] = useState("ode");   // "ode" | "results" | "surrogate"

  // ODE editor state
  const [odeCode, setOdeCode]       = useState(DEFAULT_ODE_CODE);
  const [configErr, setConfigErr]   = useState(null);

  // CSV uploads
  const [csvPaths, setCsvPaths]     = useState({});  // key -> server_path
  const [csvStatus, setCsvStatus]   = useState({});  // key -> "uploading"|"done"|"error"

  // Optimiser settings
  const [mode, setMode]             = useState("nsga2");
  const [popSize, setPopSize]       = useState(10);
  const [nGen, setNGen]             = useState(5);
  const [nCalls, setNCalls]         = useState(50);
  const [nInitial, setNInitial]     = useState(10);
  const [tEnd, setTEnd]             = useState(466.945);
  const [tIgnore, setTIgnore]       = useState(0.5);

  // Job state
  const [jobId, setJobId]           = useState(null);
  const [jobStatus, setJobStatus]   = useState(null);
  const [logs, setLogs]             = useState([]);
  const [running, setRunning]       = useState(false);
  const [results, setResults]       = useState(null);
  const [plots, setPlots]           = useState([]);
  const [selectedPlot, setSelectedPlot] = useState(null);
  const [progress, setProgress]     = useState(0);

  // Surrogate
  const [surrModelFile, setSurrModelFile]   = useState(null);
  const [surrParamsFile, setSurrParamsFile] = useState(null);
  const [surrValidation, setSurrValidation] = useState(null);
  const [surrLoading, setSurrLoading]       = useState(false);

  const logRef = useRef(null);

  // Auto-scroll logs
  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [logs]);

  // Parse config on code change
  useEffect(() => {
    const parsed = parseConfig(odeCode);
    setConfigErr(parsed === null ? "CONFIG parse error — check Python syntax" : null);
  }, [odeCode]);

  // ── Upload a CSV file ─────────────────────────────────────────────────
  const uploadCsv = useCallback(async (key, file) => {
    setCsvStatus(s => ({ ...s, [key]: "uploading" }));
    const fd = new FormData();
    fd.append("file", file);
    fd.append("key", key);
    try {
      const res = await axios.post(`${API}/upload-csv`, fd);
      setCsvPaths(p => ({ ...p, [key]: res.data.server_path }));
      setCsvStatus(s => ({ ...s, [key]: "done" }));
    } catch {
      setCsvStatus(s => ({ ...s, [key]: "error" }));
    }
  }, []);

  // ── Start optimisation run ─────────────────────────────────────────────
  const startRun = useCallback(async () => {
    const cfg = parseConfig(odeCode);
    if (!cfg) { alert("CONFIG parse error — fix the ODE code first."); return; }

    const csvCount = Object.keys(csvPaths).length;
    if (csvCount < 6) {
      alert(`Please upload all 6 axle CSV files (${csvCount}/6 uploaded).`);
      return;
    }

    setLogs([]);
    setResults(null);
    setPlots([]);
    setRunning(true);
    setProgress(5);
    setTab("ode");

    const payload = {
      mode,
      pop_size:      parseInt(popSize),
      n_gen:         parseInt(nGen),
      n_calls:       parseInt(nCalls),
      n_initial:     parseInt(nInitial),
      T_END:         parseFloat(tEnd),
      T_IGNORE:      parseFloat(tIgnore),
      cfg_overrides: cfg,
      csv_paths:     csvPaths,
    };

    let jid;
    try {
      const res = await axios.post(`${API}/run`, payload);
      jid = res.data.job_id;
      setJobId(jid);
      setJobStatus("running");
    } catch (e) {
      alert("Failed to start job: " + e.message);
      setRunning(false);
      return;
    }

    // ── SSE log stream ─────────────────────────────────────────────────
    const evtSrc = new EventSource(`${API}/stream/${jid}`);
    let evalCount = 0;
    const totalEvals = mode === "nsga2"
      ? parseInt(popSize) * (parseInt(nGen) + 1)
      : parseInt(nCalls);

    evtSrc.onmessage = (e) => {
      if (e.data === "__DONE__") {
        evtSrc.close();
        setProgress(100);
        fetchFinalResults(jid);
        return;
      }
      setLogs(l => [...l, e.data]);
      if (e.data.includes("eval ")) {
        evalCount++;
        setProgress(Math.min(95, Math.round((evalCount / totalEvals) * 90) + 5));
      }
    };

    evtSrc.onerror = () => {
      evtSrc.close();
      fetchFinalResults(jid);
    };
  }, [odeCode, csvPaths, mode, popSize, nGen, nCalls, nInitial, tEnd, tIgnore]);

  const fetchFinalResults = async (jid) => {
    try {
      const [rRes, pRes] = await Promise.all([
        axios.get(`${API}/results/${jid}`),
        axios.get(`${API}/plots/${jid}`),
      ]);
      setResults(rRes.data.result);
      const pl = pRes.data.plots || [];
      setPlots(pl);
      if (pl.length > 0) setSelectedPlot(pl[0]);
      setJobStatus(rRes.data.status);
    } catch (e) {
      console.error(e);
    } finally {
      setRunning(false);
      setTab("results");
    }
  };

  // ── Validate surrogate ──────────────────────────────────────────────
  const validateSurrogate = async () => {
    if (!surrModelFile || !surrParamsFile) {
      alert("Upload both model.pkl and params.json first.");
      return;
    }
    setSurrLoading(true);
    setSurrValidation(null);
    const fd = new FormData();
    fd.append("model_file", surrModelFile);
    fd.append("params_file", surrParamsFile);
    fd.append("cfg_json", "{}");
    try {
      const res = await axios.post(`${API}/validate-surrogate`, fd);
      setSurrValidation(res.data);
    } catch (e) {
      setSurrValidation({ passed: false, checks: [], summary: String(e) });
    } finally {
      setSurrLoading(false);
    }
  };

  // ── Render ─────────────────────────────────────────────────────────────
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100vh", overflow: "hidden" }}>

      {/* Header */}
      <header style={{
        background: "var(--surface)", borderBottom: "1px solid var(--border)",
        padding: "10px 24px", display: "flex", alignItems: "center", gap: 16, flexShrink: 0,
      }}>
        <span style={{ fontSize: "1.4rem" }}>🚛</span>
        <h1>Ride Optimisation</h1>
        <span className="badge badge-info" style={{ marginLeft: 4 }}>
          {mode === "nsga2" ? "NSGA-II (Multi-objective)" : "Bayesian (Single-objective)"}
        </span>
        {running && (
          <span className="badge badge-warn" style={{ marginLeft: "auto" }}>
            ⚙ Running…
          </span>
        )}
        {jobStatus === "done" && !running && (
          <span className="badge badge-ok" style={{ marginLeft: "auto" }}>
            ✓ Complete
          </span>
        )}
        {jobStatus === "failed" && !running && (
          <span className="badge badge-err" style={{ marginLeft: "auto" }}>
            ✗ Failed
          </span>
        )}
      </header>

      {/* Tabs */}
      <div style={{ padding: "0 24px", background: "var(--surface)", flexShrink: 0, borderBottom: "1px solid var(--border)" }}>
        <div className="tabs" style={{ marginBottom: 0 }}>
          <div className={`tab ${tab === "ode" ? "active" : ""}`} onClick={() => setTab("ode")}>
            ODE Setup
          </div>
          <div
            className={`tab ${tab === "results" ? "active" : ""} ${!results ? "disabled" : ""}`}
            onClick={() => results && setTab("results")}
          >
            Results {plots.length > 0 && `(${plots.length} plots)`}
          </div>
          <div className={`tab ${tab === "surrogate" ? "active" : ""}`} onClick={() => setTab("surrogate")}>
            Surrogate <span style={{ fontSize: 10, color: "var(--text3)", marginLeft: 4 }}>(disabled)</span>
          </div>
        </div>
      </div>

      {/* Body */}
      <div style={{ flex: 1, overflow: "hidden", display: "flex", flexDirection: "column", padding: "16px 24px", gap: 12 }}>

        {/* ═══ ODE TAB ═══════════════════════════════════════════════════════ */}
        {tab === "ode" && (
          <div style={{ flex: 1, overflow: "hidden", display: "grid", gridTemplateColumns: "1fr 340px", gap: 12 }}>

            {/* Left: Editor + CSVs */}
            <div style={{ display: "flex", flexDirection: "column", gap: 12, overflow: "hidden", minHeight: 0 }}>

              {/* Editor */}
              <div className="card" style={{ flex: 1, padding: 0, overflow: "hidden", minHeight: 0 }}>
                <div style={{
                  background: "var(--surface2)", padding: "8px 14px",
                  display: "flex", alignItems: "center", justifyContent: "space-between",
                  borderBottom: "1px solid var(--border)",
                }}>
                  <span style={{ fontFamily: "var(--font-mono)", fontSize: 12, color: "var(--text2)" }}>
                    ode_config.py
                  </span>
                  {configErr
                    ? <span className="badge badge-err">{configErr}</span>
                    : <span className="badge badge-ok">✓ valid</span>
                  }
                </div>
                <Editor
                  height="100%"
                  defaultLanguage="python"
                  theme="vs-dark"
                  value={odeCode}
                  onChange={v => setOdeCode(v || "")}
                  options={{
                    fontSize: 13,
                    fontFamily: "JetBrains Mono, Fira Code, monospace",
                    minimap: { enabled: false },
                    scrollBeyondLastLine: false,
                    lineNumbers: "on",
                    wordWrap: "on",
                    padding: { top: 12 },
                  }}
                />
              </div>

              {/* CSV Upload */}
              <div className="card">
                <h3 style={{ marginBottom: 10 }}>Axle Displacement CSV Files</h3>
                <div className="grid-3" style={{ gap: 8 }}>
                  {CSV_KEYS.map(({ key, label }) => (
                    <CsvDropzone
                      key={key}
                      csvKey={key}
                      label={label}
                      status={csvStatus[key]}
                      onFile={(file) => uploadCsv(key, file)}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Right: Settings + Log */}
            <div style={{ display: "flex", flexDirection: "column", gap: 12, overflow: "auto" }}>

              {/* Optimiser settings */}
              <div className="card">
                <h3 style={{ marginBottom: 12 }}>Optimiser</h3>

                <label>Mode</label>
                <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
                  <ModeBtn active={mode === "nsga2"} onClick={() => setMode("nsga2")}>
                    Multi-objective<br/>
                    <span style={{ fontSize: 10, color: "var(--text3)" }}>NSGA-II · Pareto front</span>
                  </ModeBtn>
                  <ModeBtn active={mode === "bayesian"} onClick={() => setMode("bayesian")}>
                    Single-objective<br/>
                    <span style={{ fontSize: 10, color: "var(--text3)" }}>Bayesian · best RMS</span>
                  </ModeBtn>
                </div>

                {mode === "nsga2" ? (
                  <div className="grid-2">
                    <NumberField label="Population size" value={popSize} onChange={setPopSize} min={4} />
                    <NumberField label="Generations"     value={nGen}    onChange={setNGen}    min={1} />
                  </div>
                ) : (
                  <div className="grid-2">
                    <NumberField label="Total calls"    value={nCalls}   onChange={setNCalls}   min={5} />
                    <NumberField label="Initial points" value={nInitial} onChange={setNInitial} min={3} />
                  </div>
                )}

                <div style={{ height: 1, background: "var(--border)", margin: "12px 0" }} />
                <h3 style={{ marginBottom: 8 }}>Simulation time</h3>
                <div className="grid-2">
                  <NumberField label="T_END [s]"    value={tEnd}    onChange={setTEnd}    step={0.001} />
                  <NumberField label="T_IGNORE [s]" value={tIgnore} onChange={setTIgnore} step={0.1} />
                </div>

                <div style={{ marginTop: 12 }}>
                  <div className="text-sm text-muted" style={{ marginBottom: 6 }}>
                    Total ODE evaluations ≈{" "}
                    <span className="text-accent text-mono">
                      {mode === "nsga2"
                        ? parseInt(popSize || 0) * (parseInt(nGen || 0) + 1)
                        : parseInt(nCalls || 0)}
                    </span>
                  </div>
                  <button
                    className="btn btn-primary w-full"
                    disabled={running || !!configErr || Object.keys(csvPaths).length < 6}
                    onClick={startRun}
                  >
                    {running ? "⚙ Running…" : "▶ Run Optimisation"}
                  </button>
                  {Object.keys(csvPaths).length < 6 && !running && (
                    <div className="text-sm text-warn mt-2">
                      Upload all 6 CSV files to enable run ({Object.keys(csvPaths).length}/6)
                    </div>
                  )}
                </div>
              </div>

              {/* Progress */}
              {(running || jobStatus) && (
                <div className="card">
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                    <span className="text-sm">Progress</span>
                    <span className="text-sm text-mono text-accent">{progress}%</span>
                  </div>
                  <div className="progress-track">
                    <div className="progress-fill" style={{ width: `${progress}%` }} />
                  </div>
                </div>
              )}

              {/* Log console */}
              <div className="card" style={{ flex: 1 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                  <h3>Live Log</h3>
                  <button className="btn btn-ghost btn-sm" onClick={() => setLogs([])}>Clear</button>
                </div>
                <div className="log-console" ref={logRef}>
                  {logs.length === 0
                    ? <span className="text-muted">Waiting for run…</span>
                    : logs.map((l, i) => <LogLine key={i} line={l} />)
                  }
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ═══ RESULTS TAB ═══════════════════════════════════════════════════ */}
        {tab === "results" && results && (
          <div style={{ flex: 1, overflow: "hidden", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>

            {/* Left: Pareto table + downloads */}
            <div style={{ display: "flex", flexDirection: "column", gap: 12, overflow: "auto" }}>

              <div className="card">
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                  <h3>
                    {results.mode === "nsga2" ? "Pareto Front" : "Best Solution"} &nbsp;
                    <span className="badge badge-info">{results.mode === "nsga2" ? "NSGA-II" : "Bayesian"}</span>
                  </h3>
                  <div style={{ display: "flex", gap: 8 }}>
                    <a href={`${API}/download/${jobId}`} className="btn btn-ghost btn-sm">⬇ CSV</a>
                    <a href={`${API}/download-all/${jobId}`} className="btn btn-ghost btn-sm">⬇ ZIP</a>
                  </div>
                </div>
                <div style={{ overflowX: "auto" }}>
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Label</th>
                        <th>RMS_z</th>
                        <th>RMS_x</th>
                        <th>RMS_y</th>
                        <th>RMS_total</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(results.pareto || []).map((row, i) => (
                        <tr key={i}>
                          <td><span className="text-mono text-accent">{row.label || `P${i+1}`}</span></td>
                          <td className="text-mono">{Number(row.rms_z).toFixed(4)}</td>
                          <td className="text-mono">{Number(row.rms_x).toFixed(4)}</td>
                          <td className="text-mono">{Number(row.rms_y).toFixed(4)}</td>
                          <td className="text-mono text-green">{Number(row.rms_total).toFixed(4)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Summary stats */}
              <div className="card">
                <h3 style={{ marginBottom: 10 }}>Run Summary</h3>
                <div className="grid-2" style={{ gap: 8 }}>
                  <StatBox label="Total evaluations" value={results.n_evals} />
                  <StatBox label="Wall time (s)"      value={results.wall_seconds?.toFixed(1)} />
                  <StatBox label="Pareto solutions"   value={(results.pareto || []).length} />
                  <StatBox label="Mode"               value={results.mode} />
                </div>
              </div>

              {/* Best params */}
              {results.pareto?.[0] && (
                <div className="card">
                  <h3 style={{ marginBottom: 10 }}>Best Solution — Parameters</h3>
                  <table className="data-table">
                    <thead><tr><th>Parameter</th><th>Value</th></tr></thead>
                    <tbody>
                      {["K_f","C_f","K_2","K_3","cs_minus","asym_ratio","gamma_c","gamma_r"].map(k => (
                        <tr key={k}>
                          <td className="text-mono">{k}</td>
                          <td className="text-mono text-accent">{Number(results.pareto[0][k]).toExponential(4)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Right: Plots */}
            <div style={{ display: "flex", flexDirection: "column", gap: 12, overflow: "hidden" }}>
              <div className="card" style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
                <h3 style={{ marginBottom: 8 }}>Plots</h3>
                {/* Plot selector */}
                <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 10 }}>
                  {plots.map(p => (
                    <button
                      key={p}
                      className={`btn btn-sm ${selectedPlot === p ? "btn-primary" : "btn-ghost"}`}
                      onClick={() => setSelectedPlot(p)}
                      style={{ fontSize: 11 }}
                    >
                      {p.replace(".png", "").replace(/_/g, " ")}
                    </button>
                  ))}
                </div>
                {/* Plot image */}
                {selectedPlot && (
                  <div style={{ flex: 1, overflow: "hidden", borderRadius: "var(--radius)", background: "#111" }}>
                    <img
                      src={`${API}/plot/${jobId}/${selectedPlot}`}
                      alt={selectedPlot}
                      style={{ width: "100%", height: "100%", objectFit: "contain" }}
                    />
                  </div>
                )}
                {!selectedPlot && (
                  <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <span className="text-muted">No plots yet</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ═══ SURROGATE TAB ═════════════════════════════════════════════════ */}
        {tab === "surrogate" && (
          <div style={{ maxWidth: 640, margin: "0 auto", width: "100%" }}>
            <div className="card" style={{ borderColor: "var(--warn)" }}>
              <div style={{ display: "flex", gap: 12, alignItems: "flex-start", marginBottom: 16 }}>
                <span style={{ fontSize: "2rem" }}>⚠</span>
                <div>
                  <h2 style={{ color: "var(--warn)", marginBottom: 4 }}>Surrogate Model — Disabled</h2>
                  <p style={{ color: "var(--text2)", fontSize: 13, lineHeight: 1.6 }}>
                    The surrogate model path is not active. The ODE is the primary solver.
                    You can validate your surrogate files here for future use — no inference will run.
                  </p>
                </div>
              </div>

              <div style={{ height: 1, background: "var(--border)", margin: "12px 0" }} />

              <h3 style={{ marginBottom: 12 }}>Validate surrogate files (optional)</h3>

              <div className="grid-2" style={{ marginBottom: 12 }}>
                <div>
                  <label>model.pkl</label>
                  <input
                    type="file" accept=".pkl"
                    onChange={e => setSurrModelFile(e.target.files[0])}
                    style={{ color: "var(--text)", fontSize: 12, width: "100%" }}
                  />
                </div>
                <div>
                  <label>params.json</label>
                  <input
                    type="file" accept=".json"
                    onChange={e => setSurrParamsFile(e.target.files[0])}
                    style={{ color: "var(--text)", fontSize: 12, width: "100%" }}
                  />
                </div>
              </div>

              <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 16 }}>
                <button
                  className="btn btn-warn"
                  disabled={surrLoading || !surrModelFile || !surrParamsFile}
                  onClick={validateSurrogate}
                >
                  {surrLoading ? "Validating…" : "Validate"}
                </button>
                <a
                  href={`${API}/surrogate-template`}
                  className="btn btn-ghost btn-sm"
                  target="_blank" rel="noreferrer"
                >
                  ⬇ params.json template
                </a>
              </div>

              {surrValidation && (
                <div>
                  <div style={{ marginBottom: 8 }}>
                    {surrValidation.passed
                      ? <span className="badge badge-ok">✓ All checks passed</span>
                      : <span className="badge badge-err">✗ Validation failed</span>
                    }
                  </div>
                  <table className="data-table">
                    <thead><tr><th>Check</th><th>Status</th><th>Detail</th></tr></thead>
                    <tbody>
                      {(surrValidation.checks || []).map((c, i) => (
                        <tr key={i}>
                          <td className="text-mono" style={{ fontSize: 12 }}>{c.name}</td>
                          <td>
                            {c.passed
                              ? <span className="badge badge-ok">✓</span>
                              : <span className="badge badge-err">✗</span>
                            }
                          </td>
                          <td style={{ fontSize: 12, color: "var(--text2)" }}>{c.detail}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Small reusable components ──────────────────────────────────────────────

function CsvDropzone({ csvKey, label, status, onFile }) {
  const ref = useRef();
  const handleDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) onFile(file);
  };
  return (
    <div
      className={`upload-zone ${status === "done" ? "done" : ""}`}
      onDragOver={e => e.preventDefault()}
      onDrop={handleDrop}
      onClick={() => ref.current.click()}
    >
      <input
        type="file" accept=".csv" ref={ref} style={{ display: "none" }}
        onChange={e => { if (e.target.files[0]) onFile(e.target.files[0]); }}
      />
      <div style={{ marginBottom: 2 }}>
        {status === "done"     && "✓ "}
        {status === "uploading" && "⟳ "}
        {status === "error"    && "✗ "}
        <strong style={{ fontSize: 12 }}>{label}</strong>
      </div>
      <div style={{ fontSize: 10 }}>
        {status === "done"      ? "Uploaded"
         : status === "uploading" ? "Uploading…"
         : status === "error"    ? "Upload failed"
         : "Click or drop CSV"}
      </div>
    </div>
  );
}

function ModeBtn({ active, onClick, children }) {
  return (
    <button
      className={`btn ${active ? "btn-primary" : "btn-ghost"}`}
      style={{ flex: 1, flexDirection: "column", alignItems: "flex-start",
               padding: "8px 12px", textAlign: "left", lineHeight: 1.4 }}
      onClick={onClick}
    >
      {children}
    </button>
  );
}

function NumberField({ label, value, onChange, min, step }) {
  return (
    <div>
      <label>{label}</label>
      <input
        type="number" value={value} min={min} step={step || 1}
        onChange={e => onChange(e.target.value)}
      />
    </div>
  );
}

function StatBox({ label, value }) {
  return (
    <div style={{ background: "var(--surface2)", borderRadius: "var(--radius)", padding: "10px 14px" }}>
      <div style={{ fontSize: 11, color: "var(--text3)", marginBottom: 2 }}>{label}</div>
      <div style={{ fontFamily: "var(--font-mono)", fontSize: 15, color: "var(--accent)" }}>{value ?? "—"}</div>
    </div>
  );
}
