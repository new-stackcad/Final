"""
dataset.py  -  PyTorch dataset, normalisation, dataloaders.

KEY CHANGE: z_c now stored as dynamic deviation (oscillates around 0).
Normalisation stats are computed per-column as before, but now z_c has
near-zero mean so the normalised signal preserves oscillation content.
"""
from __future__ import annotations
from pathlib import Path
from typing import Dict, Optional, Tuple

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader, Dataset

from config import PARAM_BOUNDS, PARAM_NAMES, STATE_NAMES, DT, T_IGNORE, TRAIN_CFG

ROAD_COLS  = ["z_1f", "ph_f", "z_2", "ph_2", "z_3", "ph_3"]
ACCEL_COLS = [f"qdd_{n}" for n in STATE_NAMES[:3]]   # z_c, th_c, ph_c


class NormStats:
    def __init__(self, r_mean, r_std, s_mean, s_std, a_mean, a_std, p_lo, p_hi):
        self.r_mean = r_mean.astype(np.float32)
        self.r_std  = r_std.astype(np.float32)
        self.s_mean = s_mean.astype(np.float32)
        self.s_std  = s_std.astype(np.float32)
        # Accelerations: zero-mean normalisation (preserve AC content)
        self.a_mean = np.zeros_like(a_mean, dtype=np.float32)
        self.a_std  = a_std.astype(np.float32)
        self.p_lo   = p_lo.astype(np.float32)
        self.p_hi   = p_hi.astype(np.float32)

    def save(self, path: str):
        np.savez(path, r_mean=self.r_mean, r_std=self.r_std,
                 s_mean=self.s_mean, s_std=self.s_std,
                 a_mean=self.a_mean, a_std=self.a_std,
                 p_lo=self.p_lo,     p_hi=self.p_hi)
        print(f"Normalisation stats saved -> {path}")

    @staticmethod
    def load(path: str) -> "NormStats":
        d = np.load(path)
        ns = NormStats.__new__(NormStats)
        for k in d.files:
            setattr(ns, k, d[k])
        return ns

    @staticmethod
    def from_dataframe(df: pd.DataFrame) -> "NormStats":
        # Use training rows only
        if all(c in df.columns for c in ROAD_COLS):
            r_arr = df[ROAD_COLS].values.astype(np.float32)
        else:
            r_arr = np.zeros((1,6), np.float32)
        s_arr = df[STATE_NAMES].values.astype(np.float32)
        a_arr = df[ACCEL_COLS].values.astype(np.float32)
        def ms(arr): return arr.mean(0), arr.std(0)+1e-8
        r_mean,r_std = ms(r_arr)
        s_mean,s_std = ms(s_arr)
        _,     a_std = ms(a_arr)
        p_lo = np.array([PARAM_BOUNDS[k][0] for k in PARAM_NAMES], np.float32)
        p_hi = np.array([PARAM_BOUNDS[k][1] for k in PARAM_NAMES], np.float32)
        return NormStats(r_mean,r_std,s_mean,s_std,np.zeros(3,np.float32),a_std,p_lo,p_hi)


class CabinDataset(Dataset):
    """
    Each sample = one full ODE case (time series).
    States are dynamic deviations (zero-mean oscillations after normalisation).
    """
    def __init__(self, csv_path, norm_stats: NormStats,
                 split="train", t_ignore=T_IGNORE,
                 road_arr=None, cfg=None):
        df = pd.read_csv(csv_path)
        if split != "all" and "split" in df.columns:
            df = df[df["split"] == split].copy()
        self.ns      = norm_stats
        self.t_ignore = t_ignore
        self.cfg      = cfg or {}
        self.samples  = []
        h_cp = float(self.cfg.get("hcp", 0.1))

        for cid, grp in df.groupby("case_id"):
            grp = grp.sort_values("t").reset_index(drop=True)
            T   = len(grp)

            # Road inputs
            if all(c in grp.columns for c in ROAD_COLS):
                road_raw = grp[ROAD_COLS].values.astype(np.float32)
            elif road_arr is not None:
                road_raw = road_arr[:T].astype(np.float32)
            else:
                road_raw = np.zeros((T,6), np.float32)
            road_norm = (road_raw - norm_stats.r_mean) / norm_stats.r_std

            # Parameters
            p_raw  = np.array([float(grp[k].iloc[0]) for k in PARAM_NAMES], np.float32)
            p_norm = (p_raw - norm_stats.p_lo) / (norm_stats.p_hi - norm_stats.p_lo + 1e-8)

            # States (dynamic deviation, already zero-mean per construction)
            s_raw  = grp[STATE_NAMES].values.astype(np.float32)
            s_norm = (s_raw - norm_stats.s_mean) / norm_stats.s_std

            # Accels (zero-mean normalisation)
            a_raw  = grp[ACCEL_COLS].values.astype(np.float32)
            a_norm = a_raw / norm_stats.a_std   # a_mean=0 by design

            # ISO 2631 RMS in physical units
            mask   = grp["t"].values >= t_ignore
            if mask.any():
                az = a_raw[mask,0]
                ax = -h_cp * a_raw[mask,1]
                ay =  h_cp * a_raw[mask,2]
                rms_val = float(np.sqrt(np.mean(az**2)+np.mean(ax**2)+np.mean(ay**2)))
            else:
                rms_val = 0.0

            self.samples.append({
                "road":      torch.tensor(road_norm, dtype=torch.float32),
                "param":     torch.tensor(p_norm,    dtype=torch.float32),
                "state":     torch.tensor(s_norm,    dtype=torch.float32),
                "accel":     torch.tensor(a_norm,    dtype=torch.float32),
                "accel_raw": torch.tensor(a_raw,     dtype=torch.float32),
                "a_std":     torch.tensor(norm_stats.a_std, dtype=torch.float32),
                "rms":       torch.tensor([rms_val], dtype=torch.float32),
                "case_id":   int(cid),
            })

    def __len__(self):  return len(self.samples)
    def __getitem__(self, i): return self.samples[i]


def collate_pad(batch):
    max_T = max(s["road"].shape[0] for s in batch)
    pad_keys  = {"road","state","accel","accel_raw"}
    flat_keys = {"param","rms","a_std"}
    out = {k: [] for k in batch[0] if k != "case_id"}
    out["case_id"] = [s["case_id"] for s in batch]
    for s in batch:
        T   = s["road"].shape[0]
        pad = max_T - T
        for k in pad_keys:
            out[k].append(torch.nn.functional.pad(s[k],(0,0,0,pad)))
        for k in flat_keys:
            out[k].append(s[k])
    return {k: (torch.stack(v) if k!="case_id" else v) for k,v in out.items()}


def build_loaders(csv_path, norm_stats, batch_size=TRAIN_CFG["batch_size"],
                  road_arr=None, num_workers=0, cfg=None):
    train_ds = CabinDataset(csv_path, norm_stats, split="train",
                             road_arr=road_arr, cfg=cfg)
    n_val    = max(1, len(train_ds)//5)
    n_train  = len(train_ds) - n_val
    if n_train < 1:
        n_train = len(train_ds); n_val = len(train_ds)
        train_sub = val_sub = train_ds
    else:
        train_sub, val_sub = torch.utils.data.random_split(
            train_ds, [n_train, n_val],
            generator=torch.Generator().manual_seed(0))
    test_ds = CabinDataset(csv_path, norm_stats, split="test",
                            road_arr=road_arr, cfg=cfg)
    if len(test_ds) == 0:
        test_ds = train_ds

    eff_tr = min(batch_size, n_train)
    eff_vl = min(batch_size, n_val)
    eff_te = min(batch_size, max(1,len(test_ds)))
    kw = dict(collate_fn=collate_pad, num_workers=num_workers,
              pin_memory=torch.cuda.is_available())
    print(f"Dataset splits: train={n_train}  val={n_val}  test={len(test_ds)}")
    return (DataLoader(train_sub, batch_size=eff_tr, shuffle=True,  **kw),
            DataLoader(val_sub,   batch_size=eff_vl, shuffle=False, **kw),
            DataLoader(test_ds,   batch_size=eff_te, shuffle=False, **kw))
