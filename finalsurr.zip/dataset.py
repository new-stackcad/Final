"""
dataset.py  –  PyTorch dataset, normalisation, and dataloaders.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Optional, Tuple

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader, Dataset

from config import (
    PARAM_BOUNDS, PARAM_NAMES, STATE_NAMES,
    DT, T_IGNORE, TRAIN_CFG,
)

# ─────────────────────────────────────────────────────────────
# Normalisation statistics  (saved / loaded as .npz)
# ─────────────────────────────────────────────────────────────

class NormStats:
    """Holds mean/std for road, state, accel + lo/hi for params."""

    def __init__(self,
                 r_mean: np.ndarray, r_std:  np.ndarray,
                 s_mean: np.ndarray, s_std:  np.ndarray,
                 a_mean: np.ndarray, a_std:  np.ndarray,
                 p_lo:   np.ndarray, p_hi:   np.ndarray):
        self.r_mean = r_mean.astype(np.float32)
        self.r_std  = r_std.astype(np.float32)
        self.s_mean = s_mean.astype(np.float32)
        self.s_std  = s_std.astype(np.float32)
        self.a_mean = a_mean.astype(np.float32)
        self.a_std  = a_std.astype(np.float32)
        self.p_lo   = p_lo.astype(np.float32)
        self.p_hi   = p_hi.astype(np.float32)

    def save(self, path: str) -> None:
        np.savez(path, r_mean=self.r_mean, r_std=self.r_std,
                 s_mean=self.s_mean, s_std=self.s_std,
                 a_mean=self.a_mean, a_std=self.a_std,
                 p_lo=self.p_lo,     p_hi=self.p_hi)
        print(f"Normalisation stats saved → {path}")

    @staticmethod
    def load(path: str) -> "NormStats":
        d = np.load(path)
        return NormStats(**{k: d[k] for k in d.files})

    @staticmethod
    def from_dataframe(df: pd.DataFrame) -> "NormStats":
        """Compute stats from the *training* subset of a DataFrame."""
        road_cols  = ["z_1f", "ph_f", "z_2", "ph_2", "z_3", "ph_3"]
        state_cols = STATE_NAMES
        accel_cols = [f"qdd_{n}" for n in STATE_NAMES[:3]]

        if all(c in df.columns for c in road_cols):
            r_arr = df[road_cols].values.astype(np.float32)
        else:
            r_arr = np.zeros((1, 6), np.float32)

        s_arr = df[state_cols].values.astype(np.float32)
        a_arr = df[accel_cols].values.astype(np.float32)

        def ms(arr):
            return arr.mean(0), arr.std(0) + 1e-8

        r_mean, r_std = ms(r_arr)
        s_mean, s_std = ms(s_arr)
        a_mean, a_std = ms(a_arr)
        p_lo = np.array([PARAM_BOUNDS[k][0] for k in PARAM_NAMES], np.float32)
        p_hi = np.array([PARAM_BOUNDS[k][1] for k in PARAM_NAMES], np.float32)
        return NormStats(r_mean, r_std, s_mean, s_std, a_mean, a_std, p_lo, p_hi)


# ─────────────────────────────────────────────────────────────
# Dataset
# ─────────────────────────────────────────────────────────────

ROAD_COLS  = ["z_1f", "ph_f", "z_2", "ph_2", "z_3", "ph_3"]
ACCEL_COLS = [f"qdd_{n}" for n in STATE_NAMES[:3]]   # z_c, th_c, ph_c


class CabinDataset(Dataset):
    """
    One sample = one full ODE case (time series).

    Returns dict with keys:
        road   : [T, 6]   normalised axle inputs
        param  : [8]      normalised design parameters
        state  : [T, 6]   normalised states
        accel  : [T, 3]   normalised accels (z_c, th_c, ph_c)
        rms    : [1]      cabin seat RMS in physical units [m/s²]
        case_id: int
    """

    def __init__(self,
                 csv_path:   str,
                 norm_stats: NormStats,
                 split:      str   = "train",   # "train" | "test" | "all"
                 h_seat:     float = 0.6,
                 t_ignore:   float = T_IGNORE,
                 road_arr:   Optional[np.ndarray] = None,  # [T, 6] pre-computed
                 t_eval:     Optional[np.ndarray] = None):
        df = pd.read_csv(csv_path)

        if split != "all" and "split" in df.columns:
            df = df[df["split"] == split].copy()

        self.ns      = norm_stats
        self.h_seat  = h_seat
        self.t_ignore = t_ignore
        self.samples  = []

        for cid, grp in df.groupby("case_id"):
            grp = grp.sort_values("t").reset_index(drop=True)
            T   = len(grp)

            # ── road inputs ─────────────────────────────────
            if all(c in grp.columns for c in ROAD_COLS):
                road_raw = grp[ROAD_COLS].values.astype(np.float32)
            elif road_arr is not None:
                road_raw = road_arr[:T].astype(np.float32)
            else:
                road_raw = np.zeros((T, 6), np.float32)
            road_norm = (road_raw - norm_stats.r_mean) / norm_stats.r_std

            # ── parameters ──────────────────────────────────
            p_raw  = np.array([float(grp[k].iloc[0]) for k in PARAM_NAMES],
                               np.float32)
            p_norm = (p_raw - norm_stats.p_lo) / (norm_stats.p_hi - norm_stats.p_lo + 1e-8)

            # ── states & accels ──────────────────────────────
            s_raw = grp[STATE_NAMES].values.astype(np.float32)
            a_raw = grp[ACCEL_COLS].values.astype(np.float32)
            s_norm = (s_raw - norm_stats.s_mean) / norm_stats.s_std
            a_norm = (a_raw - norm_stats.a_mean) / norm_stats.a_std

            # ── seat RMS (physical, for loss + evaluation) ───
            t_vals = grp["t"].values
            mask   = t_vals >= t_ignore
            if mask.any():
                a_phys  = a_raw[mask, 0] + h_seat * a_raw[mask, 2]
                rms_val = float(np.sqrt(np.mean(a_phys**2)))
            else:
                rms_val = 0.0

            self.samples.append({
                "road":     torch.tensor(road_norm, dtype=torch.float32),
                "param":    torch.tensor(p_norm,    dtype=torch.float32),
                "state":    torch.tensor(s_norm,    dtype=torch.float32),
                "accel":    torch.tensor(a_norm,    dtype=torch.float32),
                "rms":      torch.tensor([rms_val], dtype=torch.float32),
                "case_id":  int(cid),
            })

    def __len__(self)  -> int:  return len(self.samples)
    def __getitem__(self, i):   return self.samples[i]


# ─────────────────────────────────────────────────────────────
# Collate  (pads variable-length sequences within a batch)
# ─────────────────────────────────────────────────────────────

def collate_pad(batch):
    """Pad road / state / accel tensors to same T in batch."""
    max_T = max(s["road"].shape[0] for s in batch)
    out   = {k: [] for k in batch[0] if k != "case_id"}
    out["case_id"] = [s["case_id"] for s in batch]

    for s in batch:
        T   = s["road"].shape[0]
        pad = max_T - T
        out["road"].append(
            torch.nn.functional.pad(s["road"],  (0, 0, 0, pad)))
        out["state"].append(
            torch.nn.functional.pad(s["state"], (0, 0, 0, pad)))
        out["accel"].append(
            torch.nn.functional.pad(s["accel"], (0, 0, 0, pad)))
        out["param"].append(s["param"])
        out["rms"].append(s["rms"])

    return {k: (torch.stack(v) if k != "case_id" else v)
            for k, v in out.items()}


# ─────────────────────────────────────────────────────────────
# Build loaders
# ─────────────────────────────────────────────────────────────

def build_loaders(
    csv_path:   str,
    norm_stats: NormStats,
    batch_size: int = TRAIN_CFG["batch_size"],
    h_seat:     float = 0.6,
    road_arr:   Optional[np.ndarray] = None,
    num_workers: int = 0,
) -> Tuple[DataLoader, DataLoader, DataLoader]:
    """
    Returns (train_loader, val_loader, test_loader).
    Train/val split is within the 'train' split rows (80/20).
    Test loader uses 'test' split rows.
    """
    # Build train dataset first to get norm stats
    train_ds = CabinDataset(csv_path, norm_stats, split="train",
                             h_seat=h_seat, road_arr=road_arr)

    # Val: random 20% of train cases held back
    n_val   = max(1, len(train_ds) // 5)
    n_train = len(train_ds) - n_val
    train_sub, val_sub = torch.utils.data.random_split(
        train_ds, [n_train, n_val],
        generator=torch.Generator().manual_seed(0)
    )

    test_ds = CabinDataset(csv_path, norm_stats, split="test",
                            h_seat=h_seat, road_arr=road_arr)

    kw = dict(collate_fn=collate_pad, num_workers=num_workers,
              pin_memory=torch.cuda.is_available())

    train_ld = DataLoader(train_sub, batch_size=batch_size,
                          shuffle=True,  **kw)
    val_ld   = DataLoader(val_sub,   batch_size=batch_size,
                          shuffle=False, **kw)
    test_ld  = DataLoader(test_ds,   batch_size=batch_size,
                          shuffle=False, **kw)

    print(f"Dataset splits:  train={n_train}  val={n_val}  "
          f"test={len(test_ds)}  cases")
    return train_ld, val_ld, test_ld
