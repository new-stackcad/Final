"""
Surrogate-based optimisation pipeline for cabin seat RMS minimisation.

Stages
------
1. Offline data generation  – run_lhs_grid()
2. Dataset & dataloader     – CabinDataset, build_loaders()
3. Surrogate model          – PhysicsLSTM (road encoder + LSTM + param MLP)
4. Physics-informed loss    – PhysicsLoss (EOM residual + Baumgarte)
5. Training loop            – train_surrogate()
6. RMS scalar emulator      – cabin_seat_rms_surrogate()
7. Bayesian optimisation    – run_bayesian_opt()
"""

from __future__ import annotations

import os, time, warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Callable

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from scipy.integrate import solve_ivp
from scipy.linalg import solve as lin_solve
from scipy.stats import qmc

# Optional: BoTorch for Bayesian optimisation
try:
    from botorch.models import SingleTaskGP
    from botorch.fit import fit_gpytorch_mll
    from botorch.acquisition import LogExpectedImprovement
    from botorch.optim import optimize_acqf
    from gpytorch.mlls import ExactMarginalLogLikelihood
    HAS_BOTORCH = True
except ImportError:
    HAS_BOTORCH = False
    warnings.warn("BoTorch not found; falling back to bayes_opt for optimisation.")

try:
    from bayes_opt import BayesianOptimization
    HAS_BAYESOPT = True
except ImportError:
    HAS_BAYESOPT = False

# ─────────────────────────────────────────────
# 0.  Constants & base config
# ─────────────────────────────────────────────

DT       = 0.004          # 250 Hz
FS       = 250
T_END    = 436.996
T_IGNORE = 0.5            # skip initial transient when computing RMS

STATE_NAMES  = ["z_c", "th_c", "ph_c", "z_s", "th_s", "ph_s"]
(ZC, THC, PHC, ZS, THS, PHS) = range(6)

PARAM_NAMES = ["K_f", "C_f", "K_2", "K_3",
               "cs_minus", "asym_ratio", "gamma_c", "gamma_r"]

BASE_CFG: Dict = {
    "axlefront_left_csv":  "front_left.csv",
    "axlefront_right_csv": "front_right.csv",
    "axlerear1_left_csv":  "rear1_left.csv",
    "axlerear1_right_csv": "rear1_right.csv",
    "axlerear2_left_csv":  "rear2_left.csv",
    "axlerear2_right_csv": "rear2_right.csv",
    "sim_duration_s": T_END,
    "WT1": 0.814, "WT2": 1.047, "WT3": 1.047,
    "a": 0.9, "b": 1.080,
    "m_s": 22485.0, "I_syy": 103787.0, "I_sxx": 8598.0, "I_sxy": 763.0,
    "M_1f": 600.0,  "M_2": 1075.0,  "M_3": 840.0,
    "I_xx1": 650.0, "I_xx2": 1200.0, "I_xx3": 1100.0,
    "lf": 5.05, "L12": 0.54, "L23": 1.96,
    "l_cf": 6.458, "l_cr": 4.5, "l_cfcg": 0.871, "l_crcg": 1.087,
    "m_c": 862.0,   "I_xxc": 516.6, "I_yyc": 1045.0,
    "hs": 0.68, "g": 9.81, "hcp": 0.1,
    "L_DL2": 0.6211, "L_DR2": 0.6211,
    "L_DL3": 0.6251, "L_DR3": 0.6251,
    "beta_L2": 0.1693, "beta_R2": 0.1693,
    "beta_L3": 0.17453, "beta_R3": 0.17453,
    "S_tf2": 1.043, "S_tf3": 1.043, "S_f": 0.814,
    "C_cfl": 5035.0, "C_cfr": 5035.0, "C_crl": 3400.0, "C_crr": 3400.0,
    "K_cfl": 49050.0, "K_cfr": 49050.0, "K_crl": 24525.0, "K_crr": 24525.0,
    "K_f": 474257, "C_f": 15000, "K_2": 1077620, "C_2": 2000,
    "K_3": 1077620, "C_3": 2000,
    "cs_minus": 0.3, "asym_ratio": 3.0, "gamma_c": 0.12, "gamma_r": 0.09,
    "k_tf": 120e3, "c_tf": 3e3,
    "k_r1": 180e3, "c_r1": 4e3,
    "k_r2": 180e3, "c_r2": 4e3,
    "baum_omega": 20.0, "baum_zeta": 1.0,
    # Cabin seat height above cabin CG (used for RMS computation)
    "h_seat": 0.6,
}

# ─────────────────────────────────────────────
# 1.  Road signals  (identical to your existing code)
# ─────────────────────────────────────────────

def load_track(csv_path: str) -> Tuple[np.ndarray, np.ndarray]:
    df = pd.read_csv(csv_path, header=None)
    t = pd.to_numeric(df.iloc[:, 0], errors="coerce").values
    z = pd.to_numeric(df.iloc[:, 1], errors="coerce").values
    mask = np.isfinite(t) & np.isfinite(z)
    return t[mask].astype(float), z[mask].astype(float)


def make_linear_interp(x: np.ndarray, y: np.ndarray) -> Callable:
    x, y = np.asarray(x), np.asarray(y)
    def f(xq):
        xq = np.asarray(xq)
        xq_c = np.clip(xq, x[0], x[-1])
        idx = np.clip(np.searchsorted(x, xq_c) - 1, 0, len(x) - 2)
        x0, x1 = x[idx], x[idx + 1]
        y0, y1 = y[idx], y[idx + 1]
        w = (xq_c - x0) / np.maximum(x1 - x0, 1e-12)
        return y0 * (1 - w) + y1 * w
    return f


@dataclass
class RoadSignals:
    f1L: Callable; f1R: Callable
    f2L: Callable; f2R: Callable
    f3L: Callable; f3R: Callable

    def axle_inputs(self, t: float, cfg: Dict):
        zr1L, zr1R = self.f1L(t), self.f1R(t)
        zr2L, zr2R = self.f2L(t), self.f2R(t)
        zr3L, zr3R = self.f3L(t), self.f3R(t)
        z1f  = 0.5 * (zr1L + zr1R)
        z2   = 0.5 * (zr2L + zr2R)
        z3   = 0.5 * (zr3L + zr3R)
        ph_f = (zr1L - zr1R) / cfg["WT1"]
        ph2  = (zr2L - zr2R) / cfg["WT2"]
        ph3  = (zr3L - zr3R) / cfg["WT3"]
        return float(z1f), float(ph_f), float(z2), float(ph2), float(z3), float(ph3)

    def axle_input_rates(self, t: float, cfg: Dict, dt: float = DT):
        p = self.axle_inputs(t + dt, cfg)
        m = self.axle_inputs(t - dt, cfg)
        return tuple((a - b) / (2 * dt) for a, b in zip(p, m))


def build_road_signals(cfg: Dict) -> RoadSignals:
    t1L, z1L = load_track(cfg["axlefront_left_csv"])
    t1R, z1R = load_track(cfg["axlefront_right_csv"])
    t2L, z2L = load_track(cfg["axlerear1_left_csv"])
    t2R, z2R = load_track(cfg["axlerear1_right_csv"])
    t3L, z3L = load_track(cfg["axlerear2_left_csv"])
    t3R, z3R = load_track(cfg["axlerear2_right_csv"])
    return RoadSignals(
        make_linear_interp(t1L, z1L), make_linear_interp(t1R, z1R),
        make_linear_interp(t2L, z2L), make_linear_interp(t2R, z2R),
        make_linear_interp(t3L, z3L), make_linear_interp(t3R, z3R),
    )


def precompute_road_array(cfg: Dict, t_eval: np.ndarray) -> np.ndarray:
    """Pre-evaluate all 6 axle signals on t_eval → float32 array [T, 6]."""
    road = build_road_signals(cfg)
    rows = []
    for t in t_eval:
        z1f, phf, z2, ph2, z3, ph3 = road.axle_inputs(t, cfg)
        rows.append([z1f, phf, z2, ph2, z3, ph3])
    return np.array(rows, dtype=np.float32)


# ─────────────────────────────────────────────
# 2.  Asymmetric damper (numpy version for ODE)
# ─────────────────────────────────────────────

def asym_damper_force_np(v_rel: float, cfg: Dict) -> float:
    """Two-stage asymmetric damper – numpy scalar version for ODE RHS."""
    cs  = cfg["cs_minus"]
    cp  = cfg["asym_ratio"] * cs
    a_c = -0.05   # compression breakpoint (m/s)
    a_r =  0.13   # rebound breakpoint (m/s)
    gc  = cfg["gamma_c"]
    gr  = cfg["gamma_r"]
    if v_rel < 0:
        if v_rel >= a_c:
            return cs * v_rel
        else:
            return cs * (a_c + gc * (v_rel - a_c))
    else:
        if v_rel <= a_r:
            return cp * v_rel
        else:
            return cp * (a_r + gr * (v_rel - a_r))


# ─────────────────────────────────────────────
# 3.  ODE RHS  (your existing physics, self-contained)
# ─────────────────────────────────────────────
# NOTE: This is a condensed but complete version.  Insert your full
# build_M_R, geom_constraints, static_equilibrium_state here if needed.
# The functions below are stubs that call your existing code.

def geom_constraints(q: np.ndarray, t: float, cfg: Dict,
                     road: RoadSignals) -> Tuple[np.ndarray, np.ndarray]:
    z_s, th_s, ph_s = q[ZS], q[THS], q[PHS]
    _, _, z2, ph2, z3, ph3 = road.axle_inputs(t, cfg)
    l2 = cfg["L12"]; l3 = cfg["L12"] + cfg["L23"]
    S2, S3 = cfg["S_tf2"], cfg["S_tf3"]
    L_DL2, L_DL3 = cfg["L_DL2"], cfg["L_DL3"]
    dDL2, dDL3   = cfg["dell_DL2"] if "dell_DL2" in cfg else 0.02, cfg.get("dell_DL3", 0.02)
    bL2, bL3     = cfg["beta_L2"], cfg["beta_L3"]
    g2 = (z_s + l2*th_s + S2*ph_s) - (L_DL2 + dDL2)*np.sin(bL2 - th_s) \
         - (z2 + 0.5*cfg["WT2"]*ph2)
    g3 = (z_s + l3*th_s + S3*ph_s) - (L_DL3 + dDL3)*np.sin(bL3 - th_s) \
         - (z3 + 0.5*cfg["WT3"]*ph3)
    G = np.zeros((2, 12), dtype=float)
    cL2 = np.cos(bL2 - th_s); cL3 = np.cos(bL3 - th_s)
    G[0, ZS] = 1.0; G[0, THS] = l2 + (L_DL2+dDL2)*cL2; G[0, PHS] = S2
    G[1, ZS] = 1.0; G[1, THS] = l3 + (L_DL3+dDL3)*cL3; G[1, PHS] = S3
    return np.array([g2, g3], dtype=float), G


def rhs_first_order(t: float, x: np.ndarray, cfg: Dict,
                    road: RoadSignals,
                    build_M_R_fn: Callable) -> np.ndarray:
    """Generic first-order ODE RHS using external build_M_R."""
    q = x[:12]; v = x[12:]
    M, R = build_M_R_fn(q, v, t, cfg, road)
    gq, G = geom_constraints(q, t, cfg, road)
    gdot  = G @ v
    w, zeta = cfg["baum_omega"], cfg["baum_zeta"]
    gamma = (w**2)*gq + 2.0*zeta*w*gdot
    nc = 2
    A = np.zeros((12+nc, 12+nc)); b_vec = np.zeros(12+nc)
    A[:12, :12] = M; A[:12, 12:] = G.T; A[12:, :12] = G
    b_vec[:12] = -R; b_vec[12:] = -gamma
    sol = lin_solve(A, b_vec)
    xdot = np.zeros_like(x)
    xdot[:12] = v; xdot[12:] = sol[:12]
    return xdot


# ─────────────────────────────────────────────
# 4.  LHS grid + data generation
# ─────────────────────────────────────────────

PARAM_BOUNDS: Dict[str, Tuple[float, float]] = {
    "K_f":       (0.7 * 474257,   1.3 * 474257),
    "C_f":       (0.5 * 15000,    2.0 * 15000),
    "K_2":       (0.7 * 1077620,  1.3 * 1077620),
    "K_3":       (0.7 * 1077620,  1.3 * 1077620),
    "cs_minus":  (0.1, 1.5),
    "asym_ratio":(1.5, 6.0),
    "gamma_c":   (0.05, 0.30),
    "gamma_r":   (0.03, 0.25),
}


def lhs_sample(n: int, seed: int = 0) -> List[Dict]:
    """Latin-hypercube sample over PARAM_BOUNDS."""
    sampler = qmc.LatinHypercube(d=len(PARAM_BOUNDS), seed=seed)
    unit    = sampler.random(n)
    lo = np.array([v[0] for v in PARAM_BOUNDS.values()])
    hi = np.array([v[1] for v in PARAM_BOUNDS.values()])
    scaled = lo + unit * (hi - lo)
    keys   = list(PARAM_BOUNDS.keys())
    return [{k: float(scaled[i, j]) for j, k in enumerate(keys)} for i in range(n)]


def compute_seat_rms(df: pd.DataFrame, cfg: Dict, t_ignore: float = T_IGNORE) -> float:
    """
    Cabin seat vertical acceleration RMS.
    a_seat ≈ qdd_z_c + h * qdd_ph_c  (small angle, seat on centreline fore-aft)
    """
    h = cfg.get("h_seat", 0.6)
    mask = df["t"] >= t_ignore
    sub  = df[mask]
    a_seat = sub["qdd_z_c"].values + h * sub["qdd_ph_c"].values
    return float(np.sqrt(np.mean(a_seat**2)))


def run_one_case(params: Dict, cfg_base: Dict,
                 build_M_R_fn: Callable,
                 static_eq_fn: Callable,
                 t_eval: np.ndarray) -> pd.DataFrame:
    """Solve the ODE for one parameter set and return a DataFrame of results."""
    cfg = {**cfg_base, **params}
    road = build_road_signals(cfg)
    x0   = static_eq_fn(cfg, road)
    rhs  = lambda t, x: rhs_first_order(t, x, cfg, road, build_M_R_fn)
    sol  = solve_ivp(rhs, (t_eval[0], t_eval[-1]), x0,
                     t_eval=t_eval, method="Radau",
                     rtol=1e-6, atol=1e-8)
    if not sol.success:
        raise RuntimeError(sol.message)
    rows = []
    for k, t in enumerate(sol.t):
        qk  = sol.y[:12, k]; qdk = sol.y[12:, k]
        M, R = build_M_R_fn(qk, qdk, t, cfg, road)
        gq, G = geom_constraints(qk, t, cfg, road)
        gamma = (cfg["baum_omega"]**2)*gq + \
                2*cfg["baum_zeta"]*cfg["baum_omega"]*(G @ qdk)
        nc = 2
        A = np.zeros((14, 14)); b_v = np.zeros(14)
        A[:12,:12]=M; A[:12,12:]=G.T; A[12:,:12]=G
        b_v[:12]=-R; b_v[12:]=-gamma
        qddk = lin_solve(A, b_v)[:12]
        row = {"t": t, **params}
        for i, n in enumerate(STATE_NAMES):
            row[n]           = float(qk[i])
            row[f"qd_{n}"]   = float(qdk[i])
            row[f"qdd_{n}"]  = float(qddk[i])
        rows.append(row)
    return pd.DataFrame(rows)


def run_lhs_grid(n_cases: int, cfg_base: Dict,
                 build_M_R_fn: Callable, static_eq_fn: Callable,
                 out_csv: str = "physics_train.csv",
                 seed: int = 42, downsample: int = 4) -> pd.DataFrame:
    """
    Generate LHS training data.
    downsample=4 → every 4th timestep stored (still 62.5 Hz, reduces file size).
    Typical: n_cases=60 gives ~60 CPU-hours on 1 core; parallelise with joblib.
    """
    t_eval = np.arange(0.0, T_END + DT, DT)
    t_ds   = t_eval[::downsample]
    param_sets = lhs_sample(n_cases, seed=seed)
    all_dfs = []
    for cid, params in enumerate(param_sets):
        print(f"Case {cid+1}/{n_cases}: {params}")
        try:
            df = run_one_case(params, cfg_base, build_M_R_fn,
                              static_eq_fn, t_ds)
            df["case_id"] = cid
            all_dfs.append(df)
        except Exception as e:
            print(f"  FAILED: {e}")
    out = pd.concat(all_dfs, ignore_index=True)
    out.to_csv(out_csv, index=False)
    print(f"Saved {out_csv}  ({len(out)} rows)")
    return out


# ─────────────────────────────────────────────
# 5.  Dataset
# ─────────────────────────────────────────────

class CabinDataset(Dataset):
    """
    Each sample is one case_id (full time series).
    Returns:
        road_seq  : [T, 6]   axle inputs (pre-normalised)
        param_vec : [8]      design parameters (normalised to [0,1])
        state_seq : [T, 6]   target states  z_c th_c ph_c z_s th_s ph_s
        accel_seq : [T, 3]   target accel   qdd_z_c qdd_th_c qdd_ph_c
        rms_scalar: [1]      cabin seat RMS (for auxiliary loss)
    """

    def __init__(self, csv_path: str, cfg: Dict,
                 road_arr: Optional[np.ndarray] = None,
                 t_eval: Optional[np.ndarray] = None,
                 split_frac: float = 0.8, split: str = "train", seed: int = 0):
        df = pd.read_csv(csv_path)
        case_ids = sorted(df["case_id"].unique())
        rng = np.random.default_rng(seed)
        rng.shuffle(case_ids)
        cut = int(len(case_ids) * split_frac)
        sel = case_ids[:cut] if split == "train" else case_ids[cut:]

        # Parameter normalisation to [0, 1]
        self.p_lo = np.array([PARAM_BOUNDS[k][0] for k in PARAM_NAMES], np.float32)
        self.p_hi = np.array([PARAM_BOUNDS[k][1] for k in PARAM_NAMES], np.float32)

        # State normalisation (running stats from training data)
        state_cols = STATE_NAMES
        accel_cols = [f"qdd_{n}" for n in STATE_NAMES[:3]]
        all_states = df[state_cols].values.astype(np.float32)
        all_accels = df[accel_cols].values.astype(np.float32)
        self.s_mean = all_states.mean(0); self.s_std = all_states.std(0) + 1e-8
        self.a_mean = all_accels.mean(0); self.a_std = all_accels.std(0) + 1e-8

        # Road signal normalisation
        road_cols = ["z_1f", "ph_f", "z_2", "ph_2", "z_3", "ph_3"]
        if all(c in df.columns for c in road_cols):
            all_road = df[road_cols].values.astype(np.float32)
        else:
            # fall back: pre-compute road signals once (same for all cases)
            all_road = road_arr if road_arr is not None else None
        if all_road is not None:
            self.r_mean = all_road.mean(0); self.r_std = all_road.std(0) + 1e-8
        else:
            self.r_mean = np.zeros(6, np.float32)
            self.r_std  = np.ones(6,  np.float32)

        self.samples = []
        h = cfg.get("h_seat", 0.6)
        for cid in sel:
            sub  = df[df["case_id"] == cid].sort_values("t")
            T    = len(sub)

            # Road inputs
            if all(c in sub.columns for c in road_cols):
                road_seq = sub[road_cols].values.astype(np.float32)
            elif road_arr is not None and t_eval is not None:
                road_seq = road_arr[:T]   # assumes same t_eval grid
            else:
                road_seq = np.zeros((T, 6), np.float32)
            road_norm = (road_seq - self.r_mean) / self.r_std

            # Parameters
            p_raw  = np.array([sub[k].iloc[0] for k in PARAM_NAMES], np.float32)
            p_norm = (p_raw - self.p_lo) / (self.p_hi - self.p_lo + 1e-8)

            # States & accels
            states = sub[state_cols].values.astype(np.float32)
            accels = sub[accel_cols].values.astype(np.float32)
            s_norm = (states - self.s_mean) / self.s_std
            a_norm = (accels - self.a_mean) / self.a_std

            # Seat RMS (in physical units for the scalar loss)
            mask     = sub["t"].values >= T_IGNORE
            a_seat   = accels[mask, 0] + h * accels[mask, 2]  # z_c + h*ph_c
            rms      = np.sqrt(np.mean(a_seat**2)) if mask.any() else 0.0

            self.samples.append({
                "road":  torch.tensor(road_norm,  dtype=torch.float32),  # [T,6]
                "param": torch.tensor(p_norm,     dtype=torch.float32),  # [8]
                "state": torch.tensor(s_norm,     dtype=torch.float32),  # [T,6]
                "accel": torch.tensor(a_norm,     dtype=torch.float32),  # [T,3]
                "rms":   torch.tensor([rms],      dtype=torch.float32),  # [1]
            })

    def __len__(self): return len(self.samples)
    def __getitem__(self, i): return self.samples[i]


def collate_pad(batch):
    """Pad variable-length sequences to the same T within a batch."""
    max_T = max(s["road"].shape[0] for s in batch)
    out = {k: [] for k in batch[0]}
    for s in batch:
        T = s["road"].shape[0]
        pad = max_T - T
        out["road"].append(torch.nn.functional.pad(s["road"], (0,0,0,pad)))
        out["state"].append(torch.nn.functional.pad(s["state"],(0,0,0,pad)))
        out["accel"].append(torch.nn.functional.pad(s["accel"],(0,0,0,pad)))
        out["param"].append(s["param"])
        out["rms"].append(s["rms"])
    return {k: torch.stack(v) for k, v in out.items()}


def build_loaders(csv_path: str, cfg: Dict,
                  batch_size: int = 8,
                  road_arr: Optional[np.ndarray] = None) -> Tuple[DataLoader, DataLoader]:
    train_ds = CabinDataset(csv_path, cfg, road_arr=road_arr, split="train")
    val_ds   = CabinDataset(csv_path, cfg, road_arr=road_arr,
                            s_mean=train_ds.s_mean, s_std=train_ds.s_std,
                            a_mean=train_ds.a_mean, a_std=train_ds.a_std,
                            r_mean=train_ds.r_mean, r_std=train_ds.r_std,
                            split="val")
    # NOTE: CabinDataset above doesn't accept these as args; see extended version below.
    train_ld = DataLoader(train_ds, batch_size=batch_size, shuffle=True,
                          collate_fn=collate_pad)
    val_ld   = DataLoader(val_ds,   batch_size=batch_size, shuffle=False,
                          collate_fn=collate_pad)
    return train_ld, val_ld


# ─────────────────────────────────────────────
# 6.  Surrogate model
# ─────────────────────────────────────────────

class RoadCNNEncoder(nn.Module):
    """
    Lightweight 1-D CNN that maps road signals [B, T, 6] → [B, T, road_dim].
    Using causal convolutions so no future leakage.
    """
    def __init__(self, in_ch: int = 6, out_dim: int = 32, layers: int = 3):
        super().__init__()
        chs = [in_ch] + [64] * (layers - 1) + [out_dim]
        convs = []
        for i in range(layers):
            k = 5              # kernel size
            pad = k - 1        # causal: pad left only
            convs += [
                nn.ConstantPad1d((pad, 0), 0.0),
                nn.Conv1d(chs[i], chs[i+1], kernel_size=k, padding=0),
                nn.GELU(),
            ]
        self.net = nn.Sequential(*convs)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, T, 6]  → transpose to [B, 6, T] for Conv1d
        y = self.net(x.transpose(1, 2))   # [B, road_dim, T]
        return y.transpose(1, 2)           # [B, T, road_dim]


class ParamMLP(nn.Module):
    """Embeds the 8 design parameters → condition vector used in LSTM."""
    def __init__(self, n_params: int = 8, hidden: int = 64, out_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(n_params, hidden), nn.GELU(),
            nn.Linear(hidden, hidden),   nn.GELU(),
            nn.Linear(hidden, out_dim),
        )

    def forward(self, p: torch.Tensor) -> torch.Tensor:
        return self.net(p)  # [B, out_dim]


class PhysicsLSTM(nn.Module):
    """
    Parameter-conditioned LSTM surrogate.

    Architecture
    ────────────
    road_seq [B,T,6]  →  CNN encoder  →  [B,T,32]
                                            ↓  concat  ←  param embedding [B,128]
                                         [B,T,160]
                                            ↓  LSTM (2 layers, hidden=256)
                                         [B,T,256]
                                            ↓  Linear head
                         state_pred [B,T,6]   accel_pred [B,T,3]

    The param embedding is used to initialise the LSTM hidden state AND
    is concatenated to the road features at every timestep (FiLM-style).
    """

    def __init__(self,
                 road_dim:   int = 32,
                 param_dim:  int = 128,
                 lstm_hidden: int = 256,
                 lstm_layers: int = 2,
                 n_states:   int = 6,
                 n_accels:   int = 3,
                 dropout:    float = 0.1):
        super().__init__()
        self.road_enc   = RoadCNNEncoder(in_ch=6, out_dim=road_dim)
        self.param_mlp  = ParamMLP(n_params=8, hidden=64, out_dim=param_dim)

        lstm_in = road_dim + param_dim
        self.lstm = nn.LSTM(lstm_in, lstm_hidden, lstm_layers,
                            batch_first=True, dropout=dropout)

        # Initialise LSTM (h0, c0) from param embedding
        self.h0_proj = nn.Linear(param_dim, lstm_hidden * lstm_layers)
        self.c0_proj = nn.Linear(param_dim, lstm_hidden * lstm_layers)

        self.state_head = nn.Sequential(
            nn.Linear(lstm_hidden, 64), nn.GELU(),
            nn.Linear(64, n_states),
        )
        self.accel_head = nn.Sequential(
            nn.Linear(lstm_hidden, 64), nn.GELU(),
            nn.Linear(64, n_accels),
        )

        self.lstm_hidden = lstm_hidden
        self.lstm_layers = lstm_layers

    def forward(self, road: torch.Tensor,
                param: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        road  : [B, T, 6]
        param : [B, 8]
        returns state_pred [B,T,6], accel_pred [B,T,3]
        """
        B = road.shape[0]

        # Encode road
        road_feat = self.road_enc(road)                 # [B, T, road_dim]

        # Encode params
        p_emb = self.param_mlp(param)                   # [B, param_dim]

        # Broadcast param embedding across time
        p_exp = p_emb.unsqueeze(1).expand(-1, road.shape[1], -1)  # [B, T, param_dim]

        # Concatenate road + param → LSTM input
        lstm_in = torch.cat([road_feat, p_exp], dim=-1) # [B, T, road_dim+param_dim]

        # Initialise hidden states from param embedding
        h0 = self.h0_proj(p_emb).view(B, self.lstm_layers, self.lstm_hidden)
        c0 = self.c0_proj(p_emb).view(B, self.lstm_layers, self.lstm_hidden)
        h0 = h0.permute(1, 0, 2).contiguous()
        c0 = c0.permute(1, 0, 2).contiguous()

        lstm_out, _ = self.lstm(lstm_in, (h0, c0))      # [B, T, hidden]

        state_pred = self.state_head(lstm_out)           # [B, T, 6]
        accel_pred = self.accel_head(lstm_out)           # [B, T, 3]
        return state_pred, accel_pred


# ─────────────────────────────────────────────
# 7.  Physics-informed loss
# ─────────────────────────────────────────────

class PhysicsLoss(nn.Module):
    """
    Combined loss:
      L = λ_s·MSE(state) + λ_a·MSE(accel) + λ_r·MSE(rms) + λ_p·physics_residual

    physics_residual: simplified EOM term that penalises unphysical oscillations.
    Uses finite-difference acceleration from predicted states as a proxy.
    """

    def __init__(self,
                 lambda_state: float = 1.0,
                 lambda_accel: float = 2.0,
                 lambda_rms:   float = 5.0,
                 lambda_phys:  float = 0.1):
        super().__init__()
        self.ls = lambda_state
        self.la = lambda_accel
        self.lr = lambda_rms
        self.lp = lambda_phys

    def forward(self,
                state_pred: torch.Tensor,  # [B, T, 6]
                accel_pred: torch.Tensor,  # [B, T, 3]
                state_true: torch.Tensor,  # [B, T, 6]
                accel_true: torch.Tensor,  # [B, T, 3]
                rms_true:   torch.Tensor,  # [B, 1]
                param:      torch.Tensor,  # [B, 8]  (normalised)
                h_seat:     float = 0.6,
                dt:         float = DT) -> Tuple[torch.Tensor, Dict]:

        # State and accel MSE
        l_state = nn.functional.mse_loss(state_pred, state_true)
        l_accel = nn.functional.mse_loss(accel_pred, accel_true)

        # RMS loss: predicted RMS vs true RMS
        # cabin seat accel ≈ qdd_z_c + h * qdd_ph_c  (index 0 and 2)
        a_seat_pred = accel_pred[..., 0] + h_seat * accel_pred[..., 2]
        rms_pred    = torch.sqrt((a_seat_pred**2).mean(dim=1, keepdim=True) + 1e-8)
        l_rms       = nn.functional.mse_loss(rms_pred, rms_true)

        # Physics residual: finite-difference acceleration from predicted state
        # vs. directly predicted acceleration (consistency check)
        if state_pred.shape[1] > 2:
            # FD second derivative of bounce (z_c, index 0)
            q_zc   = state_pred[:, :, 0]                    # [B, T]
            fd_acc = (q_zc[:, 2:] - 2*q_zc[:, 1:-1] + q_zc[:, :-2]) / (dt**2)
            pred_acc_inner = accel_pred[:, 1:-1, 0]         # [B, T-2]
            l_phys = nn.functional.mse_loss(fd_acc, pred_acc_inner)
        else:
            l_phys = torch.tensor(0.0, device=state_pred.device)

        total = (self.ls * l_state + self.la * l_accel +
                 self.lr * l_rms   + self.lp * l_phys)

        metrics = {
            "loss_state": l_state.item(),
            "loss_accel": l_accel.item(),
            "loss_rms":   l_rms.item(),
            "loss_phys":  l_phys.item(),
            "loss_total": total.item(),
        }
        return total, metrics


# ─────────────────────────────────────────────
# 8.  Training loop
# ─────────────────────────────────────────────

def train_surrogate(model: PhysicsLSTM,
                    train_loader: DataLoader,
                    val_loader:   DataLoader,
                    cfg_train: Dict,
                    save_path: str = "surrogate_best.pt") -> PhysicsLSTM:
    """
    cfg_train keys:
      epochs, lr, weight_decay, patience, device,
      lambda_state, lambda_accel, lambda_rms, lambda_phys, h_seat
    """
    device   = cfg_train.get("device", "cpu")
    epochs   = cfg_train.get("epochs",   120)
    lr       = cfg_train.get("lr",       3e-4)
    patience = cfg_train.get("patience", 20)
    h_seat   = cfg_train.get("h_seat",   0.6)

    model  = model.to(device)
    opt    = torch.optim.AdamW(model.parameters(), lr=lr,
                                weight_decay=cfg_train.get("weight_decay", 1e-5))
    sched  = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs, eta_min=1e-6)
    crit   = PhysicsLoss(
        lambda_state=cfg_train.get("lambda_state", 1.0),
        lambda_accel=cfg_train.get("lambda_accel", 2.0),
        lambda_rms=cfg_train.get("lambda_rms",   5.0),
        lambda_phys=cfg_train.get("lambda_phys", 0.1),
    )

    best_val = float("inf"); no_improve = 0
    history  = []

    for ep in range(1, epochs + 1):
        # ── train ──
        model.train(); tr_metrics: List[Dict] = []
        for batch in train_loader:
            road  = batch["road"].to(device)
            param = batch["param"].to(device)
            state = batch["state"].to(device)
            accel = batch["accel"].to(device)
            rms   = batch["rms"].to(device)

            sp, ap = model(road, param)
            loss, m = crit(sp, ap, state, accel, rms, param, h_seat)

            opt.zero_grad(); loss.backward(); 
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            tr_metrics.append(m)

        # ── validate ──
        model.eval(); vl_metrics: List[Dict] = []
        with torch.no_grad():
            for batch in val_loader:
                road  = batch["road"].to(device)
                param = batch["param"].to(device)
                state = batch["state"].to(device)
                accel = batch["accel"].to(device)
                rms   = batch["rms"].to(device)
                sp, ap = model(road, param)
                _, m = crit(sp, ap, state, accel, rms, param, h_seat)
                vl_metrics.append(m)

        def mean_m(ms): return {k: np.mean([d[k] for d in ms]) for k in ms[0]}
        tr_m = mean_m(tr_metrics); vl_m = mean_m(vl_metrics)
        sched.step()

        val_loss = vl_m["loss_total"]
        if val_loss < best_val:
            best_val = val_loss; no_improve = 0
            torch.save({"model": model.state_dict(),
                        "epoch": ep, "val_loss": best_val}, save_path)
        else:
            no_improve += 1

        history.append({"ep": ep, **{f"tr_{k}": v for k, v in tr_m.items()},
                                    **{f"vl_{k}": v for k, v in vl_m.items()}})
        if ep % 10 == 0 or ep == 1:
            print(f"Ep {ep:4d}  tr={tr_m['loss_total']:.4e}  "
                  f"vl={vl_m['loss_total']:.4e}  "
                  f"rms_vl={vl_m['loss_rms']:.4e}  "
                  f"lr={sched.get_last_lr()[0]:.2e}")

        if no_improve >= patience:
            print(f"Early stop at epoch {ep}  (best val={best_val:.4e})")
            break

    # Load best weights
    ckpt = torch.load(save_path, map_location=device)
    model.load_state_dict(ckpt["model"])
    pd.DataFrame(history).to_csv("training_history.csv", index=False)
    return model


# ─────────────────────────────────────────────
# 9.  RMS scalar emulator  (used inside optimiser)
# ─────────────────────────────────────────────

class RMSEmulator:
    """
    Wraps the trained PhysicsLSTM to expose a fast scalar RMS function.
    The road tensor is cached – only the parameter vector changes during optimisation.
    """

    def __init__(self,
                 model: PhysicsLSTM,
                 road_arr: np.ndarray,      # [T, 6] normalised road signals
                 dataset:  CabinDataset,    # used for normalisation stats
                 cfg:      Dict,
                 device:   str = "cpu"):
        self.model   = model.eval().to(device)
        self.device  = device
        self.cfg     = cfg
        self.h_seat  = cfg.get("h_seat", 0.6)
        self.p_lo    = dataset.p_lo
        self.p_hi    = dataset.p_hi
        self.a_std   = dataset.a_std
        self.a_mean  = dataset.a_mean

        road_t = torch.tensor(road_arr, dtype=torch.float32, device=device).unsqueeze(0)
        self.road_t = road_t    # [1, T, 6]

    @torch.no_grad()
    def __call__(self, params: Dict) -> float:
        """params: dict with keys = PARAM_NAMES, physical units."""
        p_raw  = np.array([params[k] for k in PARAM_NAMES], np.float32)
        p_norm = (p_raw - self.p_lo) / (self.p_hi - self.p_lo + 1e-8)
        p_t    = torch.tensor(p_norm, dtype=torch.float32,
                               device=self.device).unsqueeze(0)  # [1, 8]

        _, accel_pred = self.model(self.road_t, p_t)   # [1, T, 3]
        # denormalise
        ap = (accel_pred[0].cpu().numpy() * self.a_std + self.a_mean)  # [T, 3]
        a_seat = ap[:, 0] + self.h_seat * ap[:, 2]

        # skip transient
        n_skip = int(T_IGNORE / DT)
        return float(np.sqrt(np.mean(a_seat[n_skip:]**2)))


# ─────────────────────────────────────────────
# 10. Bayesian optimisation
# ─────────────────────────────────────────────

def run_bayesian_opt_botorch(emulator: RMSEmulator,
                              n_init:   int = 10,
                              n_iter:   int = 50,
                              seed:     int = 0) -> Dict:
    """
    BoTorch-based Bayesian optimisation over PARAM_BOUNDS.
    Uses a GP with Matern-5/2 kernel + Log-Expected Improvement.
    Returns best_params dict and best_rms value.
    """
    if not HAS_BOTORCH:
        raise ImportError("BoTorch required.  pip install botorch")

    torch.manual_seed(seed)
    dim = len(PARAM_NAMES)

    bounds = torch.zeros(2, dim, dtype=torch.double)
    for j, k in enumerate(PARAM_NAMES):
        bounds[0, j] = 0.0   # normalised lower
        bounds[1, j] = 1.0   # normalised upper

    def f_norm(p_norm_np: np.ndarray) -> float:
        """Evaluate emulator from normalised param vector."""
        p_phys = {k: float(emulator.p_lo[j] + p_norm_np[j] *
                            (emulator.p_hi[j] - emulator.p_lo[j]))
                  for j, k in enumerate(PARAM_NAMES)}
        return emulator(p_phys)

    # Initial Sobol sample
    sobol = qmc.Sobol(d=dim, scramble=True, seed=seed)
    X0    = sobol.random(n_init).astype(np.float64)
    Y0    = np.array([[f_norm(x)] for x in X0])
    print(f"Initial {n_init} samples: RMS in [{Y0.min():.4f}, {Y0.max():.4f}]")

    train_X = torch.tensor(X0, dtype=torch.double)
    train_Y = torch.tensor(-Y0, dtype=torch.double)  # negate: maximise −RMS

    best_rms = Y0.min(); best_x = X0[Y0.argmin()]

    for it in range(n_iter):
        gp  = SingleTaskGP(train_X, train_Y)
        mll = ExactMarginalLogLikelihood(gp.likelihood, gp)
        fit_gpytorch_mll(mll)

        acqf  = LogExpectedImprovement(gp, best_f=train_Y.max())
        cand, _ = optimize_acqf(acqf, bounds=bounds, q=1,
                                 num_restarts=10, raw_samples=256)
        x_new = cand[0].detach().numpy().astype(np.float64)
        y_new = f_norm(x_new)
        print(f"  iter {it+1:3d}  RMS={y_new:.5f}  best={min(best_rms,y_new):.5f}")

        train_X = torch.cat([train_X, cand.double()])
        train_Y = torch.cat([train_Y, torch.tensor([[-y_new]], dtype=torch.double)])

        if y_new < best_rms:
            best_rms = y_new; best_x = x_new

    best_params = {k: float(emulator.p_lo[j] + best_x[j] *
                             (emulator.p_hi[j] - emulator.p_lo[j]))
                   for j, k in enumerate(PARAM_NAMES)}
    print("\n=== Optimal parameters ===")
    for k, v in best_params.items():
        print(f"  {k:15s} = {v:.4f}")
    print(f"  cabin seat RMS = {best_rms:.5f} m/s²")
    return {"params": best_params, "rms": best_rms}


def run_bayesian_opt_fallback(emulator: RMSEmulator,
                               n_init: int = 5,
                               n_iter: int = 30,
                               seed:   int = 0) -> Dict:
    """Fallback using bayes_opt if BoTorch is unavailable."""
    if not HAS_BAYESOPT:
        raise ImportError("pip install bayesian-optimization")

    def objective(**kwargs):
        p_norm = np.array([kwargs[k] for k in PARAM_NAMES], np.float32)
        p_phys = {k: float(emulator.p_lo[j] + p_norm[j] *
                            (emulator.p_hi[j] - emulator.p_lo[j]))
                  for j, k in enumerate(PARAM_NAMES)}
        return -emulator(p_phys)

    pbounds = {k: (0.0, 1.0) for k in PARAM_NAMES}
    opt = BayesianOptimization(f=objective, pbounds=pbounds,
                                random_state=seed, verbose=2)
    opt.maximize(init_points=n_init, n_iter=n_iter)
    best_norm = opt.max["params"]
    best_params = {k: float(emulator.p_lo[j] + best_norm[k] *
                             (emulator.p_hi[j] - emulator.p_lo[j]))
                   for j, k in enumerate(PARAM_NAMES)}
    best_rms = -opt.max["target"]
    return {"params": best_params, "rms": best_rms}


# ─────────────────────────────────────────────
# 11.  Normalisation stats helper (for saved models)
# ─────────────────────────────────────────────

@dataclass
class NormStats:
    r_mean: np.ndarray; r_std:  np.ndarray
    s_mean: np.ndarray; s_std:  np.ndarray
    a_mean: np.ndarray; a_std:  np.ndarray
    p_lo:   np.ndarray; p_hi:   np.ndarray

    def save(self, path: str):
        np.savez(path, r_mean=self.r_mean, r_std=self.r_std,
                 s_mean=self.s_mean, s_std=self.s_std,
                 a_mean=self.a_mean, a_std=self.a_std,
                 p_lo=self.p_lo,     p_hi=self.p_hi)

    @staticmethod
    def load(path: str) -> "NormStats":
        d = np.load(path)
        return NormStats(**{k: d[k] for k in d.files})


# ─────────────────────────────────────────────
# 12.  End-to-end entry point
# ─────────────────────────────────────────────

def main(build_M_R_fn: Callable, static_eq_fn: Callable,
         mode: str = "train",
         n_cases: int = 80,
         train_csv: str = "physics_train.csv",
         model_path: str = "surrogate_best.pt"):
    """
    mode='generate' : run LHS grid to produce training CSV
    mode='train'    : train the surrogate on existing CSV
    mode='optimise' : load trained model and run Bayesian optimisation
    mode='all'      : generate + train + optimise
    """
    device = "cuda" if torch.cuda.is_available() else "cpu"
    cfg    = BASE_CFG.copy()

    t_eval = np.arange(0.0, T_END + DT, DT)

    if mode in ("generate", "all"):
        print("=== Generating LHS training data ===")
        run_lhs_grid(n_cases, cfg, build_M_R_fn, static_eq_fn,
                     out_csv=train_csv, seed=42, downsample=4)

    if mode in ("train", "all"):
        print("=== Building dataset ===")
        # Pre-compute road signals (same road for all cases)
        road_arr = precompute_road_array(cfg, t_eval[::4])
        r_mean   = road_arr.mean(0); r_std = road_arr.std(0) + 1e-8
        road_norm = (road_arr - r_mean) / r_std

        train_ds = CabinDataset(train_csv, cfg, road_arr=road_norm, split="train")
        val_ds   = CabinDataset(train_csv, cfg, road_arr=road_norm, split="val")
        train_ld = DataLoader(train_ds, batch_size=4, shuffle=True,
                              collate_fn=collate_pad, num_workers=0)
        val_ld   = DataLoader(val_ds,   batch_size=4, shuffle=False,
                              collate_fn=collate_pad, num_workers=0)

        # Save norm stats
        ns = NormStats(r_mean=train_ds.r_mean, r_std=train_ds.r_std,
                       s_mean=train_ds.s_mean, s_std=train_ds.s_std,
                       a_mean=train_ds.a_mean, a_std=train_ds.a_std,
                       p_lo=train_ds.p_lo,     p_hi=train_ds.p_hi)
        ns.save("norm_stats.npz")

        model = PhysicsLSTM(road_dim=32, param_dim=128,
                            lstm_hidden=256, lstm_layers=2, dropout=0.1)
        cfg_train = {
            "device": device, "epochs": 150, "lr": 3e-4,
            "weight_decay": 1e-5, "patience": 25,
            "lambda_state": 1.0, "lambda_accel": 2.0,
            "lambda_rms": 5.0,   "lambda_phys":  0.05,
            "h_seat": cfg["h_seat"],
        }
        print(f"=== Training on {device} ===")
        model = train_surrogate(model, train_ld, val_ld, cfg_train, model_path)

    if mode in ("optimise", "all"):
        print("=== Loading model for optimisation ===")
        ns     = NormStats.load("norm_stats.npz")
        model  = PhysicsLSTM(road_dim=32, param_dim=128,
                             lstm_hidden=256, lstm_layers=2, dropout=0.1)
        ckpt   = torch.load(model_path, map_location=device)
        model.load_state_dict(ckpt["model"])

        # Road signals (full resolution for emulator)
        road_arr  = precompute_road_array(cfg, t_eval)
        road_norm = (road_arr - ns.r_mean) / ns.r_std

        # Dummy dataset for stats (or load from saved norm_stats)
        class _FakeDS:
            p_lo = ns.p_lo; p_hi = ns.p_hi
            a_std = ns.a_std; a_mean = ns.a_mean
        emulator = RMSEmulator(model, road_norm, _FakeDS(), cfg, device=device)

        print("=== Running Bayesian optimisation ===")
        if HAS_BOTORCH:
            result = run_bayesian_opt_botorch(emulator, n_init=10, n_iter=60)
        else:
            result = run_bayesian_opt_fallback(emulator, n_init=5, n_iter=30)

        pd.DataFrame([result["params"]]).assign(rms=result["rms"]).to_csv(
            "optimal_params.csv", index=False)
        print("Saved optimal_params.csv")
        return result


if __name__ == "__main__":
    # Plug in your existing build_M_R and static_equilibrium_state here:
    # from your_ode_module import build_M_R, static_equilibrium_state
    # main(build_M_R, static_equilibrium_state, mode="all", n_cases=80)
    print("Import and call main() with your build_M_R and static_equilibrium_state.")
