# Cabin Seat RMS Surrogate – Complete Guide

## What this does

Replaces expensive Radau ODE solves (~5–15 min each) with a fast
neural surrogate (~5 ms per call), then uses Bayesian optimisation
to find suspension parameters that **minimise cabin seat vertical
acceleration RMS**.

**Optimised parameters:**
`K_f`, `C_f`, `K_2`, `K_3` – front/rear spring & damper rates  
`cs_minus`, `asym_ratio`, `gamma_c`, `gamma_r` – asymmetric 2-stage damper

---

## File layout

```
cabin_surrogate/
├── run_all.py              ← single entry point
├── requirements.txt
├── data/                   ← put your 6 road CSVs here
│   ├── front_left.csv
│   ├── front_right.csv
│   ├── rear1_left.csv
│   ├── rear1_right.csv
│   ├── rear2_left.csv
│   └── rear2_right.csv
├── src/
│   ├── config.py           ← ALL tunable constants live here
│   ├── physics.py          ← ODE, asymmetric damper, static eq.
│   ├── data_gen.py         ← LHS sampling + parallel generation
│   ├── dataset.py          ← PyTorch dataset + normalisation
│   ├── model.py            ← PhysicsLSTM architecture + loss
│   ├── train.py            ← training loop
│   ├── evaluate.py         ← test-set evaluation + plots
│   └── optimise.py         ← Bayesian optimisation
├── checkpoints/            ← created automatically
│   ├── best.pt             ← best model weights
│   ├── norm_stats.npz      ← normalisation statistics
│   └── history.csv         ← training loss history
└── outputs/
    ├── eval/               ← evaluation results
    │   ├── rms_parity.png
    │   ├── test_case_metrics.csv
    │   ├── test_predictions.csv
    │   └── plots/case_*.png
    └── opt/                ← optimisation results
        ├── optimal_params.json
        ├── param_comparison.csv
        └── bo_history.csv
```

---

## Step 0: Install dependencies

```bash
# Create environment (recommended)
conda create -n cabin_surr python=3.11
conda activate cabin_surr

# Install packages
pip install -r requirements.txt

# GPU (optional but ~5× faster training):
pip install torch --index-url https://download.pytorch.org/whl/cu121
```

---

## Step 1: Prepare your road CSVs

Each CSV must be **2 columns, no header**: `time_s, displacement_m`

```
0.000,  0.000
0.004,  0.0001
0.008, -0.0002
...
```

Place all 6 files in `data/`:
- `data/front_left.csv`
- `data/front_right.csv`
- `data/rear1_left.csv`
- `data/rear1_right.csv`
- `data/rear2_left.csv`
- `data/rear2_right.csv`

**Check your vehicle parameters** in `src/config.py` (mass, geometry, etc.)
before generating data.

---

## Step 2: Quick smoke-test (< 5 minutes)

Before committing to the full run, verify everything works:

```bash
python run_all.py --data_dir data/ --mode all --smoke_test
```

This runs 2 ODE cases + 5 training epochs. If it completes without error,
your setup is correct.

---

## Step 3: Generate ODE training data

### Serial (simplest, no extra setup):
```bash
python run_all.py --data_dir data/ --mode generate --n_cases 80
```

### Parallel (RECOMMENDED – much faster):
```bash
# Use all available CPU cores:
python run_all.py --data_dir data/ --mode generate --n_cases 80 --n_jobs -1

# Or specify number of cores explicitly:
python run_all.py --data_dir data/ --mode generate --n_cases 80 --n_jobs 8
```

**How parallelism works:**  
joblib distributes each ODE case to a separate CPU process.
With 8 cores and 80 cases at ~10 min/case:
- Serial:   ~13 hours
- 8 cores:  ~1.5 hours
- 16 cores: ~50 minutes

**How many cases do you need?**
- Minimum: 40 (poor generalisation)
- Recommended: 80–120 (good for 8 params)
- Better: 200+ (excellent accuracy)

Each case generates ~7,000 timesteps at 62.5 Hz.
80 cases ≈ 15 MB CSV.

**Output:** `data/physics_train.csv` (80% train, 20% test by case)

---

## Step 4: Train the surrogate

```bash
python run_all.py --data_dir data/ --mode train
```

**What to expect:**
- ~30–60 s/epoch on CPU with batch_size=4
- ~5–10 s/epoch on GPU
- Early stopping at ~80–120 epochs typically
- Watch `vl_loss_rms` – this directly predicts your objective quality

**Resume after interruption:**
```bash
python run_all.py --data_dir data/ --mode train --resume checkpoints/best.pt
```

**Tune if needed** – edit `src/config.py` → `TRAIN_CFG`:
- `epochs`: increase to 200 if not converged
- `lr`: reduce to 1e-4 if loss oscillates
- `lambda_rms`: increase to 10.0 to prioritise RMS accuracy
- `lstm_hidden`: increase to 512 for more capacity (needs more data)

---

## Step 5: Evaluate on test set

```bash
python run_all.py --data_dir data/ --mode evaluate
```

**What to check in `outputs/eval/`:**

| File | What to look for |
|---|---|
| `rms_parity.png` | Points should lie near the diagonal |
| `test_case_metrics.csv` | `rms_rel_err` should be < 5% |
| `plots/case_*.png` | Time-series should track ODE output |

**Acceptance criteria (industry typical):**
- RMS relative error < 5% → good surrogate
- RMS relative error < 2% → excellent
- Pearson correlation > 0.95 → time-series tracking is good

If accuracy is poor:
1. Generate more ODE cases (try 150+)
2. Increase `lstm_hidden` to 512 in `config.py`
3. Increase `lambda_rms` to 10 in `TRAIN_CFG`

---

## Step 6: Run Bayesian optimisation

```bash
python run_all.py --data_dir data/ --mode optimise
```

**Optional: verify the optimal with a full ODE solve:**
```bash
python run_all.py --data_dir data/ --mode optimise --verify_ode
```

This takes ~10 minutes but confirms the surrogate prediction is real.

**Output:** `outputs/opt/optimal_params.json` + `param_comparison.csv`

---

## Step 7: Run everything at once

```bash
python run_all.py --data_dir data/ --mode all --n_cases 80 --n_jobs 8 --verify_ode
```

---

## Understanding the outputs

### `checkpoints/history.csv`
Training curves. Plot `tr_loss_total` and `vl_loss_total` to check for
overfitting (val >> train = overfit; both high = underfit).

### `outputs/eval/test_case_metrics.csv`
Key columns:
- `rms_true`: ground-truth seat RMS from ODE [m/s²]
- `rms_pred`: surrogate prediction [m/s²]
- `rms_rel_err`: |pred-true|/true – your surrogate quality metric
- `corr_aseat`: Pearson correlation of seat acceleration time-series

### `outputs/opt/optimal_params.json`
```json
{
  "nominal_params":   { "K_f": 474257, ... },
  "optimal_params":   { "K_f": 412345, ... },
  "rms_nominal":      0.28431,
  "rms_surrogate":    0.21847,
  "rms_ode_verify":   0.22103,
  "rms_reduction_%":  23.2
}
```

### `outputs/opt/bo_history.csv`
All BO iterations. Plot column `rms` vs row index to see convergence.

---

## Parallelisation options

### Option A: joblib (built-in, recommended for single machine)
```bash
python run_all.py --data_dir data/ --mode generate --n_cases 80 --n_jobs -1
```
`-1` uses all available cores.

### Option B: Run cases manually in parallel (for clusters/HPC)
```bash
# Split into 4 batches of 20:
python src/data_gen.py --n_cases 20 --seed 0  --out data/batch0.csv &
python src/data_gen.py --n_cases 20 --seed 20 --out data/batch1.csv &
python src/data_gen.py --n_cases 20 --seed 40 --out data/batch2.csv &
python src/data_gen.py --n_cases 20 --seed 60 --out data/batch3.csv &
wait

# Merge:
python -c "
import pandas as pd, glob
dfs = [pd.read_csv(f) for f in sorted(glob.glob('data/batch*.csv'))]
for i, df in enumerate(dfs):
    df['case_id'] += i * 20
import numpy as np; rng = np.random.default_rng(42)
ids = list(range(sum(len(d['case_id'].unique()) for d in dfs)))
rng.shuffle(ids)
cut = int(0.8 * len(ids)); train_ids = set(ids[:cut])
all_df = pd.concat(dfs, ignore_index=True)
all_df['split'] = all_df['case_id'].map(lambda x: 'train' if x in train_ids else 'test')
all_df.to_csv('data/physics_train.csv', index=False)
print('Merged', len(all_df), 'rows')
"
```

---

## Troubleshooting

**"No module named config"**  
Run from the `cabin_surrogate/` directory, not from `src/`.

**"FileNotFoundError: data/front_left.csv"**  
Check your `--data_dir` path and that all 6 CSV files exist.

**ODE solver fails / returns None**  
- Check that your CSVs cover the full simulation time (0 → 437 s)
- Check vehicle parameter values in `config.py`
- Try reducing `rtol` / `atol` in `physics.py` → `run_one_case()`

**Training loss NaN**  
- Reduce `lr` in `TRAIN_CFG` (try 1e-4)
- Check that your road CSVs don't contain NaN values

**Surrogate RMS error > 10%**  
- Generate more ODE cases (80+ strongly recommended)
- Increase `lstm_hidden` to 512 in `config.py`
- Increase `lambda_rms` to 10.0

**BoTorch not found**  
```bash
pip install botorch
```
The pipeline automatically falls back to `bayesian-optimization` if
BoTorch is unavailable.

---

## Modifying parameter bounds

Edit `PARAM_BOUNDS` in `src/config.py`:
```python
PARAM_BOUNDS: Dict[str, Tuple[float, float]] = {
    "K_f":        (330000, 620000),   # tighter range if you know feasible region
    "C_f":        (7500,   30000),
    ...
}
```
**Important:** regenerate training data after changing bounds, since the
LHS sample covers the bounds space.
