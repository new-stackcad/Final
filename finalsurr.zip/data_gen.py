"""
data_gen.py  –  LHS grid data generation (parallelised with joblib).

Usage
-----
# From project root:
python src/data_gen.py --n_cases 80 --n_jobs 8 --seed 42 --out data/physics_train.csv

# Quick smoke-test (2 cases, no parallelism):
python src/data_gen.py --n_cases 2 --n_jobs 1 --out data/physics_train.csv
"""

from __future__ import annotations

import argparse
import os
import sys
import time
import traceback
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
from scipy.stats import qmc

# Make src/ importable regardless of working directory
sys.path.insert(0, str(Path(__file__).parent))

from config import BASE_CFG, DT, PARAM_BOUNDS, PARAM_NAMES, T_END, T_IGNORE
from physics import build_road_signals, compute_seat_rms, run_one_case

# ─────────────────────────────────────────────────────────────
# LHS sampling
# ─────────────────────────────────────────────────────────────

def lhs_sample(n: int, seed: int = 0) -> List[Dict]:
    """
    Latin-hypercube sample over PARAM_BOUNDS.
    Returns list of dicts in physical units.
    """
    sampler = qmc.LatinHypercube(d=len(PARAM_BOUNDS), seed=seed)
    unit    = sampler.random(n)                          # [n, d] in [0,1]
    lo = np.array([v[0] for v in PARAM_BOUNDS.values()])
    hi = np.array([v[1] for v in PARAM_BOUNDS.values()])
    scaled = lo + unit * (hi - lo)
    keys   = list(PARAM_BOUNDS.keys())
    return [{k: float(scaled[i, j]) for j, k in enumerate(keys)}
            for i in range(n)]


# ─────────────────────────────────────────────────────────────
# Worker function  (top-level so joblib can pickle it)
# ─────────────────────────────────────────────────────────────

def _worker(args):
    """
    args = (case_id, params, cfg_base, t_eval)
    Returns (case_id, params, df_or_None, rms_or_nan, elapsed_s)
    """
    case_id, params, cfg_base, t_eval = args
    t0 = time.perf_counter()
    try:
        df = run_one_case(params, cfg_base, t_eval, verbose=False)
    except Exception:
        traceback.print_exc()
        df = None
    elapsed = time.perf_counter() - t0
    if df is not None:
        rms = compute_seat_rms(df, {**cfg_base, **params})
    else:
        rms = float("nan")
    return case_id, params, df, rms, elapsed


# ─────────────────────────────────────────────────────────────
# Main generation function
# ─────────────────────────────────────────────────────────────

def run_lhs_grid(
    n_cases:    int,
    cfg_base:   Dict,
    out_csv:    str   = "data/physics_train.csv",
    seed:       int   = 42,
    downsample: int   = 4,       # store every Nth ODE step → 62.5 Hz
    n_jobs:     int   = 1,
    test_frac:  float = 0.20,    # fraction held out as test set
) -> None:
    """
    Generate LHS training + test data and save to CSVs.

    downsample=4 with DT=0.004 → stored timestep = 0.016 s (62.5 Hz).
    This reduces file size ~4× while keeping all relevant dynamics.
    """
    t_eval_full = np.arange(0.0, T_END + DT, DT)
    t_eval      = t_eval_full[::downsample]
    print(f"t_eval: {len(t_eval)} timesteps @ {1/(DT*downsample):.1f} Hz "
          f"over {T_END:.1f} s")

    # Sample parameters
    params_list = lhs_sample(n_cases, seed=seed)
    print(f"Generating {n_cases} LHS cases  (seed={seed}, n_jobs={n_jobs})")

    # Build task list
    tasks = [(cid, p, cfg_base, t_eval) for cid, p in enumerate(params_list)]

    # Run (parallel or serial)
    results = []
    if n_jobs == 1:
        for task in tasks:
            cid, p, df, rms, elapsed = _worker(task)
            status = f"RMS={rms:.4f}" if not np.isnan(rms) else "FAILED"
            print(f"  case {cid+1:3d}/{n_cases}  {status}  ({elapsed:.0f}s)")
            results.append((cid, p, df, rms))
    else:
        try:
            from joblib import Parallel, delayed
        except ImportError:
            print("joblib not installed – falling back to serial.  "
                  "pip install joblib")
            return run_lhs_grid(n_cases, cfg_base, out_csv, seed,
                                downsample, n_jobs=1, test_frac=test_frac)

        raw = Parallel(n_jobs=n_jobs, verbose=10)(
            delayed(_worker)(t) for t in tasks
        )
        for cid, p, df, rms, elapsed in raw:
            status = f"RMS={rms:.4f}" if not np.isnan(rms) else "FAILED"
            print(f"  case {cid+1:3d}/{n_cases}  {status}  ({elapsed:.0f}s)")
            results.append((cid, p, df, rms))

    # Filter successful cases
    ok = [(cid, p, df, rms) for cid, p, df, rms in results
          if df is not None and not np.isnan(rms)]
    print(f"\n{len(ok)}/{n_cases} cases succeeded.")
    if not ok:
        print("ERROR: no cases succeeded.  Check your CSV paths and physics code.")
        return

    # Assign split labels
    rng    = np.random.default_rng(seed)
    ids    = [c for c, *_ in ok]
    shuffled = ids.copy(); rng.shuffle(shuffled)
    cut    = max(1, int(len(shuffled) * (1 - test_frac)))
    train_ids = set(shuffled[:cut])
    test_ids  = set(shuffled[cut:])

    # Concatenate and save
    all_dfs_train, all_dfs_test = [], []
    rms_records = []
    for cid, p, df, rms in ok:
        df = df.copy()
        df["case_id"] = cid
        df["split"]   = "train" if cid in train_ids else "test"
        if cid in train_ids:
            all_dfs_train.append(df)
        else:
            all_dfs_test.append(df)
        rms_records.append({"case_id": cid, "split": df["split"].iloc[0],
                             "rms": rms, **p})

    out_path = Path(out_csv)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    # Save combined (train + test in one file, distinguished by 'split' column)
    all_df = pd.concat(all_dfs_train + all_dfs_test, ignore_index=True)
    all_df.to_csv(out_path, index=False)
    print(f"Saved  {out_path}  ({len(all_df)} rows, "
          f"{len(all_dfs_train)} train cases, {len(all_dfs_test)} test cases)")

    # Save separate test CSV for convenience
    test_path = out_path.parent / (out_path.stem.replace("train", "") + "test.csv")
    if all_dfs_test:
        pd.concat(all_dfs_test, ignore_index=True).to_csv(test_path, index=False)
        print(f"Saved  {test_path}  ({len(all_dfs_test)} test cases)")

    # Save RMS summary
    rms_path = out_path.parent / "rms_summary.csv"
    pd.DataFrame(rms_records).to_csv(rms_path, index=False)
    print(f"Saved  {rms_path}")
    print(f"\nRMS stats:  min={min(r['rms'] for r in rms_records):.4f}  "
          f"max={max(r['rms'] for r in rms_records):.4f}  "
          f"mean={np.mean([r['rms'] for r in rms_records]):.4f}")


# ─────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Generate LHS ODE training data for cabin surrogate")
    parser.add_argument("--n_cases",    type=int,   default=80,
                        help="Total number of LHS parameter sets (default 80)")
    parser.add_argument("--n_jobs",     type=int,   default=1,
                        help="Parallel workers via joblib. -1=all cores")
    parser.add_argument("--seed",       type=int,   default=42)
    parser.add_argument("--downsample", type=int,   default=4,
                        help="Store every Nth ODE step (default 4 → 62.5 Hz)")
    parser.add_argument("--test_frac",  type=float, default=0.20,
                        help="Fraction held out as test set (default 0.20)")
    parser.add_argument("--out",        type=str,
                        default="data/physics_train.csv",
                        help="Output CSV path")
    # Optional: override CSV paths
    parser.add_argument("--data_dir",   type=str,   default=None,
                        help="Directory containing the 6 road CSVs")
    args = parser.parse_args()

    cfg = dict(BASE_CFG)
    if args.data_dir:
        d = args.data_dir
        cfg.update({
            "axlefront_left_csv":  f"{d}/front_left.csv",
            "axlefront_right_csv": f"{d}/front_right.csv",
            "axlerear1_left_csv":  f"{d}/rear1_left.csv",
            "axlerear1_right_csv": f"{d}/rear1_right.csv",
            "axlerear2_left_csv":  f"{d}/rear2_left.csv",
            "axlerear2_right_csv": f"{d}/rear2_right.csv",
        })

    run_lhs_grid(
        n_cases=args.n_cases,
        cfg_base=cfg,
        out_csv=args.out,
        seed=args.seed,
        downsample=args.downsample,
        n_jobs=args.n_jobs,
        test_frac=args.test_frac,
    )
