# Ride Optimisation v2 — Generic & Scalable
# Complete Setup & Run Guide

## What changed from v1 → v2 (and why)

### Files REPLACED (do not use v1 versions)

| File | Why replaced |
|---|---|
| `backend/solver.py` | v1 had the 6-DOF truck physics hardcoded. v2 calls whatever `ode_rhs` function the user writes in the editor. Works for any system. |
| `backend/optimiser.py` | v1 assumed fixed parameter keys (K_f, C_f etc). v2 reads parameter names from the user's BOUNDS dict — works for any problem. |
| `backend/plotter.py` | v1 hardcoded state names. v2 reads them from the user model and adapts to any number of states. |
| `backend/main.py` | v1 accepted cfg_overrides as a dict. v2 accepts raw code strings from the editor and executes them server-side — the entire ODE is user-defined. |
| `frontend/src/App.jsx` | v1 had one editor panel for CONFIG only. v2 has two editor panels (ODE+Config and Geometry), a geometry toggle, and estimated run time display. |

### Files ADDED (new in v2)

| File | Purpose |
|---|---|
| `backend/user_code_runner.py` | Executes user code strings safely, extracts CONFIG / BOUNDS / OUTPUTS / ode_rhs / constraints. Auto-detects n_states. Validates everything before the solver runs. |

### Files RETAINED EXACTLY (copy from v1, no changes needed)

| File | Why kept |
|---|---|
| `backend/surrogate_check.py` | Surrogate validation logic is unchanged |
| `frontend/index.html` | Unchanged |
| `frontend/package.json` | Same dependencies |
| `frontend/vite.config.js` | Same proxy config |
| `frontend/src/index.css` | Same styles |
| `frontend/src/main.jsx` | Same React entry point |
| `requirements.txt` | Same Python packages |

---

## Project structure (v2)

```
ride_opt_v2/
├── backend/
│   ├── user_code_runner.py  ← NEW  — parses/validates user code
│   ├── solver.py            ← REPLACED — generic, calls user's ode_rhs
│   ├── optimiser.py         ← REPLACED — reads bounds from user's BOUNDS dict
│   ├── plotter.py           ← REPLACED — adapts to any state/param set
│   ├── main.py              ← REPLACED — accepts code strings from frontend
│   └── surrogate_check.py  ← KEPT    — unchanged
├── frontend/
│   ├── index.html           ← KEPT
│   ├── package.json         ← KEPT
│   ├── vite.config.js       ← KEPT
│   └── src/
│       ├── App.jsx          ← REPLACED — two editor panels + geometry toggle
│       ├── index.css        ← KEPT
│       └── main.jsx         ← KEPT
└── requirements.txt         ← KEPT
```

---

## How the generalised framework works

The app has two editor panels inside the ODE Setup tab:

### Panel 1 — ODE + Config (always visible)
You write three things here:

```python
CONFIG = {
    # All your system parameters — masses, stiffnesses, geometry etc.
    # Whatever your ODE needs. Add or remove any key.
}

BOUNDS = {
    # Which parameters to optimise and their search range [lo, hi]
    # Only keys listed here are optimised. Everything else stays fixed.
    "K_f": [416000, 533000],
    "C_f": [6600, 21000],
    ...
}

OUTPUTS = {
    # Tell the framework which state indices carry cabin accelerations.
    # These are indices in xdot (the derivative), not in x itself.
    # For a 12-state system (6 positions + 6 velocities):
    #   xdot[6] = z̈_c  (vertical cabin acceleration)
    #   xdot[7] = θ̈_c  (pitch → longitudinal)
    #   xdot[8] = φ̈_c  (roll  → lateral)
    "cabin_z_accel_idx":  6,
    "cabin_th_accel_idx": 7,
    "cabin_ph_accel_idx": 8,
    "hcp": 0.1,   # seat height offset [m] for lateral/longitudinal seat point calc
}

def ode_rhs(t, x, params, inputs):
    # x      = current state vector (numpy array)
    # params = your CONFIG dict merged with current trial parameter values
    # inputs = road signals at time t (dict with z1f, ph_f, z2, ph2, z3, ph3 etc.)
    # Return: list or numpy array of same length as x
    ...
    return [dx0, dx1, dx2, ...]
```

### Panel 2 — Geometry (appears when toggle is ON)

```python
def constraints(t, q, params, inputs):
    # q      = position sub-vector (first half of state x)
    # Return: list of constraint residuals — one per constraint
    # Return [] if no constraints (same as leaving toggle off)
    g1 = ...
    g2 = ...
    return [g1, g2]
```

When the geometry toggle is ON:
- The solver applies Baumgarte stabilisation to enforce your constraints
- CONFIG must include `baum_omega` and `baum_zeta`
- The constraint Jacobian is computed numerically — you don't need to derive it

When OFF: pure unconstrained ODE, no Baumgarte, faster.

### Objectives (always fixed)
The optimiser always minimises three things regardless of what ODE you write:
- **RMS_z** — vertical cabin seat acceleration
- **RMS_x** — longitudinal seat acceleration (pitch × seat height)
- **RMS_y** — lateral seat acceleration (roll × seat height)

These come from the OUTPUTS indices you declare. Change the ODE, the objectives stay the same.

---

## Current example loaded in the editor

The editor comes pre-loaded with your **6-DOF laden truck** model:
- 12 states: [z_c, θ_c, φ_c, z_s, θ_s, φ_s, ż_c, θ̇_c, φ̇_c, ż_s, θ̇_s, φ̇_s]
- Two-stage asymmetric damper
- Leaf spring geometric compatibility constraints in the geometry panel
- Same parameters and bounds as v1

You can run this as-is to verify everything works. Once verified, you can paste any other vehicle ODE into the editor — the backend adapts automatically.

---

## Setup steps (same as v1)

### Step 1 — Python environment
```bash
python -m venv venv
venv\Scripts\activate          # Windows
source venv/bin/activate       # macOS/Linux
```

### Step 2 — Install Python packages
```bash
pip install -r requirements.txt
```

### Step 3 — Install frontend dependencies
```bash
cd frontend
npm install
```

### Step 4 — Start backend (Terminal 1)
```bash
cd backend
uvicorn main:app --reload --port 8000
```

### Step 5 — Start frontend (Terminal 2)
```bash
cd frontend
npm run dev
```

Open http://localhost:3000

---

## Using the app

1. The ODE editor is pre-filled with the 6-DOF truck example
2. Upload all 6 axle CSV files (Front Left/Right, Rear1 Left/Right, Rear2 Left/Right)
3. Toggle geometry ON if you want leaf spring constraints enforced
4. Choose optimiser mode:
   - **Multi-objective (NSGA-II)** — gives Pareto front of RMS_z / RMS_x / RMS_y trade-offs
   - **Single-objective (Bayesian)** — gives one best combined RMS solution
5. Set population/generations (NSGA-II) or total calls (Bayesian)
6. The app shows **estimated total time** before the run starts (based on a 3s test solve)
7. Click Run — live log streams every evaluation
8. Results tab opens automatically with Pareto table + all plots

---

## Switching to a different vehicle/system

To use a different ODE in the future:

1. Clear the ODE editor
2. Write your new `CONFIG`, `BOUNDS`, `OUTPUTS`, and `ode_rhs`
3. Update `OUTPUTS` to point to the correct state indices for cabin accelerations
4. If your system has geometric constraints, write `constraints()` and toggle ON
5. Upload your road data CSVs (or leave empty if your ODE doesn't use road inputs)
6. Run — nothing else changes

The backend detects the number of states automatically from what `ode_rhs` returns.

---

## Common errors

| Error | Fix |
|---|---|
| `CONFIG dict not found` | Make sure your ODE panel has `CONFIG = {...}` |
| `BOUNDS dict not found` | Make sure your ODE panel has `BOUNDS = {...}` |
| `OUTPUTS dict not found` | Add `OUTPUTS = {...}` with cabin index mapping |
| `ode_rhs not found` | Add `def ode_rhs(t, x, params, inputs):` |
| `Could not detect state dimension` | Make sure ode_rhs returns a list/array of same length as x |
| `OUTPUTS cabin_z_accel_idx out of range` | Check your index — for 12-state system max index is 11 |
| `Geometry enabled but baum_omega missing` | Add `baum_omega` and `baum_zeta` to CONFIG |
| `ODE integration failed` | Check your equations — try running with geometry OFF first |
| `CSV file not found` | Check upload completed (green tick on all 6 dropzones) |
| `uvicorn not found` | Activate venv first |
| `npm not recognised` | Set Node.js PATH (see setup guide) |

---

## Quick start cheat sheet

```bash
# Terminal 1
cd ride_opt_v2/backend
venv\Scripts\activate
uvicorn main:app --reload --port 8000

# Terminal 2
cd ride_opt_v2/frontend
npm run dev

# Browser
http://localhost:3000
```
