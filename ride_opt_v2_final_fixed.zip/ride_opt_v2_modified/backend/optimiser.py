"""
optimiser.py
============
Two modes:
  nsga2    -> NSGA-II multi-objective  (RMS_z, RMS_x, RMS_y)
  bayesian -> Bayesian single-objective (RMS_total)

Key fix vs v7: run_one_case is called with fast=True during optimisation loop,
and fast=False only for final time-history plots. This avoids the 230-min/eval
timeout by using coarser tolerances + sparse t_eval during search.
"""

from __future__ import annotations
import time, warnings
import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Callable

from user_code_runner import UserModel
from solver import run_one_case, compute_cabin_rms

warnings.filterwarnings("ignore")


# ---------------------------------------------------------------------------
# Result container
# ---------------------------------------------------------------------------
@dataclass
class OptResult:
    mode:         str
    df_pareto:    pd.DataFrame
    eval_log:     List[Dict]
    hv_history:   List[float]
    convergence:  List[float]
    wall_seconds: float
    n_evals:      int
    param_keys:   List[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Shared eval wrapper  (fast=True → optimisation tolerances)
# ---------------------------------------------------------------------------
def _evaluate(params: Dict, model: UserModel, signals: Dict,
              t_eval: np.ndarray, log_cb: Callable, label: str) -> Dict:
    try:
        df  = run_one_case(params, model, signals, t_eval,
                           log_cb=log_cb, fast=True)
        return compute_cabin_rms(df, model)
    except Exception as e:
        log_cb(f"  [WARN] {label} failed: {e}")
        return {"rms_z": 99.0, "rms_x": 99.0, "rms_y": 99.0, "rms_total": 99.0}


# ===========================================================================
# NSGA-II
# ===========================================================================
def _run_nsga2(model, signals, t_eval, pop_size, n_gen, log_cb) -> OptResult:
    from pymoo.core.problem            import ElementwiseProblem
    from pymoo.algorithms.moo.nsga2    import NSGA2
    from pymoo.operators.crossover.sbx import SBX
    from pymoo.operators.mutation.pm   import PM
    from pymoo.operators.sampling.rnd  import FloatRandomSampling
    from pymoo.optimize                import minimize as pymoo_minimize
    from pymoo.indicators.hv           import HV
    from pymoo.core.callback           import Callback

    param_keys = list(model.bounds.keys())
    XL = np.array([float(model.bounds[k][0]) for k in param_keys])
    XU = np.array([float(model.bounds[k][1]) for k in param_keys])
    HV_REF = np.array([5.0, 5.0, 5.0])

    eval_log:   List[Dict]  = []
    hv_history: List[float] = []
    gen_counter = [0]

    class VehicleProblem(ElementwiseProblem):
        def __init__(self):
            super().__init__(n_var=len(param_keys), n_obj=3,
                             n_constr=0, xl=XL, xu=XU)

        def _evaluate(self, x, out, *args, **kwargs):
            params = dict(zip(param_keys, x.tolist()))
            gen    = gen_counter[0]
            rms    = _evaluate(params, model, signals, t_eval, log_cb,
                               f"gen={gen} eval={len(eval_log)+1}")
            f = [rms["rms_z"], rms["rms_x"], rms["rms_y"]]
            out["F"] = f
            eval_log.append({**params, **rms, "gen": gen})
            log_cb(f"  eval {len(eval_log):>4d} | gen={gen} "
                   f"| z={f[0]:.4f} x={f[1]:.4f} y={f[2]:.4f}")

    class HVCallback(Callback):
        def notify(self, algorithm):
            gen_counter[0] = algorithm.n_gen
            F     = algorithm.pop.get("F")
            valid = F[np.all(F < 90, axis=1)] if F is not None and len(F) else np.empty((0,3))
            try:
                hv_val = float(HV(ref_point=HV_REF).do(valid)) if len(valid) else 0.0
            except Exception:
                hv_val = 0.0
            hv_history.append(hv_val)
            n_nd = len(valid)
            log_cb(f"[GEN {algorithm.n_gen:>3d}/{n_gen}]  Pareto={n_nd}  HV={hv_val:.4f}")

    log_cb(f"NSGA-II | pop={pop_size} gen={n_gen} | params={param_keys}")
    t0 = time.time()

    result = pymoo_minimize(
        VehicleProblem(),
        NSGA2(
            pop_size=pop_size,
            sampling=FloatRandomSampling(),
            crossover=SBX(prob=0.9, eta=15),
            mutation=PM(eta=20),
            eliminate_duplicates=True,
        ),
        ("n_gen", n_gen),
        callback=HVCallback(),
        seed=42, verbose=False,
    )

    wall = time.time() - t0
    log_cb(f"NSGA-II done in {wall:.1f}s | evals={len(eval_log)}")

    rows = []
    X = result.opt.get("X")
    F = result.opt.get("F")
    if X is None or len(X) == 0:
        # fallback: use best from eval_log
        valid_log = [e for e in eval_log if e.get("rms_total", 99) < 90]
        if not valid_log:
            valid_log = eval_log
        valid_log.sort(key=lambda e: e.get("rms_total", 99))
        for i, e in enumerate(valid_log[:max(1, len(valid_log))]):
            rows.append({k: e[k] for k in param_keys if k in e} |
                        {"rms_z": e["rms_z"], "rms_x": e["rms_x"],
                         "rms_y": e["rms_y"], "rms_total": e["rms_total"],
                         "label": f"P{i+1:02d}"})
    else:
        for i, (xi, fi) in enumerate(zip(X, F)):
            params = dict(zip(param_keys, xi.tolist()))
            rows.append({**params,
                         "rms_z": float(fi[0]), "rms_x": float(fi[1]),
                         "rms_y": float(fi[2]),
                         "rms_total": float(fi[0]**2 + fi[1]**2 + fi[2]**2)**0.5,
                         "label": f"P{i+1:02d}"})

    df = pd.DataFrame(rows).sort_values("rms_total").reset_index(drop=True)
    for col, lbl in [("rms_z","Best_vertical"), ("rms_x","Best_longitudinal"),
                     ("rms_y","Best_lateral"),   ("rms_total","Best_total")]:
        if col in df.columns:
            df.loc[df[col].idxmin(), "label"] = lbl

    return OptResult("nsga2", df, eval_log, hv_history, [], wall, len(eval_log), param_keys)


# ===========================================================================
# Bayesian
# ===========================================================================
def _run_bayesian(model, signals, t_eval, n_calls, n_initial, log_cb) -> OptResult:
    from skopt       import gp_minimize
    from skopt.space import Real
    from skopt.utils import use_named_args

    param_keys  = list(model.bounds.keys())
    space       = [Real(float(model.bounds[k][0]), float(model.bounds[k][1]),
                        name=k) for k in param_keys]
    eval_log:    List[Dict]  = []
    convergence: List[float] = []

    @use_named_args(space)
    def objective(**params):
        rms = _evaluate(dict(params), model, signals, t_eval, log_cb,
                        f"eval={len(eval_log)+1}")
        val  = rms["rms_total"]
        eval_log.append({**params, **rms})
        best = min((e["rms_total"] for e in eval_log), default=val)
        convergence.append(best)
        log_cb(f"  eval {len(eval_log):>4d} | total={val:.4f} | best={best:.4f}")
        return float(val)

    log_cb(f"Bayesian | n_calls={n_calls} n_initial={n_initial} | params={param_keys}")
    t0     = time.time()
    result = gp_minimize(objective, space, n_calls=n_calls,
                         n_initial_points=n_initial,
                         acq_func="EI", noise=1e-10,
                         random_state=42, verbose=False)
    wall   = time.time() - t0
    log_cb(f"Bayesian done in {wall:.1f}s | evals={len(eval_log)}")

    best_params = dict(zip(param_keys, result.x))
    # Final report run at full accuracy
    try:
        best_rms = compute_cabin_rms(
            run_one_case(best_params, model, signals, t_eval,
                         log_cb=log_cb, fast=False), model)
    except Exception:
        best_rms = {"rms_z":99,"rms_x":99,"rms_y":99,"rms_total":99}

    df = pd.DataFrame([{**best_params, **best_rms, "label": "Best_total"}])
    return OptResult("bayesian", df, eval_log, [], convergence, wall, len(eval_log), param_keys)


# ===========================================================================
# Public entry point
# ===========================================================================
def run_optimisation(
    model:        UserModel,
    signals:      Dict,
    t_eval:       np.ndarray,
    mode:         str = "nsga2",
    opt_settings: Optional[Dict] = None,
    log_cb:       Optional[Callable] = None,
) -> OptResult:
    if log_cb is None:
        log_cb = print
    if opt_settings is None:
        opt_settings = {}

    if mode == "nsga2":
        return _run_nsga2(model, signals, t_eval,
                          pop_size=int(opt_settings.get("pop_size", 10)),
                          n_gen=int(opt_settings.get("n_gen", 5)),
                          log_cb=log_cb)
    elif mode == "bayesian":
        return _run_bayesian(model, signals, t_eval,
                             n_calls=int(opt_settings.get("n_calls", 50)),
                             n_initial=int(opt_settings.get("n_initial", 10)),
                             log_cb=log_cb)
    else:
        raise ValueError(f"Unknown mode: {mode!r}. Use 'nsga2' or 'bayesian'.")
