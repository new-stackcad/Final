"""
solver.py  (generic)
====================
Integrates any user-defined ODE system.

KEY DESIGN CHOICES vs prior versions
--------------------------------------
1.  Two-tier tolerance strategy
    - Optimisation tier (fast): rtol=1e-4, atol=1e-6, max_step=0.05 (~5x faster)
    - Report tier (accurate):   rtol=1e-6, atol=1e-8, max_step=0.01
    Caller passes  fast=True  during optimisation loop; False for final report.

2.  Sparse t_eval during optimisation
    RMS only needs the signal, not every dt=0.001 point.
    During optimisation we evaluate at dt=0.01 (1/10th the points → 10x less
    DataFrame overhead).  RMS accuracy is not affected because RMS is an
    integral quantity.

3.  Static equilibrium via correct LSQ  (matching reference code exactly)
    F(q, lam) = [R + G^T lam ; 1e3*g] = 0  (includes Lagrange multipliers)
    Falls back to dynamic relaxation then zeros.

4.  No threading in the hot path
    Threading inside run_one_case caused GIL contention inside Radau's inner
    loop.  Timeout enforcement is now at the optimiser level only.
"""

from __future__ import annotations
import time
import traceback
import numpy as np
import pandas as pd
from numpy.linalg import solve as lin_solve
from scipy.integrate import solve_ivp
from scipy.optimize  import least_squares as _lsq
from typing import Dict, Optional, Callable, List

from user_code_runner import UserModel


# ── tolerance presets ────────────────────────────────────────────────────────
_TOL_FAST   = dict(rtol=1e-4, atol=1e-6, max_step=0.05)   # optimisation loop
_TOL_REPORT = dict(rtol=1e-6, atol=1e-8, max_step=0.01)   # final report / plots


# ---------------------------------------------------------------------------
# Road signal loader
# ---------------------------------------------------------------------------
def build_road_signals(cfg: Dict) -> Dict:
    """
    Load axle CSV files listed in cfg.
    Returns dict  {sig_key: interp_callable}  or {} for non-vehicle problems.
    """
    def _load(path: str):
        df   = pd.read_csv(path, skiprows=2, header=None)
        t    = pd.to_numeric(df.iloc[:, 0], errors="coerce").values
        z    = pd.to_numeric(df.iloc[:, 1], errors="coerce").values
        mask = np.isfinite(t) & np.isfinite(z)
        t, z = t[mask].astype(float), z[mask].astype(float)

        def interp(xq):
            xq_c = float(np.clip(xq, t[0], t[-1]))
            idx  = int(np.clip(np.searchsorted(t, xq_c) - 1, 0, len(t) - 2))
            x0, x1 = t[idx], t[idx + 1]
            w = (xq_c - x0) / max(x1 - x0, 1e-12)
            return float(z[idx] * (1 - w) + z[idx + 1] * w)
        return interp

    CSV_MAP = {
        "axlefront_left_csv":  "f1L",
        "axlefront_right_csv": "f1R",
        "axlerear1_left_csv":  "f2L",
        "axlerear1_right_csv": "f2R",
        "axlerear2_left_csv":  "f3L",
        "axlerear2_right_csv": "f3R",
        # 4-axle
        "axlerear3_left_csv":  "f4L",
        "axlerear3_right_csv": "f4R",
        # 5-axle
        "axlerear4_left_csv":  "f5L",
        "axlerear4_right_csv": "f5R",
    }

    signals = {}
    for cfg_key, sig_key in CSV_MAP.items():
        path = cfg.get(cfg_key, "")
        if path:
            try:
                signals[sig_key] = _load(path)
            except Exception as e:
                raise RuntimeError(f"Failed to load {cfg_key} ({path}): {e}")
    return signals


def _build_inputs(t: float, signals: Dict, cfg: Dict, dt: float = 0.001) -> Dict:
    """
    Build the inputs dict passed to user's ode_rhs at time t.
    Computes axle displacements, roll angles, and their central-diff rates.
    """
    if not signals:
        return {}

    WT1 = cfg.get("WT1", 1.0)
    WT2 = cfg.get("WT2", 1.0)
    WT3 = cfg.get("WT3", 1.0)

    def _g(key):
        f = signals.get(key)
        return float(f(t)) if f is not None else 0.0

    def _gd(key):
        f = signals.get(key)
        if f is None:
            return 0.0
        return (float(f(t + dt)) - float(f(t - dt))) / (2 * dt)

    zr1L, zr1R = _g("f1L"), _g("f1R")
    zr2L, zr2R = _g("f2L"), _g("f2R")
    zr3L, zr3R = _g("f3L"), _g("f3R")

    zr1L_d, zr1R_d = _gd("f1L"), _gd("f1R")
    zr2L_d, zr2R_d = _gd("f2L"), _gd("f2R")
    zr3L_d, zr3R_d = _gd("f3L"), _gd("f3R")

    return {
        # displacements
        "z1f":  0.5 * (zr1L + zr1R),
        "ph_f": (zr1L - zr1R) / WT1,
        "z2":   0.5 * (zr2L + zr2R),
        "ph2":  (zr2L - zr2R) / WT2,
        "z3":   0.5 * (zr3L + zr3R),
        "ph3":  (zr3L - zr3R) / WT3,
        # raw signals
        "zr1L": zr1L, "zr1R": zr1R,
        "zr2L": zr2L, "zr2R": zr2R,
        "zr3L": zr3L, "zr3R": zr3R,
        # rates
        "dz1f":  0.5 * (zr1L_d + zr1R_d),
        "dph_f": (zr1L_d - zr1R_d) / WT1,
        "dz2":   0.5 * (zr2L_d + zr2R_d),
        "dph2":  (zr2L_d - zr2R_d) / WT2,
        "dz3":   0.5 * (zr3L_d + zr3R_d),
        "dph3":  (zr3L_d - zr3R_d) / WT3,
    }


# ---------------------------------------------------------------------------
# RHS dispatcher
# ---------------------------------------------------------------------------
def _make_rhs(model: UserModel, params: Dict, signals: Dict) -> Callable:
    """
    Returns scipy-compatible rhs(t, x) -> xdot.

    Unconstrained: calls ode_rhs directly.
    Constrained:   applies Baumgarte stabilisation using numerical Jacobian.
    """
    cfg        = {**model.cfg, **params}
    dt         = float(cfg.get("DT", 0.001))
    n          = model.n_states
    has_constr = model.geom_enabled and model.constraints is not None

    if not has_constr:
        def rhs(t, x):
            inp  = _build_inputs(t, signals, cfg, dt)
            return np.asarray(model.ode_rhs(t, np.asarray(x), cfg, inp), dtype=float)
        return rhs

    # ── Constrained (Baumgarte) ──────────────────────────────────────────
    n2   = n // 2
    w    = float(cfg.get("baum_omega", 10.0))
    zeta = float(cfg.get("baum_zeta",  1.0))
    eps  = 1e-6

    def rhs(t, x):
        q, v = x[:n2], x[n2:]
        inp  = _build_inputs(t, signals, cfg, dt)

        xdot_free = np.asarray(model.ode_rhs(t, x, cfg, inp), dtype=float)
        vdot_free = xdot_free[n2:]

        try:
            g0 = np.asarray(model.constraints(t, q, cfg, inp), dtype=float)
        except Exception:
            return xdot_free

        nc = len(g0)
        if nc == 0:
            return xdot_free

        # Numerical Jacobian G = dg/dq
        G = np.zeros((nc, n2))
        for j in range(n2):
            qp = q.copy(); qp[j] += eps
            qm = q.copy(); qm[j] -= eps
            G[:, j] = (
                np.asarray(model.constraints(t, qp, cfg, inp), dtype=float) -
                np.asarray(model.constraints(t, qm, cfg, inp), dtype=float)
            ) / (2 * eps)

        gamma   = w**2 * g0 + 2 * zeta * w * (G @ v)
        GGT     = G @ G.T
        try:
            lam      = np.linalg.solve(GGT + 1e-12 * np.eye(nc),
                                       G @ vdot_free + gamma)
            vdot_cor = vdot_free - G.T @ lam
        except np.linalg.LinAlgError:
            vdot_cor = vdot_free

        return np.concatenate([v, vdot_cor])

    return rhs


# ---------------------------------------------------------------------------
# Static equilibrium
# ---------------------------------------------------------------------------
def _static_equilibrium(model: UserModel, params: Dict, signals: Dict) -> np.ndarray:
    """
    Find static equilibrium via least-squares — matches reference code exactly.

    For the constrained (geom) case we solve:
        F(q, lam) = [ R(q, 0) + G^T lam ]  = 0
                    [ 1e3 * g(q)         ]
    which is exactly what the working standalone does.

    For unconstrained we solve for zero accelerations.
    """
    cfg = {**model.cfg, **params}
    n   = model.n_states
    n2  = n // 2

    rhs = _make_rhs(model, params, signals)

    # ── Method 1: unconstrained LSQ ──────────────────────────────────────
    def residual_unc(q):
        x    = np.hstack([q, np.zeros(n2)])
        xdot = np.asarray(rhs(0.0, x), dtype=float)
        return xdot[n2:]   # accelerations → 0 at equilibrium

    try:
        sol = _lsq(residual_unc, np.zeros(n2), method="trf", loss="soft_l1",
                   xtol=1e-10, ftol=1e-10, gtol=1e-10, max_nfev=500)
        q0 = sol.x
        if np.all(np.isfinite(q0)) and np.all(np.abs(q0) < 100.0):
            x0 = np.hstack([q0, np.zeros(n2)])
            # Verify residual is small
            res = np.max(np.abs(residual_unc(q0)))
            if res < 1.0:    # physically reasonable
                return x0
    except Exception:
        pass

    # ── Method 2: constrained LSQ  (includes Lagrange multipliers) ───────
    if model.geom_enabled and model.constraints is not None:
        inp0 = _build_inputs(0.0, signals, cfg)
        nc_guess = 2   # typical for the 6-DOF leaf-spring model

        def residual_con(y):
            # Try to determine nc from constraints call
            q   = y[:n2]
            lam = y[n2:]
            try:
                g_val, G_mat = model.constraints.__wrapped__(q, 0.0, cfg, inp0)
                nc_actual = len(g_val)
            except Exception:
                # constraints returns just residual vector
                try:
                    g_val = np.asarray(model.constraints(0.0, q, cfg, inp0), dtype=float)
                    nc_actual = len(g_val)
                    G_mat = None
                except Exception:
                    return np.zeros(n2 + len(lam))

            # Rebuild M, R by calling ode_rhs then extracting acceleration part
            x    = np.hstack([q, np.zeros(n2)])
            xdot = np.asarray(model.ode_rhs(0.0, x, cfg, inp0), dtype=float)
            # xdot[n2:] = M^{-1} R  (unconstrained acceleration)
            # The constraint force is G^T lam
            # We need numerical G if not available
            if G_mat is None:
                G_mat = np.zeros((nc_actual, n2))
                eps = 1e-6
                for j in range(n2):
                    qp = q.copy(); qp[j] += eps
                    qm = q.copy(); qm[j] -= eps
                    try:
                        gp = np.asarray(model.constraints(0.0, qp, cfg, inp0), dtype=float)
                        gm = np.asarray(model.constraints(0.0, qm, cfg, inp0), dtype=float)
                        G_mat[:, j] = (gp - gm) / (2 * eps)
                    except Exception:
                        pass

            Mlam = lam[:nc_actual] if len(lam) >= nc_actual else np.zeros(nc_actual)
            eq1  = xdot[n2:] + G_mat.T @ Mlam   # should be 0
            eq2  = 1e3 * g_val[:nc_actual]        # constraint: 0
            return np.hstack([eq1, eq2[:len(lam)]])

        try:
            y0  = np.zeros(n2 + nc_guess)
            sol = _lsq(residual_con, y0, method="trf", loss="soft_l1",
                       xtol=1e-10, ftol=1e-10, gtol=1e-10, max_nfev=600)
            q0  = sol.x[:n2]
            if np.all(np.isfinite(q0)) and np.all(np.abs(q0) < 100.0):
                return np.hstack([q0, np.zeros(n2)])
        except Exception:
            pass

    # ── Method 3: dynamic relaxation fallback ────────────────────────────
    heavy_params = {**params}
    for k in cfg:
        if k.startswith("C_") or "damp" in k.lower():
            heavy_params[k] = float(cfg[k]) * 20.0
    rhs_h = _make_rhs(model, heavy_params, signals)
    try:
        sol2 = solve_ivp(rhs_h, (0.0, 3.0), np.zeros(n),
                         method="Radau", rtol=1e-5, atol=1e-7, max_step=0.1)
        if sol2.success and np.all(np.isfinite(sol2.y[:, -1])):
            return sol2.y[:, -1]
    except Exception:
        pass

    # ── Method 4: zeros ──────────────────────────────────────────────────
    return np.zeros(n)


# ---------------------------------------------------------------------------
# Time estimator
# ---------------------------------------------------------------------------
def estimate_single_eval_time(
    model:    UserModel,
    signals:  Dict,
    t_sample: float = 3.0,
) -> float:
    """
    Run a SHORT integration at FAST tolerances and extrapolate to T_END.
    Always uses the fast-tolerance config (same as optimisation loop) so the
    estimate matches actual run time.
    """
    cfg    = model.cfg
    T_END  = float(cfg.get("T_END", 466.945))
    dt_opt = 0.01   # sparse t_eval used during optimisation
    params = {k: (float(v[0]) + float(v[1])) / 2
              for k, v in model.bounds.items()
              if isinstance(v, (list, tuple)) and len(v) == 2}

    rhs    = _make_rhs(model, params, signals)
    x0     = _static_equilibrium(model, params, signals)
    t_end_sample = min(t_sample, T_END)
    t_eval = np.arange(0.0, t_end_sample + dt_opt, dt_opt)

    wall0 = time.time()
    try:
        solve_ivp(rhs, (0.0, t_end_sample), x0, method="Radau",
                  t_eval=t_eval, **_TOL_FAST)
    except Exception:
        pass
    sample_wall = time.time() - wall0

    # Extrapolate: num_points in full run / num_points in sample
    n_full   = int(T_END / dt_opt)
    n_sample = len(t_eval)
    return sample_wall * (n_full / max(n_sample, 1))


# ---------------------------------------------------------------------------
# Main integration — two-tier tolerances
# ---------------------------------------------------------------------------
def run_one_case(
    params:   Dict,
    model:    UserModel,
    signals:  Dict,
    t_eval:   np.ndarray,
    log_cb:   Optional[Callable] = None,
    fast:     bool = True,
) -> pd.DataFrame:
    """
    Run one ODE integration.

    Parameters
    ----------
    fast    : True  → optimisation tolerances + sparse t_eval (10x faster)
              False → report tolerances + original t_eval (accurate, for plots)
    """
    def _log(msg):
        if log_cb:
            log_cb(msg)

    cfg  = {**model.cfg, **params}
    n    = model.n_states
    rhs  = _make_rhs(model, params, signals)

    _log("Computing static equilibrium …")
    x0   = _static_equilibrium(model, params, signals)
    _log(f"x0 = {np.round(x0, 5).tolist()}")

    # ── Select solver settings ───────────────────────────────────────────
    if fast:
        tol   = _TOL_FAST
        dt_ev = 0.01   # sparse — 1/10th points, fine for RMS
        T_END = float(t_eval[-1])
        t_ev  = np.arange(float(t_eval[0]), T_END + dt_ev, dt_ev)
    else:
        tol   = _TOL_REPORT
        t_ev  = t_eval

    t0, tf = float(t_ev[0]), float(t_ev[-1])
    _log(f"Integrating ({n} states, Radau, {'FAST' if fast else 'REPORT'}) "
         f"T=[{t0:.2f}, {tf:.2f}]s  n_eval_pts={len(t_ev)}")

    wall0 = time.time()
    sol   = solve_ivp(rhs, (t0, tf), x0, method="Radau",
                      t_eval=t_ev, **tol)
    elapsed = time.time() - wall0
    _log(f"Done — success={sol.success}  nfev={sol.nfev}  wall={elapsed:.1f}s")

    if not sol.success:
        raise RuntimeError(f"ODE failed: {sol.message}")
    if not np.all(np.isfinite(sol.y)):
        raise RuntimeError("ODE returned non-finite values — check equations.")

    # ── Build DataFrame ──────────────────────────────────────────────────
    snames = model.state_names
    out    = model.outputs
    hcp    = float(out.get("hcp", 0.1))
    iz     = out.get("cabin_z_accel_idx")
    ith    = out.get("cabin_th_accel_idx")
    iph    = out.get("cabin_ph_accel_idx")

    rows = []
    for i, t in enumerate(sol.t):
        x = sol.y[:, i]
        try:
            xdot = rhs(t, x)
        except Exception:
            xdot = np.zeros(n)

        row = {"t": float(t)}
        for j in range(n):
            nm       = snames[j] if j < len(snames) else f"x{j}"
            row[nm]  = float(x[j])
            row[f"d{nm}"] = float(xdot[j])

        # Seat accelerations (indices into full xdot vector)
        row["cabin_az"] = float(xdot[iz])         if iz  is not None else 0.0
        row["cabin_ax"] = float(-hcp * xdot[ith]) if ith is not None else 0.0
        row["cabin_ay"] = float( hcp * xdot[iph]) if iph is not None else 0.0
        rows.append(row)

    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# RMS
# ---------------------------------------------------------------------------
def compute_cabin_rms(df: pd.DataFrame, model: UserModel) -> Dict[str, float]:
    t_ignore = float(model.cfg.get("T_IGNORE", 0.5))
    mask     = df["t"] >= t_ignore

    az = df.loc[mask, "cabin_az"].values
    ax = df.loc[mask, "cabin_ax"].values
    ay = df.loc[mask, "cabin_ay"].values

    return {
        "rms_z":     float(np.sqrt(np.mean(az ** 2))),
        "rms_x":     float(np.sqrt(np.mean(ax ** 2))),
        "rms_y":     float(np.sqrt(np.mean(ay ** 2))),
        "rms_total": float(np.sqrt(np.mean(az**2) + np.mean(ax**2) + np.mean(ay**2))),
    }
