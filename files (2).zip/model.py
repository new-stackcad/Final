"""
model.py  -  PhysicsLSTM surrogate architecture.

Architecture summary
--------------------
Road signals [B,T,6]
    |-- Linear road encoder (per-timestep MLP)  ->  [B,T,road_dim=32]
    |
    +-- concat with param embedding broadcast    ->  [B,T,road_dim+param_dim]

Design params [B,8]
    |-- ParamMLP  ->  [B,param_dim=128]
         |-- also initialises LSTM h0, c0

LSTM (2 layers, hidden=256)  ->  [B,T,256]
    |-- StateHead  ->  state_pred  [B,T,6]
    +-- AccelHead  ->  accel_pred  [B,T,3]

NOTE: Road encoder uses a per-timestep MLP (no Conv1d/transpose).
This guarantees contiguous tensors throughout and avoids all cuDNN
CUDNN_STATUS_NOT_SUPPORTED errors regardless of PyTorch/cuDNN version.
"""

from __future__ import annotations
from typing import Tuple

import torch
import torch.nn as nn

from config import TRAIN_CFG


# ---------------------------------------------------------------
# Road encoder: per-timestep MLP (no Conv1d, no transpose)
# Operates on last dim only -> always contiguous
# ---------------------------------------------------------------

class RoadEncoder(nn.Module):
    """
    Per-timestep linear encoder.  Applied independently to each timestep.
    Input:  [B, T, 6]
    Output: [B, T, out_dim]
    No Conv1d, no transpose, always contiguous.
    """

    def __init__(self, in_dim: int = 6, out_dim: int = 32, hidden: int = 64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.GELU(),
            nn.Linear(hidden, hidden),
            nn.GELU(),
            nn.Linear(hidden, out_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, T, 6]  ->  [B, T, out_dim]
        # nn.Linear operates on last dim -> output is always contiguous
        return self.net(x)


# ---------------------------------------------------------------
# Param MLP
# ---------------------------------------------------------------

class ParamMLP(nn.Module):
    """Maps 8 design params -> condition vector."""

    def __init__(self, n_params: int = 8, hidden: int = 64, out_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(n_params, hidden), nn.GELU(),
            nn.Linear(hidden, hidden),   nn.GELU(),
            nn.Linear(hidden, out_dim),
        )

    def forward(self, p: torch.Tensor) -> torch.Tensor:
        return self.net(p)


# ---------------------------------------------------------------
# Output heads
# ---------------------------------------------------------------

class ResidualHead(nn.Module):
    """2-layer MLP with skip connection."""

    def __init__(self, in_dim: int, out_dim: int, hidden: int = 128):
        super().__init__()
        self.fc1  = nn.Linear(in_dim, hidden)
        self.act  = nn.GELU()
        self.fc2  = nn.Linear(hidden, out_dim)
        self.skip = nn.Linear(in_dim, out_dim, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.fc2(self.act(self.fc1(x))) + self.skip(x)


# ---------------------------------------------------------------
# Main surrogate model
# ---------------------------------------------------------------

class PhysicsLSTM(nn.Module):
    """Parameter-conditioned physics-informed LSTM surrogate."""

    def __init__(self,
                 road_dim:    int   = TRAIN_CFG["road_dim"],
                 param_dim:   int   = TRAIN_CFG["param_dim"],
                 lstm_hidden: int   = TRAIN_CFG["lstm_hidden"],
                 lstm_layers: int   = TRAIN_CFG["lstm_layers"],
                 dropout:     float = TRAIN_CFG["dropout"],
                 n_states:    int   = 6,
                 n_accels:    int   = 3):
        super().__init__()

        self.road_enc  = RoadEncoder(in_dim=6, out_dim=road_dim, hidden=64)
        self.param_mlp = ParamMLP(n_params=8, hidden=64, out_dim=param_dim)

        lstm_in = road_dim + param_dim
        self.lstm = nn.LSTM(
            input_size=lstm_in,
            hidden_size=lstm_hidden,
            num_layers=lstm_layers,
            batch_first=True,
            dropout=dropout if lstm_layers > 1 else 0.0,
        )

        self.h0_proj = nn.Linear(param_dim, lstm_hidden * lstm_layers)
        self.c0_proj = nn.Linear(param_dim, lstm_hidden * lstm_layers)

        self.state_head = ResidualHead(lstm_hidden, n_states)
        self.accel_head = ResidualHead(lstm_hidden, n_accels)

        self.lstm_hidden = lstm_hidden
        self.lstm_layers = lstm_layers

        self._init_weights()

    def _init_weights(self):
        for name, p in self.named_parameters():
            if "weight_ih" in name:
                nn.init.xavier_uniform_(p)
            elif "weight_hh" in name:
                nn.init.orthogonal_(p)
            elif "bias" in name:
                nn.init.zeros_(p)

    # cuDNN LSTM has an undocumented max sequence length.
    # At 1000Hz with downsample=4, T=116737 exceeds it.
    # We process the sequence in chunks, passing hidden state
    # between chunks so temporal continuity is preserved.
    CHUNK = 8192   # safe for all cuDNN versions; power of 2

    def forward(self,
                road:  torch.Tensor,   # [B, T, 6]
                param: torch.Tensor,   # [B, 8]
                ) -> Tuple[torch.Tensor, torch.Tensor]:
        B, T, _ = road.shape

        # --- road encoding: Linear on last dim -> always contiguous ---
        road_feat = self.road_enc(road)                     # [B, T, road_dim]

        # --- param embedding ---
        p_emb = self.param_mlp(param)                       # [B, param_dim]

        # --- broadcast param across T ---
        p_rep   = p_emb.unsqueeze(1).repeat(1, T, 1)       # [B, T, param_dim]
        lstm_in = torch.cat([road_feat, p_rep], dim=2).contiguous()  # [B, T, F]

        # --- init hidden state from param embedding ---
        h = (self.h0_proj(p_emb)
              .view(B, self.lstm_layers, self.lstm_hidden)
              .permute(1, 0, 2).contiguous())               # [layers, B, H]
        c = (self.c0_proj(p_emb)
              .view(B, self.lstm_layers, self.lstm_hidden)
              .permute(1, 0, 2).contiguous())               # [layers, B, H]

        # --- chunked LSTM: avoids cuDNN sequence-length limit ---
        out_chunks = []
        for start in range(0, T, self.CHUNK):
            end   = min(start + self.CHUNK, T)
            chunk = lstm_in[:, start:end, :].contiguous()  # [B, chunk, F]
            out_chunk, (h, c) = self.lstm(chunk, (h, c))   # hidden state carries over
            out_chunks.append(out_chunk)
            h = h.contiguous()
            c = c.contiguous()

        lstm_out = torch.cat(out_chunks, dim=1)             # [B, T, H]

        state_pred = self.state_head(lstm_out)              # [B, T, 6]
        accel_pred = self.accel_head(lstm_out)              # [B, T, 3]

        return state_pred, accel_pred

    @property
    def n_params(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


# ---------------------------------------------------------------
# Physics-informed loss
# ---------------------------------------------------------------

class PhysicsLoss(nn.Module):
    """
    L = lambda_s * MSE(state)
      + lambda_a * MSE(accel)
      + lambda_r * MSE(rms_normalised)
      + lambda_p * finite_difference_consistency
    """

    def __init__(self,
                 lambda_state: float = TRAIN_CFG["lambda_state"],
                 lambda_accel: float = TRAIN_CFG["lambda_accel"],
                 lambda_rms:   float = TRAIN_CFG["lambda_rms"],
                 lambda_phys:  float = TRAIN_CFG["lambda_phys"]):
        super().__init__()
        self.ls = lambda_state
        self.la = lambda_accel
        self.lr = lambda_rms
        self.lp = lambda_phys

    def forward(self,
                state_pred:  torch.Tensor,   # [B, T, 6]
                accel_pred:  torch.Tensor,   # [B, T, 3]  normalised
                state_true:  torch.Tensor,
                accel_true:  torch.Tensor,   # [B, T, 3]  normalised
                rms_true:    torch.Tensor,   # [B, 1]     physical m/s²
                h_seat:      float = 0.1,    # hcp lever arm
                dt:          float = 0.004,
                accel_raw:   torch.Tensor = None,  # [B, T, 3] physical m/s²
                a_std:       torch.Tensor = None,  # [B, 3]
                ) -> Tuple[torch.Tensor, dict]:

        mse = nn.functional.mse_loss

        # ── State loss: cabin DOFs weighted more than sprung mass ──
        # Weight z_c (index 0) and th_c (index 1) higher because they
        # directly determine seat acceleration and the LSTM tends to
        # predict the mean of slowly-varying DOFs like z_c.
        # Weights: [z_c=3, th_c=2, ph_c=2, z_s=1, th_s=1, ph_s=1]
        w_s = state_pred.new_tensor([3., 2., 2., 1., 1., 1.]).view(1, 1, 6)
        l_state = (w_s * (state_pred - state_true)**2).mean()

        # ── Accel loss: cabin DOFs weighted more ──────────────────
        # [qdd_z_c=3, qdd_th_c=2, qdd_ph_c=2]
        w_a = accel_pred.new_tensor([3., 2., 2.]).view(1, 1, 3)
        l_accel = (w_a * (accel_pred - accel_true)**2).mean()

        # ── AC emphasis: penalise predicting mean instead of dynamics
        # This is the key fix for flat bounce prediction.
        # Compare std of prediction vs std of target in each cabin DOF.
        # If surrogate predicts constant, its std=0 vs target std>0.
        # Loss = MSE of per-sequence std values (forces correct amplitude).
        pred_std = state_pred[:, :, :3].std(dim=1)   # [B, 3]
        true_std = state_true[:, :, :3].std(dim=1)   # [B, 3]
        l_ac = mse(pred_std, true_std)

        # ── Physical RMS loss (ISO 2631) ───────────────────────────
        if a_std is not None:
            a_std_b = a_std.unsqueeze(1)              # [B, 1, 3]
            ap_phys = accel_pred * a_std_b             # [B, T, 3]  physical
            az = ap_phys[..., 0]
            ax = -h_seat * ap_phys[..., 1]
            ay =  h_seat * ap_phys[..., 2]
            rms_pred = torch.sqrt(
                (az**2).mean(dim=1, keepdim=True) +
                (ax**2).mean(dim=1, keepdim=True) +
                (ay**2).mean(dim=1, keepdim=True) + 1e-8)
        else:
            rms_pred = torch.sqrt(
                (accel_pred[..., 0]**2).mean(dim=1, keepdim=True) + 1e-8)
            rms_true = rms_true / (rms_true.mean() + 1e-8)

        l_rms = mse(rms_pred, rms_true)

        # ── Finite-difference consistency (z_c bounce) ────────────
        l_phys = torch.zeros(1, device=state_pred.device)[0]
        if state_pred.shape[1] > 2:
            q_zc  = state_pred[:, :, 0]
            fd    = (q_zc[:, 2:] - 2*q_zc[:, 1:-1] + q_zc[:, :-2]) / (dt**2)
            l_phys = mse(fd, accel_pred[:, 1:-1, 0])

        total = (self.ls * l_state
               + self.la * l_accel
               + self.lr * l_rms
               + self.lp * l_phys
               + 2.0     * l_ac)    # AC amplitude loss, fixed weight

        return total, {
            "loss_total": total.item(),
            "loss_state": l_state.item(),
            "loss_accel": l_accel.item(),
            "loss_rms":   l_rms.item(),
            "loss_phys":  l_phys.item(),
            "loss_ac":    l_ac.item(),
        }
