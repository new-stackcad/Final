"""
agent_state.py
==============
Defines RideOptState — the single shared state object
that every node in the LangGraph reads from and writes to.

Nothing is global. Everything the agent knows at any point
lives in this object.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Preflight result
# ---------------------------------------------------------------------------
@dataclass
class PreflightResult:
    passed:           bool
    geometry_ok:      bool
    equilibrium_ok:   bool
    test_integration_ok: bool
    est_seconds_per_eval: float
    est_total_seconds:    float
    n_evals_planned:      int
    violations:       List[str] = field(default_factory=list)
    warnings:         List[str] = field(default_factory=list)
    retry_count:      int = 0


# ---------------------------------------------------------------------------
# Decision record — every routing decision is logged
# ---------------------------------------------------------------------------
@dataclass
class Decision:
    node:    str
    choice:  str
    reason:  str


# ---------------------------------------------------------------------------
# Agent summary — structured output for downstream agents
# ---------------------------------------------------------------------------
@dataclass
class AgentSummary:
    status:          str            # "success" | "partial" | "failed"
    mode:            str            # "nsga2" | "bayesian"
    n_evals:         int
    wall_seconds:    float
    best_params:     Dict[str, float]
    best_rms:        Dict[str, float]   # rms_z, rms_x, rms_y, rms_total
    pareto_size:     int
    sim_mode:        str            # "ode" | "surrogate"
    geom_enabled:    bool
    result_path:     str            # path to output folder
    plot_files:      List[str]
    # For DFMEA agent
    constraint_active:  bool
    constraint_residuals: Optional[List[float]]
    # For Expert Assistant agent
    hv_history:      List[float]
    convergence:     List[float]
    eval_log_size:   int
    param_keys:      List[str]
    warnings:        List[str]


# ---------------------------------------------------------------------------
# Main state — flows through every graph node
# ---------------------------------------------------------------------------
@dataclass
class RideOptState:
    # ── Inputs (set once at entry) ────────────────────────────────────────
    ode_code:       str = ""
    geom_code:      str = ""
    geom_enabled:   bool = False
    csv_paths:      Dict[str, str] = field(default_factory=dict)
    opt_mode:       str = "nsga2"      # "nsga2" | "bayesian"
    sim_mode:       str = "ode"        # "ode"   | "surrogate"
    pop_size:       int = 10
    n_gen:          int = 5
    n_calls:        int = 50
    n_initial:      int = 10
    T_END:          float = 466.945
    T_IGNORE:       float = 0.5
    job_id:         str = ""
    out_dir:        str = ""

    # ── Parsed model (set by ingest_code node) ────────────────────────────
    user_model:     Optional[Any] = None   # UserModel from user_code_runner
    model_valid:    bool = False
    model_errors:   List[str] = field(default_factory=list)

    # ── Road signals (set by ingest_data node) ────────────────────────────
    signals:        Optional[Dict] = None
    signals_loaded: bool = False
    signals_error:  str = ""

    # ── Preflight (set by preflight node) ────────────────────────────────
    preflight:      Optional[PreflightResult] = None

    # ── Optimisation result (set by optimise node) ────────────────────────
    opt_result:     Optional[Any] = None   # OptResult from optimiser
    opt_done:       bool = False

    # ── Post-processing (set by postprocess node) ─────────────────────────
    plot_files:     List[str] = field(default_factory=list)
    result_path:    str = ""
    run_data:       Optional[Dict] = None

    # ── Agent summary (set by postprocess node) ───────────────────────────
    agent_summary:  Optional[AgentSummary] = None

    # ── Control flow ─────────────────────────────────────────────────────
    current_node:   str = "start"
    status:         str = "pending"   # pending | running | done | failed
    error:          str = ""
    retry_count:    int = 0
    max_retries:    int = 1

    # ── Full decision log (every routing choice recorded here) ────────────
    decisions:      List[Decision] = field(default_factory=list)

    # ── Live log (streamed to frontend) ───────────────────────────────────
    logs:           List[str] = field(default_factory=list)

    def log(self, msg: str):
        self.logs.append(msg)

    def decide(self, node: str, choice: str, reason: str):
        self.decisions.append(Decision(node=node, choice=choice, reason=reason))
        self.log(f"[{node}] → {choice} | {reason}")
