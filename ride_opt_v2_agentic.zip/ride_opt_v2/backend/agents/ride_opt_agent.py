"""
ride_opt_agent.py
=================
Assembles the Ride Optimisation Agent as a LangGraph StateGraph.

This is the single entry point the Suspension Agent (orchestrator)
calls. It builds the graph once at module load, then invoke() is
called per job.

Graph topology
--------------
  START
    ↓
  ingest_code ──(fail)──────────────────────── END
    ↓ ok
  ingest_data ──(fail)──────────────────────── END
    ↓ ok
  preflight ──(hard fail)──────────────────── END
    ↓ (soft fail) ←──────────────(retry once)─┘
    ↓ ok
  optimise ──(crash)───────────────────────── END
    ↓ ok
  postprocess
    ↓
  END

Usage
-----
    from agents.ride_opt_agent import run_ride_opt_agent

    final_state = run_ride_opt_agent(
        ode_code    = "...",
        geom_code   = "...",
        geom_enabled= True,
        csv_paths   = {"fa_lh": "/path/...", ...},
        opt_mode    = "nsga2",
        pop_size    = 10,
        n_gen       = 5,
        T_END       = 466.945,
        T_IGNORE    = 0.5,
        job_id      = "abc123",
        out_dir     = "/results/abc123",
        log_queue   = q,   # optional queue.Queue for SSE streaming
    )
"""

from __future__ import annotations
import queue as q_module
from typing import Optional

from langgraph.graph import StateGraph, END

from agents.agent_state import RideOptState
from agents.nodes import (
    node_ingest_code,
    node_ingest_data,
    node_preflight,
    node_optimise,
    node_postprocess,
    route_after_ingest_code,
    route_after_ingest_data,
    route_after_preflight,
    route_after_optimise,
)


# ---------------------------------------------------------------------------
# Build the graph (once at module load)
# ---------------------------------------------------------------------------
def _build_graph() -> StateGraph:
    builder = StateGraph(RideOptState)

    # ── Add nodes ──────────────────────────────────────────────────────────
    builder.add_node("ingest_code",  node_ingest_code)
    builder.add_node("ingest_data",  node_ingest_data)
    builder.add_node("preflight",    node_preflight)
    builder.add_node("optimise",     node_optimise)
    builder.add_node("postprocess",  node_postprocess)

    # ── Entry point ────────────────────────────────────────────────────────
    builder.set_entry_point("ingest_code")

    # ── Conditional edges ──────────────────────────────────────────────────
    builder.add_conditional_edges(
        "ingest_code",
        route_after_ingest_code,
        {"ingest_data": "ingest_data", "__end__": END},
    )
    builder.add_conditional_edges(
        "ingest_data",
        route_after_ingest_data,
        {"preflight": "preflight", "__end__": END},
    )
    builder.add_conditional_edges(
        "preflight",
        route_after_preflight,
        {
            "optimise":  "optimise",
            "preflight": "preflight",   # retry edge
            "__end__":   END,
        },
    )
    builder.add_conditional_edges(
        "optimise",
        route_after_optimise,
        {"postprocess": "postprocess", "__end__": END},
    )

    # postprocess always goes to END
    builder.add_edge("postprocess", END)

    return builder.compile()


# Compile once
_GRAPH = _build_graph()


# ---------------------------------------------------------------------------
# Log bridge — pipes state.logs into a queue.Queue for SSE streaming
# ---------------------------------------------------------------------------
class _LogBridge:
    """
    Intercepts state.log() calls and pushes messages into
    a queue.Queue so FastAPI's SSE endpoint can stream them live.
    """
    def __init__(self, log_queue: Optional[q_module.Queue]):
        self._q = log_queue

    def push(self, msg: str):
        if self._q is not None:
            self._q.put(msg)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------
def run_ride_opt_agent(
    ode_code:     str,
    geom_code:    str,
    geom_enabled: bool,
    csv_paths:    dict,
    opt_mode:     str,
    sim_mode:     str = "ode",
    pop_size:     int = 10,
    n_gen:        int = 5,
    n_calls:      int = 50,
    n_initial:    int = 10,
    T_END:        float = 466.945,
    T_IGNORE:     float = 0.5,
    job_id:       str = "",
    out_dir:      str = "",
    log_queue:    Optional[q_module.Queue] = None,
) -> RideOptState:
    """
    Build initial state, run the graph, return final state.

    The graph runs synchronously in the calling thread.
    FastAPI calls this from a background thread so the main
    event loop is never blocked.

    Parameters
    ----------
    ode_code     : full content of the ODE + Config editor panel
    geom_code    : content of the Geometry editor panel (or "")
    geom_enabled : whether geometry toggle is ON
    csv_paths    : dict mapping short keys to server file paths
    opt_mode     : "nsga2" | "bayesian"
    sim_mode     : "ode" | "surrogate" (surrogate disabled for now)
    pop_size     : NSGA-II population size
    n_gen        : NSGA-II generations
    n_calls      : Bayesian total calls
    n_initial    : Bayesian initial random points
    T_END        : simulation end time [s]
    T_IGNORE     : seconds to skip when computing RMS
    job_id       : unique job identifier (from FastAPI)
    out_dir      : directory to write results into
    log_queue    : queue.Queue for live log streaming to frontend
    """

    # Build initial state
    initial_state = RideOptState(
        ode_code=ode_code,
        geom_code=geom_code,
        geom_enabled=geom_enabled,
        csv_paths=csv_paths,
        opt_mode=opt_mode,
        sim_mode=sim_mode,
        pop_size=pop_size,
        n_gen=n_gen,
        n_calls=n_calls,
        n_initial=n_initial,
        T_END=T_END,
        T_IGNORE=T_IGNORE,
        job_id=job_id,
        out_dir=out_dir,
    )

    # Wire log bridge so every state.log() call also pushes to the queue
    bridge = _LogBridge(log_queue)
    _patch_state_logging(initial_state, bridge)

    # Run the graph
    final_state = _GRAPH.invoke(initial_state)

    # Signal stream done
    if log_queue is not None:
        log_queue.put("__DONE__")

    return final_state


def _patch_state_logging(state: RideOptState, bridge: _LogBridge):
    """
    Monkey-patch state.log() so every log message also goes to the queue.
    This keeps the SSE stream working exactly as before.
    """
    original_log = state.log

    def patched_log(msg: str):
        original_log(msg)
        bridge.push(msg)

    state.log = patched_log
