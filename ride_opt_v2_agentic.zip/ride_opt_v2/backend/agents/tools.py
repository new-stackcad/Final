"""
tools.py
========
The 7 tools of the Ride Optimisation Agent.
Each tool wraps the existing backend modules — nothing is rewritten.

Tool 1: code_ingestion      — parse + validate user ODE/geometry code
Tool 2: data_ingestion      — load road signal CSVs
Tool 3: preflight           — geometry check + equilibrium + test integration
Tool 4: simulation_engine   — single ODE or surrogate evaluation
Tool 5: objective_calculator — compute cabin RMS from trajectory
Tool 6: optimiser_tool      — NSGA-II or Bayesian (calls tools 4+5 internally)
Tool 7: post_processor      — plots, CSV, JSON, agent summary

Tools 4 and 5 are called INSIDE tool 6 on every function evaluation.
They are not graph nodes — they do not make routing decisions.
"""

from __future__ import annotations
import os, json, time
from typing import Dict, List, Optional, Callable

import numpy as np
import pandas as pd

# ── existing modules ──────────────────────────────────────────────────────
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from user_code_runner import parse_user_code, validate_user_model, UserModel
from solver import (
    build_road_signals,
    run_one_case,
    compute_cabin_rms,
    estimate_single_eval_time,
    _static_equilibrium,
    _build_inputs,
)
from optimiser import run_optimisation, OptResult
from plotter import generate_all_plots, generate_time_history

from agents.agent_state import RideOptState, PreflightResult, AgentSummary


# ===========================================================================
# TOOL 1 — code_ingestion
# ===========================================================================
def tool_code_ingestion(state: RideOptState) -> RideOptState:
    """
    Parse and validate user ODE code + optional geometry code.
    Populates state.user_model, state.model_valid, state.model_errors.
    """
    state.log("TOOL 1 | code_ingestion | Parsing user code …")

    try:
        model = parse_user_code(
            ode_code=state.ode_code,
            geom_code=state.geom_code if state.geom_enabled else None,
        )
    except Exception as e:
        state.model_valid  = False
        state.model_errors = [str(e)]
        state.log(f"  [FAIL] Parse error: {e}")
        return state

    violations = validate_user_model(model)
    if violations:
        state.model_valid  = False
        state.model_errors = violations
        for v in violations:
            state.log(f"  [CONFIG ERROR] {v}")
        return state

    state.user_model  = model
    state.model_valid = True
    state.log(
        f"  [OK] n_states={model.n_states} | "
        f"geom={model.geom_enabled} | "
        f"params={list(model.bounds.keys())}"
    )
    return state


# ===========================================================================
# TOOL 2 — data_ingestion
# ===========================================================================
def tool_data_ingestion(state: RideOptState) -> RideOptState:
    """
    Load axle CSV files and build road signal interpolants.
    Injects csv_paths and simulation time settings into model.cfg.
    """
    state.log("TOOL 2 | data_ingestion | Loading road signals …")

    model = state.user_model

    # Inject CSV paths into model.cfg
    csv_key_map = {
        "fa_lh":  "axlefront_left_csv",
        "fa_rh":  "axlefront_right_csv",
        "ra1_lh": "axlerear1_left_csv",
        "ra1_rh": "axlerear1_right_csv",
        "ra2_lh": "axlerear2_left_csv",
        "ra2_rh": "axlerear2_right_csv",
    }
    for short, cfg_key in csv_key_map.items():
        if short in state.csv_paths:
            model.cfg[cfg_key] = state.csv_paths[short]

    model.cfg["T_END"]    = state.T_END
    model.cfg["T_IGNORE"] = state.T_IGNORE

    try:
        signals = build_road_signals(model.cfg)
        state.signals        = signals
        state.signals_loaded = True
        state.log(f"  [OK] Signals loaded: {list(signals.keys())}")
    except Exception as e:
        state.signals_error  = str(e)
        state.signals_loaded = False
        state.log(f"  [FAIL] {e}")

    return state


# ===========================================================================
# TOOL 3 — preflight
# ===========================================================================
def tool_preflight(state: RideOptState) -> RideOptState:
    """
    1. Geometry feasibility check
    2. Static equilibrium
    3. Short test integration (3 seconds)
    4. Time estimation
    """
    state.log("TOOL 3 | preflight | Running pre-flight checks …")

    model   = state.user_model
    signals = state.signals

    # ---- 3a. Geometry feasibility ----------------------------------------
    from geometry_checks import run_geometry_checks
    violations = run_geometry_checks(model.cfg)
    geom_ok = len(violations) == 0
    if not geom_ok:
        for v in violations:
            state.log(f"  [GEOM FAIL] {v}")

    # ---- 3b. Static equilibrium ------------------------------------------
    try:
        baseline_params = {k: float(v) for k, v in model.cfg.items()
                           if k in model.bounds}
        x0 = _static_equilibrium(model, baseline_params, signals)
        eq_ok = np.all(np.isfinite(x0))
        state.log(f"  Equilibrium: ||x0||={np.linalg.norm(x0):.4e}")
    except Exception as e:
        eq_ok = False
        state.log(f"  [WARN] Equilibrium failed: {e}")

    # ---- 3c. Test integration (3 second sample) --------------------------
    test_ok    = False
    est_single = 0.0
    est_total  = 0.0
    n_evals    = (state.pop_size * (state.n_gen + 1)
                  if state.opt_mode == "nsga2" else state.n_calls)

    try:
        est_single = estimate_single_eval_time(model, signals, t_sample=3.0)
        est_total  = est_single * n_evals
        test_ok    = True
        mins, secs = divmod(int(est_total), 60)
        state.log(
            f"  Test integration OK | "
            f"est per eval={est_single:.1f}s | "
            f"n_evals={n_evals} | "
            f"Est. total time ≈ {mins}m {secs}s"
        )
    except Exception as e:
        state.log(f"  [WARN] Test integration failed: {e}")

    # ---- 3d. Build result ------------------------------------------------
    passed = geom_ok and test_ok
    pf = PreflightResult(
        passed=passed,
        geometry_ok=geom_ok,
        equilibrium_ok=eq_ok,
        test_integration_ok=test_ok,
        est_seconds_per_eval=est_single,
        est_total_seconds=est_total,
        n_evals_planned=n_evals,
        violations=violations,
        retry_count=state.retry_count,
    )

    if not geom_ok:
        pf.warnings.append("Geometry violations found — check CONFIG values")
    if not eq_ok:
        pf.warnings.append("Static equilibrium solver did not converge — using zero IC")

    state.preflight = pf
    state.log(f"  Preflight {'PASSED' if passed else 'FAILED'}")
    return state


# ===========================================================================
# TOOL 4 — simulation_engine  (called inside optimiser, not a graph node)
# ===========================================================================
def tool_simulation_engine(
    params:  Dict,
    model:   UserModel,
    signals: Dict,
    t_eval:  np.ndarray,
    mode:    str = "ode",      # "ode" | "surrogate"
    log_cb:  Optional[Callable] = None,
) -> pd.DataFrame:
    """
    Single evaluation — runs ODE or surrogate for one parameter set.
    Returns trajectory DataFrame.

    mode="surrogate" is reserved for future use.
    Currently always falls through to ODE.
    """
    # ── Surrogate path (disabled — future) ─────────────────────────────
    # if mode == "surrogate" and model.surrogate is not None:
    #     return tool_surrogate_evaluate(params, model, t_eval, log_cb)

    # ── ODE path (always active) ────────────────────────────────────────
    return run_one_case(params, model, signals, t_eval, log_cb)


# ===========================================================================
# TOOL 5 — objective_calculator  (called inside optimiser, not a graph node)
# ===========================================================================
def tool_objective_calculator(
    df:    pd.DataFrame,
    model: UserModel,
) -> Dict[str, float]:
    """
    Compute cabin seat RMS from a trajectory DataFrame.
    Always returns: rms_z, rms_x, rms_y, rms_total.
    These are the fixed objectives — they never change regardless of ODE.
    """
    return compute_cabin_rms(df, model)


# ===========================================================================
# TOOL 6 — optimiser_tool
# ===========================================================================
def tool_optimiser(
    state:   RideOptState,
    log_cb:  Callable,
) -> RideOptState:
    """
    Runs NSGA-II (multi-objective) or Bayesian (single-objective).
    Internally calls tool_simulation_engine + tool_objective_calculator
    on every candidate evaluation.

    Routing note: this tool does NOT make routing decisions.
    It just runs to completion. The graph node that calls it
    checks the result quality afterward.
    """
    state.log(f"TOOL 6 | optimiser | mode={state.opt_mode} | sim={state.sim_mode}")

    model   = state.user_model
    signals = state.signals
    dt      = float(model.cfg.get("DT", 0.001))
    t_eval  = np.arange(0.0, state.T_END + dt, dt)

    opt_settings = dict(
        pop_size=state.pop_size,
        n_gen=state.n_gen,
        n_calls=state.n_calls,
        n_initial=state.n_initial,
    )

    result = run_optimisation(
        model=model,
        signals=signals,
        t_eval=t_eval,
        mode=state.opt_mode,
        opt_settings=opt_settings,
        log_cb=log_cb,
    )

    state.opt_result = result
    state.opt_done   = True
    state.log(
        f"  Optimisation complete | "
        f"evals={result.n_evals} | "
        f"wall={result.wall_seconds:.1f}s"
    )
    return state


# ===========================================================================
# TOOL 7 — post_processor
# ===========================================================================
def tool_post_processor(state: RideOptState) -> RideOptState:
    """
    1. Generate all plots
    2. Save pareto_front.csv + run_results.json
    3. Build AgentSummary for downstream agents (DFMEA, Expert Assistant)
    """
    state.log("TOOL 7 | post_processor | Generating outputs …")

    model   = state.user_model
    result  = state.opt_result
    signals = state.signals
    out_dir = state.out_dir

    os.makedirs(out_dir, exist_ok=True)
    dt     = float(model.cfg.get("DT", 0.001))
    t_eval = np.arange(0.0, state.T_END + dt, dt)

    # ---- Save CSV and JSON -----------------------------------------------
    csv_path  = os.path.join(out_dir, "pareto_front.csv")
    json_path = os.path.join(out_dir, "run_results.json")

    result.df_pareto.to_csv(csv_path, index=False)

    run_data = {
        "mode":         result.mode,
        "n_evals":      result.n_evals,
        "wall_seconds": result.wall_seconds,
        "param_keys":   result.param_keys,
        "pareto":       result.df_pareto.to_dict(orient="records"),
        "hv_history":   result.hv_history,
        "convergence":  result.convergence,
        "eval_log":     result.eval_log[:500],
        "decisions":    [
            {"node": d.node, "choice": d.choice, "reason": d.reason}
            for d in state.decisions
        ],
    }
    with open(json_path, "w") as f:
        json.dump(run_data, f, indent=2, default=str)

    state.run_data = run_data

    # ---- Generate plots --------------------------------------------------
    try:
        plot_paths      = generate_all_plots(result, model, signals, t_eval, out_dir)
        state.plot_files = [os.path.basename(p) for p in plot_paths if p]
        state.log(f"  Plots saved: {len(state.plot_files)} files")
    except Exception as e:
        state.log(f"  [WARN] Plot generation failed: {e}")
        state.plot_files = []

    state.result_path = out_dir

    # ---- Build AgentSummary (for DFMEA + Expert Assistant agents) --------
    best_row    = result.df_pareto.iloc[0].to_dict() if len(result.df_pareto) > 0 else {}
    best_params = {k: best_row.get(k, 0.0) for k in result.param_keys}
    best_rms    = {
        "rms_z":     float(best_row.get("rms_z",     0.0)),
        "rms_x":     float(best_row.get("rms_x",     0.0)),
        "rms_y":     float(best_row.get("rms_y",     0.0)),
        "rms_total": float(best_row.get("rms_total", 0.0)),
    }

    # Constraint residuals at best solution (for DFMEA)
    constraint_residuals = None
    if model.geom_enabled and model.constraints is not None:
        try:
            q0  = np.zeros(model.n_states // 2)
            inp = _build_inputs(0.0, signals, model.cfg)
            res = model.constraints(0.0, q0, {**model.cfg, **best_params}, inp)
            constraint_residuals = [float(r) for r in res]
        except Exception:
            pass

    warnings = []
    if state.preflight:
        warnings.extend(state.preflight.warnings)

    # Pareto quality warning
    if result.mode == "nsga2" and len(result.hv_history) > 0:
        if result.hv_history[-1] < 0.01:
            warnings.append("Pareto front hypervolume is near zero — results may be degenerate")

    failed_evals = sum(1 for e in result.eval_log if e.get("rms_total", 0) >= 90)
    if failed_evals > len(result.eval_log) * 0.3:
        warnings.append(
            f"{failed_evals}/{len(result.eval_log)} evaluations failed — "
            f"check ODE stability"
        )

    state.agent_summary = AgentSummary(
        status="success" if not warnings else "partial",
        mode=result.mode,
        n_evals=result.n_evals,
        wall_seconds=result.wall_seconds,
        best_params=best_params,
        best_rms=best_rms,
        pareto_size=len(result.df_pareto),
        sim_mode=state.sim_mode,
        geom_enabled=model.geom_enabled,
        result_path=out_dir,
        plot_files=state.plot_files,
        constraint_active=model.geom_enabled,
        constraint_residuals=constraint_residuals,
        hv_history=result.hv_history,
        convergence=result.convergence,
        eval_log_size=len(result.eval_log),
        param_keys=result.param_keys,
        warnings=warnings,
    )

    state.log(
        f"  AgentSummary built | status={state.agent_summary.status} | "
        f"warnings={len(warnings)}"
    )
    return state
