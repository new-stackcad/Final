"""
main.py  (agentic)
==================
FastAPI backend. Calls the Ride Optimisation Agent (LangGraph)
instead of calling solver/optimiser/plotter directly.

Run:  uvicorn main:app --reload --port 8000
"""

from __future__ import annotations
import asyncio, io, json, os, queue, threading, time, uuid, zipfile
from pathlib import Path
from typing import Any, Dict, Optional

from fastapi import FastAPI, BackgroundTasks, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel

from agents.ride_opt_agent import run_ride_opt_agent
from surrogate_check import validate_surrogate, surrogate_params_json_template

app = FastAPI(title="Ride Optimisation — Agentic v2", version="2.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

UPLOAD_DIR  = Path("uploads");  UPLOAD_DIR.mkdir(exist_ok=True)
RESULTS_DIR = Path("results");  RESULTS_DIR.mkdir(exist_ok=True)

_jobs: Dict[str, Dict]              = {}
_log_queues: Dict[str, queue.Queue] = {}


class RunRequest(BaseModel):
    ode_code:     str
    geom_code:    str  = ""
    geom_enabled: bool = False
    mode:      str   = "nsga2"
    pop_size:  int   = 10
    n_gen:     int   = 5
    n_calls:   int   = 50
    n_initial: int   = 10
    T_END:    float = 466.945
    T_IGNORE: float = 0.5
    csv_paths: Dict[str, str] = {}


def _run_job(job_id: str, req: RunRequest):
    job  = _jobs[job_id]
    logq = _log_queues[job_id]
    out_dir = str(RESULTS_DIR / job_id)
    os.makedirs(out_dir, exist_ok=True)
    job["status"] = "running"

    try:
        final_state = run_ride_opt_agent(
            ode_code=req.ode_code, geom_code=req.geom_code,
            geom_enabled=req.geom_enabled, csv_paths=req.csv_paths,
            opt_mode=req.mode, sim_mode="ode",
            pop_size=req.pop_size, n_gen=req.n_gen,
            n_calls=req.n_calls, n_initial=req.n_initial,
            T_END=req.T_END, T_IGNORE=req.T_IGNORE,
            job_id=job_id, out_dir=out_dir, log_queue=logq,
        )

        job["logs"] = final_state.logs

        if final_state.status in ("done", "partial"):
            job["status"]     = "done"
            job["result"]     = final_state.run_data
            job["plot_files"] = final_state.plot_files
            job["out_dir"]    = final_state.result_path or out_dir
            if final_state.agent_summary:
                from dataclasses import asdict
                job["agent_summary"] = asdict(final_state.agent_summary)
            if final_state.preflight:
                job["est_seconds"]   = final_state.preflight.est_total_seconds
                job["n_evals_total"] = final_state.preflight.n_evals_planned
            job["decisions"] = [
                {"node": d.node, "choice": d.choice, "reason": d.reason}
                for d in final_state.decisions
            ]
        else:
            job["status"] = "failed"
            job["error"]  = final_state.error or "Agent returned unknown failure"

    except Exception as e:
        import traceback
        job["status"] = "failed"
        job["error"]  = str(e)
        logq.put(f"[ERROR] {e}\n{traceback.format_exc()}")
    finally:
        try: logq.put_nowait("__DONE__")
        except Exception: pass


@app.get("/")
def root(): return {"message": "Ride Optimisation Agentic API v2"}

@app.post("/upload-csv")
async def upload_csv(file: UploadFile = File(...), key: str = Form(...)):
    name = f"{key}_{uuid.uuid4().hex[:8]}_{file.filename}"
    dest = UPLOAD_DIR / name
    with open(dest, "wb") as f: f.write(await file.read())
    return {"key": key, "server_path": str(dest), "filename": file.filename}

@app.post("/run")
async def start_run(req: RunRequest, background_tasks: BackgroundTasks):
    job_id = uuid.uuid4().hex[:12]
    _jobs[job_id] = {
        "status":"queued","mode":req.mode,"logs":[],"result":None,
        "plot_files":[],"error":None,"agent_summary":None,"decisions":[],
        "est_seconds":None,"n_evals_total":None,"created_at":time.time(),
    }
    _log_queues[job_id] = queue.Queue()
    threading.Thread(target=_run_job, args=(job_id, req), daemon=True).start()
    return {"job_id": job_id, "status": "queued"}

@app.get("/status/{job_id}")
def get_status(job_id: str):
    if job_id not in _jobs: raise HTTPException(404, "Job not found")
    j = _jobs[job_id]
    return {"job_id":job_id,"status":j["status"],"error":j["error"],
            "est_seconds":j.get("est_seconds"),"n_evals_total":j.get("n_evals_total"),
            "plot_count":len(j.get("plot_files",[]))}

@app.get("/stream/{job_id}")
async def stream_logs(job_id: str):
    if job_id not in _jobs: raise HTTPException(404, "Job not found")
    logq = _log_queues[job_id]
    async def gen():
        while True:
            try:
                msg = logq.get(timeout=0.3)
                if msg == "__DONE__": yield "data: __DONE__\n\n"; break
                yield f"data: {msg}\n\n"
            except queue.Empty:
                yield ": keep-alive\n\n"
                await asyncio.sleep(0.1)
                if _jobs.get(job_id,{}).get("status") in ("done","failed"):
                    while not logq.empty():
                        m = logq.get_nowait()
                        if m != "__DONE__": yield f"data: {m}\n\n"
                    yield "data: __DONE__\n\n"; break
    return StreamingResponse(gen(), media_type="text/event-stream")

@app.get("/results/{job_id}")
def get_results(job_id: str):
    if job_id not in _jobs: raise HTTPException(404, "Job not found")
    j = _jobs[job_id]
    if j["status"] != "done": return {"status":j["status"],"error":j["error"]}
    return {"status":"done","result":j["result"]}

@app.get("/decisions/{job_id}")
def get_decisions(job_id: str):
    if job_id not in _jobs: raise HTTPException(404, "Job not found")
    return {"decisions": _jobs[job_id].get("decisions",[])}

@app.get("/agent-summary/{job_id}")
def get_agent_summary(job_id: str):
    if job_id not in _jobs: raise HTTPException(404, "Job not found")
    s = _jobs[job_id].get("agent_summary")
    if not s: raise HTTPException(404, "Not available yet")
    return s

@app.get("/plots/{job_id}")
def list_plots(job_id: str):
    if job_id not in _jobs: raise HTTPException(404, "Job not found")
    return {"plots": _jobs[job_id].get("plot_files",[])}

@app.get("/plot/{job_id}/{filename}")
def serve_plot(job_id: str, filename: str):
    if job_id not in _jobs: raise HTTPException(404, "Job not found")
    path = os.path.join(_jobs[job_id].get("out_dir",""), "plots", filename)
    if not os.path.isfile(path): raise HTTPException(404, f"Not found: {filename}")
    return FileResponse(path, media_type="image/png")

@app.get("/download/{job_id}")
def download_csv(job_id: str):
    if job_id not in _jobs: raise HTTPException(404, "Job not found")
    path = os.path.join(_jobs[job_id].get("out_dir",""), "pareto_front.csv")
    if not os.path.isfile(path): raise HTTPException(404, "CSV not ready")
    return FileResponse(path, media_type="text/csv", filename=f"pareto_front_{job_id}.csv")

@app.get("/download-all/{job_id}")
def download_all(job_id: str):
    if job_id not in _jobs: raise HTTPException(404, "Job not found")
    out_dir = _jobs[job_id].get("out_dir","")
    if not out_dir or not os.path.isdir(out_dir): raise HTTPException(404, "Results not ready")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf,"w",zipfile.ZIP_DEFLATED) as zf:
        for root,_,files in os.walk(out_dir):
            for fname in files:
                fpath = os.path.join(root,fname)
                zf.write(fpath, os.path.relpath(fpath, out_dir))
    buf.seek(0)
    return StreamingResponse(buf, media_type="application/zip",
        headers={"Content-Disposition":f"attachment; filename=results_{job_id}.zip"})

@app.post("/validate-surrogate")
async def validate_surrogate_endpoint(
    model_file: UploadFile=File(...), params_file: UploadFile=File(...), cfg_json: str=Form("{}"),
):
    cfg = json.loads(cfg_json)
    pkl_path    = UPLOAD_DIR / f"surrogate_{uuid.uuid4().hex[:8]}.pkl"
    params_path = UPLOAD_DIR / f"surrogate_params_{uuid.uuid4().hex[:8]}.json"
    with open(pkl_path,"wb") as f: f.write(await model_file.read())
    with open(params_path,"wb") as f: f.write(await params_file.read())
    result = validate_surrogate(str(pkl_path), str(params_path), cfg)
    return {"passed":result.passed,"checks":result.checks,"model_type":result.model_type,
            "ode_version":result.ode_version,"objectives":result.objectives,"summary":result.summary()}

@app.get("/surrogate-template")
def surrogate_template(): return surrogate_params_json_template()
