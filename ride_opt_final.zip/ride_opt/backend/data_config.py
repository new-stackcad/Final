"""
data_config.py
==============
Handles:
  - Default CFG dict (all physical parameters)
  - CSV axle-displacement loading + linear interpolation
  - RoadSignals: axle_inputs() and axle_input_rates()
  - build_road_signals(cfg) -> RoadSignals
"""

from __future__ import annotations
import numpy as np
import pandas as pd
from dataclasses import dataclass
from typing import Callable, Dict, Tuple

# ---------------------------------------------------------------------------
# Simulation time constants (can be overridden via cfg)
# ---------------------------------------------------------------------------
DT       = 0.001          # default numerical-diff step for road rate
T_IGNORE = 0.5            # seconds to skip at start when computing RMS
T_END    = 466.945        # default simulation end time [s]
FS       = 1000           # sample frequency [Hz]

# ---------------------------------------------------------------------------
# Default vehicle configuration
# ---------------------------------------------------------------------------
DEFAULT_CFG: Dict = {
    # ---- CSV paths (user must set these, or upload via frontend) ----
    "axlefront_left_csv":  "",
    "axlefront_right_csv": "",
    "axlerear1_left_csv":  "",
    "axlerear1_right_csv": "",
    "axlerear2_left_csv":  "",
    "axlerear2_right_csv": "",

    # ---- Track geometry ----
    "s1": 0.6277, "s2": 0.6305,
    "WT1": 0.814,  "WT2": 1.047,  "WT3": 1.047,

    # ---- Cabin (unsprung equivalent) ----
    "m_c": 862.0,   "I_xxc": 516.6,  "I_yyc": 1045.0,
    "M_1f": 600.0,  "M_2": 1075.0,   "M_3": 840.0,
    "I_xx1": 650.0, "I_xx2": 1200.0, "I_xx3": 1100.0,

    # ---- Axle track widths ----
    "S_tf2": 1.043, "S_tf3": 1.043,
    "S_f":   0.814,

    # ---- Cabin spring / damper to sprung mass ----
    "C_cfl": 5035.0, "C_cfr": 5035.0,
    "C_crl": 3400.0, "C_crr": 3400.0,
    "K_cfl": 49050.0,"K_cfr": 49050.0,
    "K_crl": 24525.0,"K_crr": 24525.0,

    # ---- Rear axle damping ----
    "C_2": 2000, "C_3": 2000,

    # ---- Leaf spring geometry ----
    "L_DL2": 0.6211, "L_DR2": 0.6211,
    "L_DL3": 0.6251, "L_DR3": 0.6251,
    "beta_L2": 0.1693,  "beta_R2": 0.1693,
    "beta_L3": 0.17453, "beta_R3": 0.17453,

    # ---- Cabin CG offsets ----
    "a": 0.9,  "b": 1.080,
    "l_cfcg": 0.871, "l_crcg": 1.087,
    "hcp": 0.1,

    # ---- Sprung mass (laden) ----
    "lf": 5.05, "L12": 0.54, "L23": 1.96,
    "l_cf": 6.458, "l_cr": 4.5,
    "m_s": 22485.0, "I_syy": 103787.0,
    "I_sxx": 8598.0, "I_sxy": 763.0,
    "hs": 0.68,

    # ---- Parameters to be optimised ----
    "K_f": 474257,   "C_f": 15000,
    "K_2": 1077620,  "K_3": 1077620,

    # ---- Gravity ----
    "g": 9.81,

    # ---- Damper shape ----
    "cs_minus":   0.3,
    "asym_ratio": 3.0,
    "gamma_c":    0.12,
    "gamma_r":    0.09,

    # ---- Baumgarte stabilisation ----
    "baum_omega": 10.0,
    "baum_zeta":  1.0,

    # ---- Simulation time ----
    "T_END":    T_END,
    "T_IGNORE": T_IGNORE,
    "DT":       DT,
    "FS":       FS,
}

# ---------------------------------------------------------------------------
# Optimisation parameter keys + default bounds
# ---------------------------------------------------------------------------
PARAM_KEYS = [
    "K_f", "C_f", "K_2", "K_3",
    "cs_minus", "asym_ratio", "gamma_c", "gamma_r",
]

def default_bounds(cfg: Dict) -> Dict[str, Tuple[float, float]]:
    return {
        "K_f":        (0.879 * cfg["K_f"],  1.126 * cfg["K_f"]),
        "C_f":        (0.44  * cfg["C_f"],  1.4   * cfg["C_f"]),
        "K_2":        (0.892 * cfg["K_2"],  1.116 * cfg["K_2"]),
        "K_3":        (0.892 * cfg["K_3"],  1.116 * cfg["K_3"]),
        "cs_minus":   (0.2,   0.4),
        "asym_ratio": (2.3,   4.0),
        "gamma_c":    (0.08,  0.16),
        "gamma_r":    (0.08,  0.10),
    }

# ---------------------------------------------------------------------------
# CSV loader
# ---------------------------------------------------------------------------
def load_track(csv_path: str) -> Tuple[np.ndarray, np.ndarray]:
    """Read time + displacement columns from axle CSV (skip 2 header rows)."""
    df = pd.read_csv(csv_path, skiprows=2, header=None)
    t  = pd.to_numeric(df.iloc[:, 0], errors="coerce").values
    z  = pd.to_numeric(df.iloc[:, 1], errors="coerce").values
    mask = np.isfinite(t) & np.isfinite(z)
    return t[mask].astype(float), z[mask].astype(float)


def make_linear_interp(x: np.ndarray, y: np.ndarray) -> Callable:
    """Fast piecewise-linear interpolant (clamped at ends)."""
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)

    def f(xq):
        xq   = np.asarray(xq, dtype=float)
        xq_c = np.clip(xq, x[0], x[-1])
        idx  = np.clip(np.searchsorted(x, xq_c) - 1, 0, len(x) - 2)
        x0, x1 = x[idx], x[idx + 1]
        y0, y1 = y[idx], y[idx + 1]
        w = (xq_c - x0) / np.maximum(x1 - x0, 1e-12)
        return y0 * (1.0 - w) + y1 * w
    return f


# ---------------------------------------------------------------------------
# Road signals dataclass
# ---------------------------------------------------------------------------
@dataclass
class RoadSignals:
    f1L: Callable
    f1R: Callable
    f2L: Callable
    f2R: Callable
    f3L: Callable
    f3R: Callable

    def axle_inputs(self, t: float, cfg: Dict):
        zr1L, zr1R = float(self.f1L(t)), float(self.f1R(t))
        zr2L, zr2R = float(self.f2L(t)), float(self.f2R(t))
        zr3L, zr3R = float(self.f3L(t)), float(self.f3R(t))

        z1f  = 0.5 * (zr1L + zr1R)
        z2   = 0.5 * (zr2L + zr2R)
        z3   = 0.5 * (zr3L + zr3R)
        ph_f = (zr1L - zr1R) / cfg["WT1"]
        ph2  = (zr2L - zr2R) / cfg["WT2"]
        ph3  = (zr3L - zr3R) / cfg["WT3"]
        return float(z1f), float(ph_f), float(z2), float(ph2), float(z3), float(ph3)

    def axle_input_rates(self, t: float, cfg: Dict, dt: float = None):
        dt = dt or cfg.get("DT", DT)
        p  = self.axle_inputs(t + dt, cfg)
        m  = self.axle_inputs(t - dt, cfg)
        return tuple((a - b) / (2.0 * dt) for a, b in zip(p, m))


def build_road_signals(cfg: Dict) -> RoadSignals:
    """Load all 6 axle CSV files and return a RoadSignals object."""
    def _load(key):
        return make_linear_interp(*load_track(cfg[key]))

    return RoadSignals(
        f1L=_load("axlefront_left_csv"),
        f1R=_load("axlefront_right_csv"),
        f2L=_load("axlerear1_left_csv"),
        f2R=_load("axlerear1_right_csv"),
        f3L=_load("axlerear2_left_csv"),
        f3R=_load("axlerear2_right_csv"),
    )
