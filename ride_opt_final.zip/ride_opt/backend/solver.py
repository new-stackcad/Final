"""
solver.py
=========
Core ODE physics:
  - TwoStageAsymmetricDamper
  - build_M_R(q, v, t, cfg, road)  -> M [6x6], R [6]
  - rhs_first_order(t, x, cfg, road) -> xdot [12]
  - static_equilibrium_state(cfg, road) -> x0 [12]
  - run_one_case(params, cfg_base, t_eval) -> pd.DataFrame

Also provides:
  - compute_seat_rms(df, cfg) -> float
  - compute_seat_rms_axes(df, cfg) -> dict
"""

from __future__ import annotations
import time
import numpy as np
import pandas as pd
from dataclasses import dataclass
from numpy.linalg import solve as lin_solve
from scipy.integrate import solve_ivp
from scipy.optimize import least_squares
from typing import Dict, Tuple

from data_config import build_road_signals, RoadSignals, DT, T_IGNORE
from geometry import geom_constraints

# State-vector index aliases
ZC, THC, PHC, ZS, THS, PHS = range(6)
STATE_NAMES = ["z_c", "th_c", "ph_c", "z_s", "th_s", "ph_s"]


# ---------------------------------------------------------------------------
# Two-stage asymmetric damper model
# ---------------------------------------------------------------------------
@dataclass
class TwoStageAsymmetricDamper:
    cs_minus:   float
    asym_ratio: float
    gamma_c:    float
    gamma_r:    float
    alpha_c:    float = -0.05
    alpha_r:    float =  0.13

    def force(self, v_rel: float) -> float:
        c_plus = self.asym_ratio * self.cs_minus
        if v_rel < 0.0:
            if v_rel >= self.alpha_c:
                return self.cs_minus * v_rel
            else:
                return self.cs_minus * (
                    self.alpha_c + self.gamma_c * (v_rel - self.alpha_c)
                )
        else:
            if v_rel <= self.alpha_r:
                return c_plus * v_rel
            else:
                return c_plus * (
                    self.alpha_r + self.gamma_r * (v_rel - self.alpha_r)
                )


# ---------------------------------------------------------------------------
# Mass matrix + generalised force vector
# ---------------------------------------------------------------------------
def build_M_R(
    q: np.ndarray,
    v: np.ndarray,
    t: float,
    cfg: Dict,
    road: RoadSignals,
) -> Tuple[np.ndarray, np.ndarray]:
    """Return (M [6x6], R [6]) for the constrained system."""

    z_c, th_c, ph_c, z_s, th_s, ph_s = q
    dz_c, dth_c, dph_c, dz_s, dth_s, dph_s = v

    z1f, ph_f, z2, ph2, z3, ph3 = road.axle_inputs(t, cfg)
    dz1f, dph_f, dz2, dph2, dz3, dph3 = road.axle_input_rates(t, cfg)

    phi_NRS2 = (
        cfg["beta_L2"] * cfg["L_DL2"] - cfg["beta_R2"] * cfg["L_DR2"]
    ) / max(cfg["S_tf2"], 1e-6)
    phi_NRS3 = (
        cfg["beta_L3"] * cfg["L_DL3"] - cfg["beta_R3"] * cfg["L_DR3"]
    ) / max(cfg["S_tf3"], 1e-6)

    m_c, I_xxc, I_yyc     = cfg["m_c"],  cfg["I_xxc"], cfg["I_yyc"]
    m_s, I_sxx, I_syy, I_sxy = cfg["m_s"], cfg["I_sxx"], cfg["I_syy"], cfg["I_sxy"]
    S1, S2, S3             = cfg["S_f"],   cfg["S_tf2"], cfg["S_tf3"]
    a, b                   = cfg["a"],     cfg["b"]
    hs, g                  = cfg["hs"],    cfg["g"]
    l_cfcg, l_crcg         = cfg["l_cfcg"], cfg["l_crcg"]
    l_cf, l_cr             = cfg["l_cf"],   cfg["l_cr"]
    lf                     = cfg["lf"]
    hcp                    = cfg["hcp"]
    l2                     = cfg["L12"]
    l3                     = cfg["L12"] + cfg["L23"]

    beta_L2, beta_R2 = cfg["beta_L2"], cfg["beta_R2"]
    beta_L3, beta_R3 = cfg["beta_L3"], cfg["beta_R3"]
    L_DL2, L_DR2     = cfg["L_DL2"],   cfg["L_DR2"]
    L_DL3, L_DR3     = cfg["L_DL3"],   cfg["L_DR3"]

    Kcfl, Kcfr, Kcrl, Kcrr = cfg["K_cfl"], cfg["K_cfr"], cfg["K_crl"], cfg["K_crr"]
    Ccfl, Ccfr, Ccrl, Ccrr = cfg["C_cfl"], cfg["C_cfr"], cfg["C_crl"], cfg["C_crr"]
    K_f, C_f = cfg["K_f"], cfg["C_f"]
    K_2, C_2 = cfg["K_2"], cfg["C_2"]
    K_3, C_3 = cfg["K_3"], cfg["C_3"]

    # ---- Mass matrix ----
    M = np.zeros((6, 6), dtype=float)
    M[ZC,  ZC]  = m_c
    M[THC, THC] = I_yyc
    M[PHC, PHC] = I_xxc
    M[ZS,  ZS]  = m_s
    M[THS, THS] = I_syy
    M[THS, PHS] = I_sxy
    M[PHS, THS] = I_sxy
    M[PHS, PHS] = I_sxx + m_s * hs ** 2

    # ---- Damper force ----
    front_damper = TwoStageAsymmetricDamper(
        cs_minus=cfg["cs_minus"],   asym_ratio=cfg["asym_ratio"],
        gamma_c=cfg["gamma_c"],     gamma_r=cfg["gamma_r"],
    )
    v_f  = dz_s - lf * dth_s - dz1f
    F_df = C_f * front_damper.force(v_f)

    Csum = Ccfl + Ccfr + Ccrl + Ccrr
    Ksum = Kcfl + Kcfr + Kcrl + Kcrr

    # ---- Generalised force vector ----
    R = np.zeros(6, dtype=float)

    R[ZC] = (
        + Csum*(dz_c - dz_s) + Ksum*(z_c - z_s)
        - (Ccfl*l_cfcg + Ccfr*l_cfcg - Ccrl*l_crcg - Ccrr*l_crcg)*dth_c
        - (-Ccfl*l_cf - Ccfr*l_cf - Ccrl*l_cr - Ccrr*l_cr)*dth_s
        - (-Ccfl*b + Ccfr*a - Ccrl*b + Ccrr*a)*dph_c
        - (Ccfl*b - Ccfr*a + Ccrl*b - Ccrr*a)*dph_s
        - (Kcfl*l_cfcg + Kcfr*l_cfcg - Kcrl*l_crcg - Kcrr*l_crcg)*th_c
        - (-Kcfl*l_cf - Kcfr*l_cf - Kcrl*l_cr - Kcrr*l_cr)*th_s
        - (-Kcfl*b + Kcfr*a - Kcrl*b + Kcrr*a)*ph_c
        - (Kcfl*b - Kcfr*a + Kcrl*b - Kcrr*a)*ph_s
    )

    R[THC] = (
        - (Ccfl*l_cfcg + Ccfr*l_cfcg - Ccrl*l_crcg - Ccrr*l_crcg)*dz_c
        - (-Ccfl*l_cfcg - Ccfr*l_cfcg - Ccrl*l_crcg - Ccrr*l_crcg)*dz_s
        - (Kcfl*l_cfcg + Kcfr*l_cfcg - Kcrl*l_crcg - Kcrr*l_crcg)*z_c
        - (-Kcfl*l_cfcg - Kcfr*l_cfcg - Kcrl*l_crcg - Kcrr*l_crcg)*z_s
        - (-Ccfl*l_cfcg**2 - Ccfr*l_cfcg**2 - Ccrl*l_crcg**2 - Ccrr*l_crcg**2)*dth_c
        - (Ccfl*l_cfcg*l_cf + Ccfr*l_cfcg*l_cf - Ccrl*l_crcg*l_cr - Ccrr*l_crcg*l_cr)*dth_s
        - (-Ccfl*l_cfcg*b + Ccfr*l_cfcg*a - Ccrl*l_crcg*b + Ccrr*l_crcg*a)*dph_c
        - (Ccfl*l_cfcg*b - Ccfr*l_cfcg*a + Ccrl*l_crcg*b - Ccrr*l_crcg*a)*dph_s
        - (-Kcfl*l_cfcg**2 - Kcfr*l_cfcg**2 - Kcrl*l_crcg**2 - Kcrr*l_crcg**2 + m_c*g*hcp)*th_c
        - (Kcfl*l_cfcg*l_cf + Kcfr*l_cfcg*l_cf - Kcrl*l_crcg*l_cr - Kcrr*l_crcg*l_cr)*th_s
        - (-Kcfl*l_cfcg*b + Kcfr*l_cfcg*a - Kcrl*l_crcg*b + Kcrr*l_crcg*a)*ph_c
        - (Kcfl*l_cfcg*b - Kcfr*l_cfcg*a + Kcrl*l_crcg*b - Kcrr*l_crcg*a)*ph_s
    )

    R[PHC] = (
        - (-Ccfl*b + Ccfr*a - Ccrl*b + Ccrr*a)*dz_c
        - (Ccfl*b - Ccfr*a + Ccrl*b - Ccrr*a)*dz_s
        - (-Kcfl*b + Kcfr*a - Kcrl*b + Kcrr*a)*z_c
        - (Kcfl*b - Kcfr*a + Kcrl*b - Kcrr*a)*z_s
        - (-Ccfl*l_cfcg*b - Ccfr*l_cfcg*a + Ccrl*l_crcg*b + Ccrr*l_crcg*a)*dth_c
        - (Ccfl*l_cfcg*b + Ccfr*l_cfcg*a - Ccrl*l_crcg*b - Ccrr*l_crcg*a)*dth_s
        - (-Ccfl*b**2 + Ccfr*a**2 - Ccrl*b**2 + Ccrr*a**2)*dph_c
        - (Ccfl*b**2 - Ccfr*a**2 + Ccrl*b**2 - Ccrr*a**2)*dph_s
        - (-Kcfl*l_cfcg*b - Kcfr*l_cfcg*a + Kcrl*l_crcg*b + Kcrr*l_crcg*a)*th_c
        - (Kcfl*l_cfcg*b + Kcfr*l_cfcg*a - Kcrl*l_crcg*b - Kcrr*l_crcg*a)*th_s
        - (-Kcfl*b**2 + Kcfr*a**2 - Kcrl*b**2 + Kcrr*a**2)*ph_c
        - (Kcfl*b**2 - Kcfr*a**2 + Kcrl*b**2 - Kcrr*a**2)*ph_s
    )

    R[ZS] = (
        - (Ccfl + Ccfr + Ccrl + Ccrr)*dz_c
        - (-Ccfl*l_cfcg - Ccfr*l_cfcg + Ccrl*l_crcg + Ccrr*l_crcg)*dth_c
        - (-Ccfl - Ccfr - Ccrl - Ccrr)*dz_s
        - (Ccfl*l_cf + Ccfr*l_cf + Ccrl*l_cr + Ccrr*l_cr)*dth_s
        - (Kcfl + Kcfr + Kcrl + Kcrr)*z_c
        - (-Kcfl*l_cfcg - Kcfr*l_cfcg + Kcrl*l_crcg + Kcrr*l_crcg)*th_c
        - (-Kcfl - Kcfr - Kcrl - Kcrr)*z_s
        - (Kcfl*l_cf + Kcfr*l_cf + Kcrl*l_cr + Kcrr*l_cr)*th_s
        + K_f*(z_s - lf*th_s - z1f) + F_df
        + K_2*(z_s - z2 - beta_L2*L_DL2 - beta_R2*L_DR2 + l2*th_s) + C_2*(dz_s - dz2 + l2*dth_s)
        + K_3*(z_s - z3 - beta_L3*L_DL3 - beta_R3*L_DR3 + l3*th_s) + C_3*(dz_s - dz3 + l3*dth_s)
    )

    R[THS] = (
        - (Ccfl*l_cfcg + Ccfr*l_cfcg - Ccrl*l_crcg - Ccrr*l_crcg)*dz_c
        - (-Ccfl*l_cfcg**2 - Ccfr*l_cfcg**2 - Ccrl*l_crcg**2 - Ccrr*l_crcg**2)*dth_c
        - (-Ccfl*l_cf - Ccfr*l_cf - Ccrl*l_cr - Ccrr*l_cr)*dz_s
        - (Ccfl*l_cfcg*l_cf + Ccfr*l_cfcg*l_cf - Ccrl*l_crcg*l_cr - Ccrr*l_crcg*l_cr)*dth_s
        - (Kcfl*l_cf + Kcfr*l_cf + Kcrl*l_cr + Kcrr*l_cr)*z_c
        - (-Kcfl*l_cfcg*l_cf - Kcfr*l_cfcg*l_cf + Kcrl*l_crcg*l_cr + Kcrr*l_crcg*l_cr)*th_c
        - (-Kcfl*l_cf - Kcfr*l_cf - Kcrl*l_cr - Kcrr*l_cr)*z_s
        - (Kcfl*l_cf**2 + Kcfr*l_cf**2 + Kcrl*l_cr**2 + Kcrr*l_cr**2)*th_s
        - lf*(K_f*(z_s - lf*th_s - z1f) + F_df)
        + l2*(K_2*(z_s - z2 - beta_L2*L_DL2 - beta_R2*L_DR2 + l2*th_s) + C_2*(dz_s - dz2 + l2*dth_s))
        + l3*(K_3*(z_s - z3 - beta_L3*L_DL3 - beta_R3*L_DR3 + l3*th_s) + C_3*(dz_s - dz3 + l3*dth_s))
    )

    k_tf = 0.5 * K_f * S1**2;   C_tf = 0.5 * C_f * S1**2
    K_r1 = 0.5 * K_2 * S2**2;   C_r1 = 0.5 * C_2 * S2**2
    K_r2 = 0.5 * K_3 * S3**2;   C_r2 = 0.5 * C_3 * S3**2

    R[PHS] = (
        + m_s * g * hs * ph_s
        - k_tf*(ph_s - ph_f)  - C_tf*(dph_s - dph_f)
        - K_r1*(ph_s - ph2 - phi_NRS2) - C_r1*(dph_s - dph2)
        - K_r2*(ph_s - ph3 - phi_NRS3) - C_r2*(dph_s - dph3)
    )
    R[PHS] *= -1.0

    return M, R


# ---------------------------------------------------------------------------
# First-order ODE RHS (Baumgarte stabilised)
# ---------------------------------------------------------------------------
def rhs_first_order(
    t: float, x: np.ndarray, cfg: Dict, road: RoadSignals
) -> np.ndarray:
    q, v = x[:6], x[6:]
    M, R = build_M_R(q, v, t, cfg, road)
    gq, G = geom_constraints(q, t, cfg, road)

    w, zeta = cfg["baum_omega"], cfg["baum_zeta"]
    gamma   = w**2 * gq + 2 * zeta * w * (G @ v)

    nc  = G.shape[0]
    A   = np.zeros((6 + nc, 6 + nc), dtype=float)
    b   = np.zeros(6 + nc, dtype=float)
    A[:6, :6] = M;  A[:6, 6:] = G.T
    A[6:, :6] = G
    b[:6] = -R;     b[6:] = -gamma

    qdd      = lin_solve(A, b)[:6]
    xdot     = np.zeros_like(x)
    xdot[:6] = v
    xdot[6:] = qdd
    return xdot


# ---------------------------------------------------------------------------
# Static equilibrium
# ---------------------------------------------------------------------------
def static_equilibrium_state(cfg: Dict, road: RoadSignals) -> np.ndarray:
    t0 = 0.0
    q0 = np.zeros(6, dtype=float)

    def F(y):
        q   = y[:6];  lam = y[6:]
        M_, R_ = build_M_R(q, np.zeros(6), t0, cfg, road)
        gq, G  = geom_constraints(q, t0, cfg, road)
        return np.hstack([R_ + G.T @ lam, 1e3 * gq])

    lsq = least_squares(
        F, np.zeros(8), method="trf", loss="soft_l1",
        xtol=1e-12, ftol=1e-12, gtol=1e-12, max_nfev=800,
    )

    if lsq.success:
        return np.hstack([lsq.x[:6], np.zeros(6)])

    # Fallback: dynamic relaxation
    cfg_r = dict(cfg)
    for k in ("C_2", "C_3", "C_cfl", "C_cfr", "C_crl", "C_crr"):
        cfg_r[k] = cfg[k] * 20.0
    sol = solve_ivp(
        lambda t, x: rhs_first_order(t, x, cfg_r, road),
        (0.0, 3.0), np.zeros(12), method="Radau",
        rtol=1e-7, atol=1e-9,
    )
    q_relax = sol.y[:6, -1]
    lsq2 = least_squares(
        F, np.hstack([q_relax, np.zeros(2)]), method="trf", loss="soft_l1",
        xtol=1e-12, ftol=1e-12, gtol=1e-12, max_nfev=400,
    )
    q0 = lsq2.x[:6] if lsq2.success else q_relax
    return np.hstack([q0, np.zeros(6)])


# ---------------------------------------------------------------------------
# Main simulation runner
# ---------------------------------------------------------------------------
def run_one_case(
    params: Dict,
    cfg_base: Dict,
    t_eval: np.ndarray,
    log_cb=None,           # optional callable(msg: str) for progress streaming
) -> pd.DataFrame:
    """
    Merge params into cfg_base, integrate ODE, return DataFrame of states.

    Parameters
    ----------
    params   : dict of optimisation parameters to override in cfg_base
    cfg_base : full vehicle config dict
    t_eval   : time array [s]
    log_cb   : optional callable for streaming log lines to frontend
    """
    cfg = {**cfg_base, **params}
    road = build_road_signals(cfg)

    def _log(msg):
        if log_cb:
            log_cb(msg)

    _log("Building road signals …")
    x0 = static_equilibrium_state(cfg, road)
    _log(f"Static equilibrium OK  ||q0||={np.linalg.norm(x0[:6]):.3e}")

    t0, tf = float(t_eval[0]), float(t_eval[-1])
    _log(f"Integrating (Radau)  T_end={tf:.2f} s  dt={t_eval[1]-t_eval[0]:.4f} s")
    wall = time.time()

    sol = solve_ivp(
        fun=lambda t, x: rhs_first_order(t, x, cfg, road),
        t_span=(t0, tf),
        y0=x0,
        t_eval=t_eval,
        method="Radau",
        max_step=0.01,
        rtol=1e-6,
        atol=1e-8,
    )

    _log(f"solve_ivp: success={sol.success}  nfev={sol.nfev}  wall={time.time()-wall:.1f}s")

    if sol.status != 0 or not np.all(np.isfinite(sol.y)):
        raise RuntimeError(f"ODE integration failed: {sol.message}")

    rows = []
    for i, t in enumerate(sol.t):
        x   = sol.y[:, i]
        q   = x[:6];  v = x[6:]
        qdd = rhs_first_order(t, x, cfg, road)[6:]
        row = {"t": t}
        for j, name in enumerate(STATE_NAMES):
            row[name]           = q[j]
            row[f"qd_{name}"]   = v[j]
            row[f"qdd_{name}"]  = qdd[j]
        rows.append(row)

    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Objective / RMS helpers
# ---------------------------------------------------------------------------
def compute_seat_rms(df: pd.DataFrame, cfg: Dict) -> float:
    """Combined 3-axis seat-point RMS (ISO 2631-style scalar)."""
    mask = df["t"] >= cfg.get("T_IGNORE", T_IGNORE)
    h    = cfg["hcp"]
    az   = df.loc[mask, "qdd_z_c"].values
    ax   = -h * df.loc[mask, "qdd_th_c"].values
    ay   =  h * df.loc[mask, "qdd_ph_c"].values
    return float(np.sqrt(np.mean(az**2) + np.mean(ax**2) + np.mean(ay**2)))


def compute_seat_rms_axes(df: pd.DataFrame, cfg: Dict) -> Dict[str, float]:
    """Per-axis RMS values for diagnostics and plotting."""
    mask = df["t"] >= cfg.get("T_IGNORE", T_IGNORE)
    h    = cfg["hcp"]
    az   = df.loc[mask, "qdd_z_c"].values
    ax   = -h * df.loc[mask, "qdd_th_c"].values
    ay   =  h * df.loc[mask, "qdd_ph_c"].values
    return {
        "rms_z":     float(np.sqrt(np.mean(az**2))),
        "rms_x":     float(np.sqrt(np.mean(ax**2))),
        "rms_y":     float(np.sqrt(np.mean(ay**2))),
        "rms_total": float(np.sqrt(np.mean(az**2) + np.mean(ax**2) + np.mean(ay**2))),
    }
