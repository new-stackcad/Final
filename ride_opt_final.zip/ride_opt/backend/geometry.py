"""
geometry.py
===========
Geometric / inequality constraints for the 6-DOF ride model.

  geom_constraints(q, t, cfg, road)
      -> (g_vec [2], G_mat [2x6])

  check_geometric_feasibility(cfg)
      -> list of violation strings (empty = OK)

These functions decide config validity before the expensive ODE solve.
"""

from __future__ import annotations
import numpy as np
from typing import Dict, List, Tuple

from data_config import RoadSignals

# State-vector index aliases
ZC, THC, PHC, ZS, THS, PHS = range(6)


# ---------------------------------------------------------------------------
# Baumgarte-stabilised holonomic constraints
# ---------------------------------------------------------------------------
def geom_constraints(
    q: np.ndarray,
    t: float,
    cfg: Dict,
    road: RoadSignals,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Two holonomic constraints (leaf-spring geometric compatibility).

    Returns
    -------
    g : (2,)  constraint residuals
    G : (2,6) constraint Jacobian  dg/dq
    """
    z_s, th_s, ph_s = q[ZS], q[THS], q[PHS]

    _, _, z2, ph2, z3, ph3 = road.axle_inputs(t, cfg)

    l2 = cfg["L12"]
    l3 = cfg["L12"] + cfg["L23"]

    S2, S3 = cfg["S_tf2"], cfg["S_tf3"]
    sl2, sl3 = cfg["s1"], cfg["s2"]
    bL2, bL3 = cfg["beta_L2"], cfg["beta_L3"]

    g2 = (
        z_s + l2 * th_s + S2 * ph_s
        - sl2 * np.sin(bL2 - th_s)
        - (z2 + 0.5 * cfg["WT2"] * ph2)
    )
    g3 = (
        z_s + l3 * th_s + S3 * ph_s
        - sl3 * np.sin(bL3 - th_s)
        - (z3 + 0.5 * cfg["WT3"] * ph3)
    )

    g = np.array([g2, g3], dtype=float)

    # Jacobian dg/dq  (6 DOFs)
    G = np.zeros((2, 6), dtype=float)

    G[0, ZS]  = 1.0
    G[0, THS] = l2 + sl2 * np.cos(bL2 - th_s)
    G[0, PHS] = S2

    G[1, ZS]  = 1.0
    G[1, THS] = l3 + sl3 * np.cos(bL3 - th_s)
    G[1, PHS] = S3

    return g, G


# ---------------------------------------------------------------------------
# Pre-flight feasibility checks
# ---------------------------------------------------------------------------
def check_geometric_feasibility(cfg: Dict) -> List[str]:
    """
    Run lightweight checks on cfg before triggering the ODE solve.

    Returns a list of human-readable violation strings.
    Empty list  =>  all checks passed.
    """
    violations: List[str] = []

    def _check(cond: bool, msg: str):
        if not cond:
            violations.append(msg)

    # ---- positive masses ----
    _check(cfg["m_s"] > 0,  f"m_s must be positive, got {cfg['m_s']}")
    _check(cfg["m_c"] > 0,  f"m_c must be positive, got {cfg['m_c']}")

    # ---- positive stiffnesses ----
    for k in ("K_f", "K_2", "K_3", "K_cfl", "K_cfr", "K_crl", "K_crr"):
        _check(cfg[k] > 0, f"{k} must be positive, got {cfg[k]}")

    # ---- positive damping ----
    for k in ("C_f", "C_2", "C_3", "C_cfl", "C_cfr", "C_crl", "C_crr"):
        _check(cfg[k] >= 0, f"{k} must be non-negative, got {cfg[k]}")

    # ---- damper shape ----
    _check(cfg["cs_minus"]   > 0,   f"cs_minus must be > 0, got {cfg['cs_minus']}")
    _check(cfg["asym_ratio"] > 1.0, f"asym_ratio must be > 1, got {cfg['asym_ratio']}")
    _check(0 < cfg["gamma_c"] < 1,  f"gamma_c must be in (0,1), got {cfg['gamma_c']}")
    _check(0 < cfg["gamma_r"] < 1,  f"gamma_r must be in (0,1), got {cfg['gamma_r']}")

    # ---- track widths ----
    for k in ("WT1", "WT2", "WT3"):
        _check(cfg[k] > 0, f"{k} must be positive, got {cfg[k]}")

    # ---- geometry distances ----
    for k in ("lf", "L12", "L23", "l_cf", "l_cr"):
        _check(cfg[k] > 0, f"{k} must be positive, got {cfg[k]}")

    # ---- Baumgarte ----
    _check(cfg["baum_omega"] > 0, f"baum_omega must be > 0, got {cfg['baum_omega']}")
    _check(cfg["baum_zeta"]  > 0, f"baum_zeta must be > 0, got {cfg['baum_zeta']}")

    # ---- inertia tensor positive-definiteness (diagonal dominance check) ----
    Is = cfg["I_sxx"] * cfg["I_syy"] - cfg["I_sxy"] ** 2
    _check(Is > 0, f"Sprung-mass inertia tensor not PD: det={Is:.3g}")

    # ---- CSV paths present ----
    import os
    csv_keys = [
        "axlefront_left_csv", "axlefront_right_csv",
        "axlerear1_left_csv",  "axlerear1_right_csv",
        "axlerear2_left_csv",  "axlerear2_right_csv",
    ]
    for k in csv_keys:
        path = cfg.get(k, "")
        if not path:
            violations.append(f"CSV path '{k}' is empty.")
        elif not os.path.isfile(path):
            violations.append(f"CSV file not found: {path}")

    return violations
