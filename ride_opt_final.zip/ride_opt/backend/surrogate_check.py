"""
surrogate_check.py
==================
Surrogate model validation — runs when a user uploads model.pkl + params.json.
The surrogate is DISABLED by default. This module only validates.

validate_surrogate(pkl_path, params_json_path, cfg) -> SurrogateValidation
"""

from __future__ import annotations
import json, hashlib, os
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from data_config import PARAM_KEYS, default_bounds


@dataclass
class SurrogateValidation:
    passed: bool
    checks: List[Dict]        # each: {name, passed, detail}
    model_type: str = ""
    ode_version: str = ""
    objectives: List[str] = field(default_factory=list)

    def summary(self) -> str:
        lines = [f"Surrogate validation {'PASSED' if self.passed else 'FAILED'}:"]
        for c in self.checks:
            icon = "✓" if c["passed"] else "✗"
            lines.append(f"  {icon} {c['name']}: {c['detail']}")
        return "\n".join(lines)


def validate_surrogate(
    pkl_path: str,
    params_json_path: str,
    cfg: Dict,
) -> SurrogateValidation:
    """
    Run all validation checks on a user-uploaded surrogate model.

    Checks
    ------
    1. params.json exists and is valid JSON
    2. param_names match ODE PARAM_KEYS (same names, same order)
    3. param_bounds are within or equal to ODE bounds
    4. feature_order is declared
    5. model_type is declared
    6. training_data_hash is present
    7. ode_version is declared
    8. objectives list is present
    9. scaler_params are present
    10. model.pkl file exists and is loadable
    """
    checks: List[Dict] = []
    meta: Dict = {}

    def _c(name: str, ok: bool, detail: str):
        checks.append({"name": name, "passed": ok, "detail": detail})

    # ---- 1. params.json readable ----
    try:
        with open(params_json_path, "r") as f:
            meta = json.load(f)
        _c("params.json readable", True, "Loaded successfully")
    except Exception as e:
        _c("params.json readable", False, str(e))
        return SurrogateValidation(passed=False, checks=checks)

    # ---- 2. param_names ----
    declared = meta.get("param_names", [])
    names_ok  = declared == PARAM_KEYS
    _c("param_names match ODE",
       names_ok,
       f"declared={declared}" if not names_ok else f"{declared}")

    # ---- 3. param_bounds ----
    ode_bounds = default_bounds(cfg)
    declared_bounds = meta.get("param_bounds", {})
    bounds_ok = True
    bounds_detail = []
    for k in PARAM_KEYS:
        if k not in declared_bounds:
            bounds_ok = False
            bounds_detail.append(f"{k} missing")
            continue
        lo_d, hi_d = declared_bounds[k]
        lo_o, hi_o = ode_bounds[k]
        if lo_d < lo_o * 0.99 or hi_d > hi_o * 1.01:
            bounds_ok = False
            bounds_detail.append(f"{k}: surrogate [{lo_d:.1f},{hi_d:.1f}] vs ODE [{lo_o:.1f},{hi_o:.1f}]")
    _c("param_bounds within ODE bounds",
       bounds_ok,
       "OK" if bounds_ok else "; ".join(bounds_detail))

    # ---- 4. feature_order ----
    fo = meta.get("feature_order", [])
    _c("feature_order declared", bool(fo), f"{fo}" if fo else "missing")

    # ---- 5. model_type ----
    mt = meta.get("model_type", "")
    _c("model_type declared", bool(mt), mt if mt else "missing")

    # ---- 6. training_data_hash ----
    tdh = meta.get("training_data_hash", "")
    _c("training_data_hash present", bool(tdh), tdh[:12] + "…" if tdh else "missing")

    # ---- 7. ode_version ----
    ov = meta.get("ode_version", "")
    _c("ode_version declared", bool(ov), ov if ov else "missing")

    # ---- 8. objectives ----
    objs = meta.get("objectives", [])
    _c("objectives declared", bool(objs), f"{objs}" if objs else "missing")

    # ---- 9. scaler_params ----
    sp = meta.get("scaler_params", {})
    _c("scaler_params present", bool(sp), "OK" if sp else "missing")

    # ---- 10. pkl loadable ----
    try:
        import pickle
        with open(pkl_path, "rb") as f:
            _ = pickle.load(f)
        _c("model.pkl loadable", True, "Loaded OK")
    except Exception as e:
        _c("model.pkl loadable", False, str(e))

    all_passed = all(c["passed"] for c in checks)
    return SurrogateValidation(
        passed=all_passed,
        checks=checks,
        model_type=meta.get("model_type", ""),
        ode_version=meta.get("ode_version", ""),
        objectives=meta.get("objectives", []),
    )


def surrogate_params_json_template() -> Dict:
    """Return a template params.json for users to fill in when training a surrogate."""
    return {
        "param_names":        PARAM_KEYS,
        "param_bounds":       {k: [0.0, 1.0] for k in PARAM_KEYS},
        "feature_order":      PARAM_KEYS,
        "model_type":         "GaussianProcess",
        "training_data_hash": "sha256-of-training-csv",
        "ode_version":        "1.0.0",
        "objectives":         ["rms_z", "rms_x", "rms_y"],
        "scaler_params":      {
            "method": "standard",
            "mean":   {k: 0.0 for k in PARAM_KEYS},
            "std":    {k: 1.0 for k in PARAM_KEYS},
        },
    }
