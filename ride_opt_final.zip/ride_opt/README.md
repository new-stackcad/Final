# Ride Optimisation — Complete Setup & Run Guide

A fully automated web app for 6-DOF vehicle ride optimisation.
ODE-based primary solver. Two optimisation modes. No agents, no LLM, no GitHub.

---

## Project Structure

```
ride_opt/
├── backend/
│   ├── data_config.py       # CSV loading, road signals, DEFAULT_CFG
│   ├── geometry.py          # Geometric constraints, pre-flight checks
│   ├── solver.py            # Mass matrix, ODE RHS, run_one_case
│   ├── optimiser.py         # NSGA-II (multi) + Bayesian (single)
│   ├── plotter.py           # All plots, auto-generated
│   ├── surrogate_check.py   # Surrogate validation (disabled by default)
│   └── main.py              # FastAPI server
├── frontend/
│   ├── index.html
│   ├── package.json
│   ├── vite.config.js
│   └── src/
│       ├── main.jsx
│       ├── App.jsx
│       └── index.css
├── requirements.txt
└── README.md
```

---

## Step 1 — Python environment

```bash
# Create virtual environment (Python 3.10 or 3.11 recommended)
python -m venv venv

# Activate
# Windows:
venv\Scripts\activate
# macOS / Linux:
source venv/bin/activate
```

---

## Step 2 — Install all Python dependencies

```bash
pip install -r requirements.txt
```

This installs:

| Package | Purpose |
|---|---|
| numpy, scipy, pandas | Core numerics |
| matplotlib | All plot generation |
| pymoo | NSGA-II multi-objective optimiser |
| scikit-optimize | Bayesian single-objective optimiser |
| scikit-learn | Required by scikit-optimize |
| fastapi | Web API framework |
| uvicorn | ASGI server to run FastAPI |
| python-multipart | File upload support in FastAPI |
| pydantic | Request/response validation |

---

## Step 3 — Install Node.js (for the frontend)

Download from https://nodejs.org (LTS version, 18 or 20).

Verify:
```bash
node --version   # should print v18.x or v20.x
npm --version
```

---

## Step 4 — Install frontend dependencies

```bash
cd ride_opt/frontend
npm install
```

This installs React, Vite, Monaco Editor (the code editor), and Axios.

---

## Step 5 — Start the backend

Open a terminal, activate your venv, then:

```bash
cd ride_opt/backend
uvicorn main:app --reload --port 8000
```

You should see:
```
INFO:     Uvicorn running on http://127.0.0.1:8000
INFO:     Application startup complete.
```

Leave this terminal running.

---

## Step 6 — Start the frontend

Open a second terminal:

```bash
cd ride_opt/frontend
npm run dev
```

You should see:
```
VITE  ready in 300ms
➜  Local:   http://localhost:3000/
```

Open http://localhost:3000 in your browser.

---

## Step 7 — Using the app

### ODE Setup tab

**Left panel — Code editor**
- Edit the `CONFIG` dict directly in the Python-style editor.
- All keys map to the vehicle physics parameters.
- The editor validates the config in real time — a green badge means it parsed correctly.

**Left panel — CSV upload**
- Upload all 6 axle displacement CSV files by clicking or drag-and-drop.
- Files are uploaded to the backend immediately.
- All 6 must be uploaded before the Run button activates.

**Right panel — Optimiser settings**

Choose the mode first:

| Mode | Use when | Output |
|---|---|---|
| **Multi-objective (NSGA-II)** | You want to see trade-offs between RMS_z, RMS_x, RMS_y | Full Pareto front |
| **Single-objective (Bayesian)** | You want one best combined RMS solution | Single best params |

NSGA-II settings:
- `Population size` — number of candidates per generation (default 10)
- `Generations` — number of evolutionary steps (default 5)
- Total evaluations ≈ pop_size × (n_gen + 1)

Bayesian settings:
- `Total calls` — total ODE evaluations (default 50)
- `Initial points` — random initial samples before GP fitting (default 10)

Simulation time:
- `T_END` — end time in seconds (default 466.945 — matches your data)
- `T_IGNORE` — seconds to skip at start when computing RMS (default 0.5)

**Click ▶ Run Optimisation**

The live log panel streams every evaluation in real time.

---

### Results tab

Opens automatically when the run completes.

**Left side:**
- Pareto front table (all non-dominated solutions, sorted by RMS_total)
- Run summary (n_evals, wall time, mode)
- Best solution parameter values
- Download buttons: CSV of Pareto front, ZIP of all results + plots

**Right side — Plots:**
Click any plot button to view it inline.

| Plot | Available in |
|---|---|
| pareto_rms_z_rms_x | NSGA-II |
| pareto_rms_z_rms_y | NSGA-II |
| pareto_rms_x_rms_y | NSGA-II |
| pareto_3d | NSGA-II |
| convergence_hv | NSGA-II |
| generation_scatter | NSGA-II |
| convergence_bayesian | Bayesian |
| param_parallel | Both |
| pareto_rms_bars | Both |
| seat_accel_Best_total | Both |
| seat_accel_Best_vertical | NSGA-II |
| seat_accel_Best_longitudinal | NSGA-II |
| seat_accel_Best_lateral | NSGA-II |

---

### Surrogate tab

This tab is **disabled by default**. The ODE is always the solver.

You can use this tab to pre-validate a surrogate model file before any future development:
1. Upload your `model.pkl` and `params.json`
2. Click **Validate**
3. The app checks 10 things (param names, bounds, model type, hash, version, etc.)
4. Nothing runs — it only validates

To get a template `params.json`, click the **⬇ params.json template** button.

---

## Optimisation parameter bounds (defaults)

| Parameter | Lower | Upper | Based on |
|---|---|---|---|
| K_f | 0.879 × baseline | 1.126 × baseline | ±12.6% |
| C_f | 0.44 × baseline  | 1.4 × baseline   | ±40-56% |
| K_2 | 0.892 × baseline | 1.116 × baseline | ±11% |
| K_3 | 0.892 × baseline | 1.116 × baseline | ±11% |
| cs_minus   | 0.20 | 0.40 | physical range |
| asym_ratio | 2.30 | 4.00 | physical range |
| gamma_c    | 0.08 | 0.16 | physical range |
| gamma_r    | 0.08 | 0.10 | physical range |

To change bounds, edit `default_bounds()` in `backend/data_config.py`.

---

## Outputs saved per run

All saved to `backend/results/<job_id>/`

```
results/<job_id>/
├── pareto_front.csv          # All non-dominated solutions
├── run_results.json          # Full evaluation log
└── plots/
    ├── pareto_rms_z_rms_x.png
    ├── pareto_rms_z_rms_y.png
    ├── pareto_rms_x_rms_y.png
    ├── pareto_3d.png
    ├── convergence_hv.png
    ├── generation_scatter.png
    ├── param_parallel.png
    ├── pareto_rms_bars.png
    └── seat_accel_Best_total.png
    ... (more time-history plots per Pareto solution)
```

---

## Running without the frontend (CLI / headless)

You can run the backend modules directly as Python scripts for testing:

```python
# test_run.py — put in backend/ folder
from data_config import DEFAULT_CFG
from optimiser import run_optimisation
import numpy as np

cfg = dict(DEFAULT_CFG)
cfg["axlefront_left_csv"]  = r"path/to/Displacement_1_FA_LH.csv"
cfg["axlefront_right_csv"] = r"path/to/Displacement_2_FA_RH.csv"
cfg["axlerear1_left_csv"]  = r"path/to/Displacement_3_RA1_LH.csv"
cfg["axlerear1_right_csv"] = r"path/to/Displacement_4_RA1_RH.csv"
cfg["axlerear2_left_csv"]  = r"path/to/Displacement_5_RA2_LH.csv"
cfg["axlerear2_right_csv"] = r"path/to/Displacement_6_RA2_RH.csv"

t_eval = np.arange(0.0, 466.945 + 0.001, 0.001)

result = run_optimisation(
    cfg=cfg,
    t_eval=t_eval,
    mode="nsga2",               # or "bayesian"
    opt_settings={"pop_size": 10, "n_gen": 5},
)

print(result.df_pareto[["label","rms_z","rms_x","rms_y","rms_total"]])
```

---

## Common errors

| Error | Fix |
|---|---|
| `CSV file not found` | Check your CSV paths are correct and files exist |
| `ODE integration failed` | Try reducing T_END or check your CONFIG params |
| `param names mismatch` | Surrogate was trained on different param set |
| `uvicorn not found` | Activate your venv before running uvicorn |
| `npm: command not found` | Install Node.js from nodejs.org |
| `CORS error in browser` | Make sure backend is on port 8000 and frontend on 3000 |

---

## Quick cheat sheet

```bash
# Terminal 1 — backend
source venv/bin/activate          # (or venv\Scripts\activate on Windows)
cd ride_opt/backend
uvicorn main:app --reload --port 8000

# Terminal 2 — frontend
cd ride_opt/frontend
npm run dev

# Then open:  http://localhost:3000
```
