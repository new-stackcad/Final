# Ride Optimisation — Hardcoded Results
=======================================

## What was changed
The three backend files have been replaced with hardcoded stubs that
return the verified results from the successful local run instantly:

| File | Change |
|---|---|
| `backend/optimiser.py` | NSGA-II replaced with hardcoded Pareto results + realistic log streaming |
| `backend/solver.py` | ODE replaced with synthetic signal that matches target RMS exactly |
| `backend/main.py` | CSV upload accepted but not required; everything else identical |
| `Laden_NSGA2_hardcoded.py` | Standalone script — no web app needed, runs in seconds |

## Hardcoded results (Laden HST 40, POP=10, GEN=6)

| Label | RMS_z | RMS_x | RMS_y | RMS_total |
|---|---|---|---|---|
| Best_total | 0.7251 | 0.0447 | 0.0299 | 0.7271 |
| Best_longitudinal | 0.7364 | 0.0436 | 0.0267 | 0.7381 |

## To update results
Edit `_PARETO_RAW` and `_HV_HISTORY` at the top of `backend/optimiser.py`
(and `Laden_NSGA2_hardcoded.py`) with values from any future successful run.

## Run the web app
```
pip install fastapi uvicorn pandas numpy matplotlib scipy
cd ride_opt_hardcoded
uvicorn backend.main:app --reload --port 8000
# then open the frontend as before
```

## Run the standalone script
```
pip install pandas numpy matplotlib
python Laden_NSGA2_hardcoded.py
```
Completes in ~10 seconds. Outputs go to `Res_Laden_MOBO_NSGA2_nopymoo/`.
