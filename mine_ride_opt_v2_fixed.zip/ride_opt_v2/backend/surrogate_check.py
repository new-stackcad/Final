"""
surrogate_check.py  (v2 — generic)
====================================
Surrogate model validation — runs when a user uploads model.pkl + params.json.
The surrogate is DISABLED by default. This module only validates.

KEY CHANGE from v1:
  v1 imported PARAM_KEYS and default_bounds from data_config (hardcoded 6-DOF).
  v2 has no data_config — param names and bounds come from the user's
  params.json file itself and are cross-checked against the cfg dict passed in.

validate_surrogate(pkl_path, params_json_path, cfg) -> SurrogateValidation
surrogate_params_json_template()                    -> Dict  (template for users)
"""

from __future__ import annotations
import json, os
from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class SurrogateValidation:
    passed: bool
    checks: List[Dict]
    model_type:  str = ""
    ode_version: str = ""
    objectives:  List[str] = field(default_factory=list)

    def summary(self) -> str:
        lines = [f"Surrogate validation {'PASSED' if self.passed else 'FAILED'}:"]
        for c in self.checks:
            icon = "✓" if c["passed"] else "✗"
            lines.append(f"  {icon} {c['name']}: {c['detail']}")
        return "\n".join(lines)


def validate_surrogate(
    pkl_path:         str,
    params_json_path: str,
    cfg:              Dict,
) -> SurrogateValidation:
    """
    Validate a surrogate model against the current user config.

    In v2 the param names and bounds come entirely from params.json.
    cfg is used to cross-check bounds compatibility if BOUNDS are present.

    Checks
    ------
    1.  params.json readable
    2.  param_names declared in params.json
    3.  param_bounds declared and lo < hi for every key
    4.  param_bounds compatible with cfg BOUNDS (if cfg has them)
    5.  feature_order declared
    6.  model_type declared
    7.  training_data_hash present
    8.  ode_version declared
    9.  objectives list present
    10. scaler_params present
    11. model.pkl loadable
    """
    checks: List[Dict] = []
    meta:   Dict       = {}

    def _c(name: str, ok: bool, detail: str):
        checks.append({"name": name, "passed": ok, "detail": detail})

    # ── 1. Read params.json ───────────────────────────────────────────────
    try:
        with open(params_json_path, "r") as f:
            meta = json.load(f)
        _c("params.json readable", True, "Loaded OK")
    except Exception as e:
        _c("params.json readable", False, str(e))
        return SurrogateValidation(passed=False, checks=checks)

    # ── 2. param_names present ────────────────────────────────────────────
    param_names = meta.get("param_names", [])
    _c("param_names declared",
       bool(param_names),
       f"{param_names}" if param_names else "missing — add param_names list")

    # ── 3. param_bounds declared + lo < hi ────────────────────────────────
    declared_bounds: Dict = meta.get("param_bounds", {})
    bounds_ok     = True
    bounds_detail = []
    for k in param_names:
        if k not in declared_bounds:
            bounds_ok = False
            bounds_detail.append(f"{k} missing")
            continue
        try:
            lo, hi = float(declared_bounds[k][0]), float(declared_bounds[k][1])
            if lo >= hi:
                bounds_ok = False
                bounds_detail.append(f"{k}: lo={lo} >= hi={hi}")
        except Exception:
            bounds_ok = False
            bounds_detail.append(f"{k}: invalid format")
    _c("param_bounds valid",
       bounds_ok,
       "OK" if bounds_ok else "; ".join(bounds_detail))

    # ── 4. Bounds compatible with cfg BOUNDS (if user cfg has them) ────────
    cfg_bounds = cfg.get("BOUNDS", {})   # user's BOUNDS dict from ODE editor
    if cfg_bounds and param_names:
        compat_ok     = True
        compat_detail = []
        for k in param_names:
            if k not in cfg_bounds or k not in declared_bounds:
                continue
            try:
                lo_s, hi_s = float(declared_bounds[k][0]), float(declared_bounds[k][1])
                lo_c, hi_c = float(cfg_bounds[k][0]),      float(cfg_bounds[k][1])
                if lo_s < lo_c * 0.99 or hi_s > hi_c * 1.01:
                    compat_ok = False
                    compat_detail.append(
                        f"{k}: surrogate [{lo_s:.2g},{hi_s:.2g}] "
                        f"vs cfg [{lo_c:.2g},{hi_c:.2g}]"
                    )
            except Exception:
                pass
        _c("param_bounds compatible with cfg",
           compat_ok,
           "OK" if compat_ok else "; ".join(compat_detail))
    else:
        _c("param_bounds compatible with cfg",
           True, "Skipped — no BOUNDS in cfg to compare against")

    # ── 5. feature_order ──────────────────────────────────────────────────
    fo = meta.get("feature_order", [])
    _c("feature_order declared", bool(fo), f"{fo}" if fo else "missing")

    # ── 6. model_type ─────────────────────────────────────────────────────
    mt = meta.get("model_type", "")
    _c("model_type declared", bool(mt), mt if mt else "missing")

    # ── 7. training_data_hash ─────────────────────────────────────────────
    tdh = meta.get("training_data_hash", "")
    _c("training_data_hash present",
       bool(tdh), tdh[:16] + "…" if len(tdh) > 16 else tdh if tdh else "missing")

    # ── 8. ode_version ────────────────────────────────────────────────────
    ov = meta.get("ode_version", "")
    _c("ode_version declared", bool(ov), ov if ov else "missing")

    # ── 9. objectives ─────────────────────────────────────────────────────
    objs = meta.get("objectives", [])
    _c("objectives declared", bool(objs), f"{objs}" if objs else "missing")

    # ── 10. scaler_params ─────────────────────────────────────────────────
    sp = meta.get("scaler_params", {})
    _c("scaler_params present", bool(sp), "OK" if sp else "missing")

    # ── 11. pkl loadable ──────────────────────────────────────────────────
    try:
        import pickle
        with open(pkl_path, "rb") as f:
            _ = pickle.load(f)
        _c("model.pkl loadable", True, "Loaded OK")
    except Exception as e:
        _c("model.pkl loadable", False, str(e))

    all_passed = all(c["passed"] for c in checks)
    return SurrogateValidation(
        passed=all_passed,
        checks=checks,
        model_type=meta.get("model_type", ""),
        ode_version=meta.get("ode_version", ""),
        objectives=meta.get("objectives", []),
    )


def surrogate_params_json_template() -> Dict:
    """
    Return a template params.json users should fill in when training a surrogate.
    In v2, param_names come from the user's own BOUNDS dict — this template
    shows the structure but the user must fill in their actual parameter names.
    """
    example_params = ["K_f", "C_f", "K_2", "K_3",
                      "cs_minus", "asym_ratio", "gamma_c", "gamma_r"]
    return {
        "_comment": "Fill param_names with keys from your BOUNDS dict",
        "param_names":        example_params,
        "param_bounds":       {k: [0.0, 1.0] for k in example_params},
        "feature_order":      example_params,
        "model_type":         "GaussianProcess",
        "training_data_hash": "sha256-of-training-csv",
        "ode_version":        "2.0.0",
        "objectives":         ["rms_z", "rms_x", "rms_y"],
        "scaler_params": {
            "method": "standard",
            "mean":   {k: 0.0 for k in example_params},
            "std":    {k: 1.0 for k in example_params},
        },
    }
