import { useState, useEffect, useRef, useCallback } from "react";
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ResponsiveContainer, ScatterChart, Scatter, ReferenceLine
} from "recharts";

const API = "http://localhost:8000";

// ── Design tokens ──────────────────────────────────────────────────────────
const C = {
  bg:       "#F5F7FA",
  surface:  "#FFFFFF",
  border:   "#E2E8F0",
  borderDk: "#CBD5E1",
  text:     "#0F172A",
  textSm:   "#475569",
  textXs:   "#94A3B8",
  blue:     "#2563EB",
  blueLt:   "#DBEAFE",
  green:    "#16A34A",
  greenLt:  "#DCFCE7",
  amber:    "#D97706",
  amberLt:  "#FEF3C7",
  red:      "#DC2626",
  redLt:    "#FEE2E2",
  purple:   "#7C3AED",
  purpleLt: "#EDE9FE",
  cyan:     "#0891B2",
  cyanLt:   "#CFFAFE",
};

const TABS = [
  { id:"setup",     label:"⚙️ Setup",          disabled:false },
  { id:"single",    label:"🎯 Single Objective", disabled:false },
  { id:"multi",     label:"🌐 Multi Objective",  disabled:false },
  { id:"surrogate", label:"🧠 Surrogate Model",  disabled:true  },
  { id:"results",   label:"📊 Results",          disabled:false },
];

const CSV_KEYS = [
  { key:"axlefront_left_csv",  label:"Front Axle LH" },
  { key:"axlefront_right_csv", label:"Front Axle RH" },
  { key:"axlerear1_left_csv",  label:"Rear Axle 1 LH" },
  { key:"axlerear1_right_csv", label:"Rear Axle 1 RH" },
  { key:"axlerear2_left_csv",  label:"Rear Axle 2 LH" },
  { key:"axlerear2_right_csv", label:"Rear Axle 2 RH" },
];

const PARAM_META = {
  K_f:       { label:"K_f (Front Spring)", unit:"N/m",  color:"#2563EB" },
  C_f:       { label:"C_f (Front Damper)", unit:"Ns/m", color:"#7C3AED" },
  K_2:       { label:"K_2 (Rear Spring 1)",unit:"N/m",  color:"#0891B2" },
  K_3:       { label:"K_3 (Rear Spring 2)",unit:"N/m",  color:"#16A34A" },
  cs_minus:  { label:"cs⁻ (Comp slope)",   unit:"",     color:"#D97706" },
  asym_ratio:{ label:"Asym Ratio",          unit:"",     color:"#DC2626" },
  gamma_c:   { label:"γ_c (HS Comp)",       unit:"",     color:"#DB2777" },
  gamma_r:   { label:"γ_r (HS Rebound)",    unit:"",     color:"#EA580C" },
};

// ── Utility components ─────────────────────────────────────────────────────
const Card = ({ children, style={} }) => (
  <div style={{
    background: C.surface, border:`1px solid ${C.border}`,
    borderRadius:12, padding:20, boxShadow:"0 1px 3px rgba(0,0,0,.06)",
    ...style
  }}>{children}</div>
);

const Badge = ({ color, bg, children }) => (
  <span style={{
    background:bg, color, borderRadius:6, padding:"2px 8px",
    fontSize:11, fontWeight:700, letterSpacing:.4
  }}>{children}</span>
);

const StatusDot = ({ status }) => {
  const map = {
    running:{ color:C.amber, label:"Running" },
    done:   { color:C.green, label:"Done" },
    error:  { color:C.red,   label:"Error" },
    pending:{ color:C.textXs,label:"Pending" },
  };
  const s = map[status] || map.pending;
  return (
    <span style={{ display:"flex", alignItems:"center", gap:6 }}>
      <span style={{
        width:8, height:8, borderRadius:"50%", background:s.color,
        boxShadow: status==="running" ? `0 0 0 3px ${C.amberLt}` : "none",
        animation: status==="running" ? "pulse 1.4s infinite" : "none"
      }}/>
      <span style={{ fontSize:12, color:C.textSm, fontWeight:600 }}>{s.label}</span>
    </span>
  );
};

const Btn = ({ children, onClick, disabled, variant="primary", size="md", style={} }) => {
  const styles = {
    primary: { background:C.blue,   color:"#fff", border:"none" },
    success: { background:C.green,  color:"#fff", border:"none" },
    danger:  { background:C.red,    color:"#fff", border:"none" },
    outline: { background:"transparent", color:C.blue, border:`1.5px solid ${C.blue}` },
    ghost:   { background:"transparent", color:C.textSm, border:"none" },
  };
  const sizes = { sm:{padding:"4px 12px",fontSize:12}, md:{padding:"8px 18px",fontSize:13}, lg:{padding:"12px 28px",fontSize:14} };
  return (
    <button onClick={onClick} disabled={disabled} style={{
      ...styles[variant], ...sizes[size],
      borderRadius:8, fontWeight:600, cursor:disabled?"not-allowed":"pointer",
      opacity:disabled?.5:1, transition:"all .15s", ...style
    }}>{children}</button>
  );
};

const Input = ({ label, value, onChange, type="number", step, min, max, style={} }) => (
  <label style={{ display:"flex", flexDirection:"column", gap:4 }}>
    <span style={{ fontSize:11, fontWeight:600, color:C.textSm, textTransform:"uppercase", letterSpacing:.5 }}>{label}</span>
    <input
      type={type} value={value} onChange={e=>onChange(e.target.value)}
      step={step} min={min} max={max}
      style={{
        border:`1px solid ${C.border}`, borderRadius:6, padding:"6px 10px",
        fontSize:13, color:C.text, background:"#fff", outline:"none", ...style
      }}
    />
  </label>
);

const RmsCard = ({ label, rms, color="#2563EB" }) => {
  if (!rms) return null;
  return (
    <Card style={{ borderLeft:`4px solid ${color}` }}>
      <div style={{ fontSize:11, fontWeight:700, color:C.textSm, textTransform:"uppercase", marginBottom:10 }}>{label}</div>
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 }}>
        {[["Vertical (z)", rms.rms_z], ["Longitud. (x)", rms.rms_x],
          ["Lateral (y)", rms.rms_y], ["Combined", rms.rms_total]].map(([l,v])=>(
          <div key={l} style={{ background:C.bg, borderRadius:8, padding:"8px 12px" }}>
            <div style={{ fontSize:10, color:C.textXs, marginBottom:2 }}>{l}</div>
            <div style={{ fontSize:18, fontWeight:700, color }}>{v?.toFixed(4)}</div>
            <div style={{ fontSize:10, color:C.textXs }}>m/s²</div>
          </div>
        ))}
      </div>
    </Card>
  );
};

// ── Main App ──────────────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab] = useState("setup");
  const [cfg, setCfg] = useState({});
  const [bounds, setBounds] = useState({});
  const [paramKeys, setParamKeys] = useState([]);
  const [uploadedFiles, setUploadedFiles] = useState({});  // key -> filename
  const [uploadStatus, setUploadStatus] = useState({});

  // Job state
  const [jobId, setJobId] = useState(null);
  const [jobData, setJobData] = useState(null);
  const [polling, setPolling] = useState(false);
  const pollRef = useRef(null);

  // Single obj settings
  const [initPoints, setInitPoints] = useState(8);
  const [nIter, setNIter] = useState(30);

  // Multi obj settings
  const [popSize, setPopSize] = useState(10);
  const [nGen, setNGen] = useState(6);

  // Simulation settings
  const [tEnd, setTEnd] = useState(466.945);
  const [tIgnore, setTIgnore] = useState(0.5);
  const [dt, setDt] = useState(0.001);

  // Fetch default config on mount
  useEffect(() => {
    fetch(`${API}/default_config`)
      .then(r => r.json())
      .then(d => {
        setCfg(d.cfg);
        setBounds(d.bounds);
        setParamKeys(d.param_keys);
      })
      .catch(() => {});
  }, []);

  // Poll job
  useEffect(() => {
    if (!polling || !jobId) return;
    pollRef.current = setInterval(async () => {
      try {
        const r = await fetch(`${API}/jobs/${jobId}`);
        const d = await r.json();
        setJobData(d);
        if (d.status === "done" || d.status === "error") {
          setPolling(false);
          clearInterval(pollRef.current);
          if (d.status === "done") setTab("results");
        }
      } catch {}
    }, 2000);
    return () => clearInterval(pollRef.current);
  }, [polling, jobId]);

  const handleUpload = async (csvKey, file) => {
    setUploadStatus(s => ({...s, [csvKey]: "uploading"}));
    const fd = new FormData();
    fd.append("file", file);
    try {
      const r = await fetch(`${API}/upload_csv`, { method:"POST", body:fd });
      const d = await r.json();
      setUploadedFiles(u => ({...u, [csvKey]: d.filename}));
      setUploadStatus(s => ({...s, [csvKey]: "done"}));
    } catch {
      setUploadStatus(s => ({...s, [csvKey]: "error"}));
    }
  };

  const startJob = async (mode) => {
    const missingCsv = CSV_KEYS.filter(c => !uploadedFiles[c.key]);
    if (missingCsv.length > 0) {
      alert(`Please upload all 6 axle CSV files first.\nMissing: ${missingCsv.map(c=>c.label).join(", ")}`);
      return;
    }
    const payload = {
      mode, cfg, bounds,
      param_keys: paramKeys,
      axle_csv_keys: uploadedFiles,
      init_points: parseInt(initPoints),
      n_iter: parseInt(nIter),
      pop_size: parseInt(popSize),
      n_gen: parseInt(nGen),
      t_end: parseFloat(tEnd),
      t_ignore: parseFloat(tIgnore),
      dt: parseFloat(dt),
    };
    try {
      const r = await fetch(`${API}/jobs`, { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(payload) });
      const d = await r.json();
      setJobId(d.job_id);
      setJobData(null);
      setPolling(true);
      setTab("results");
    } catch (e) {
      alert("Failed to start job: " + e.message);
    }
  };

  // ── Render ──────────────────────────────────────────────────────────────
  return (
    <div style={{ fontFamily:"'Inter','Segoe UI',sans-serif", background:C.bg, minHeight:"100vh", color:C.text }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        * { box-sizing:border-box; margin:0; }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.4} }
        @keyframes spin { to{transform:rotate(360deg)} }
        input:focus { outline:2px solid ${C.blue}; outline-offset:1px; }
        ::-webkit-scrollbar { width:6px; height:6px; }
        ::-webkit-scrollbar-track { background:transparent; }
        ::-webkit-scrollbar-thumb { background:${C.borderDk}; border-radius:3px; }
      `}</style>

      {/* Header */}
      <div style={{
        background:C.surface, borderBottom:`1px solid ${C.border}`,
        padding:"0 32px", display:"flex", alignItems:"center",
        justifyContent:"space-between", height:60,
        position:"sticky", top:0, zIndex:100,
        boxShadow:"0 1px 4px rgba(0,0,0,.06)"
      }}>
        <div style={{ display:"flex", alignItems:"center", gap:12 }}>
          <div style={{ width:36, height:36, borderRadius:10, background:C.blue, display:"flex", alignItems:"center", justifyContent:"center", fontSize:18 }}>🚛</div>
          <div>
            <div style={{ fontSize:15, fontWeight:800, color:C.text, letterSpacing:-.3 }}>Vehicle Dynamics Optimizer</div>
            <div style={{ fontSize:11, color:C.textXs }}>LangGraph · Bayesian Opt · NSGA-II</div>
          </div>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:12 }}>
          {jobId && <StatusDot status={jobData?.status || "running"} />}
          {jobId && <Badge color={C.blue} bg={C.blueLt}>JOB {jobId.slice(0,8)}</Badge>}
        </div>
      </div>

      {/* Tab bar */}
      <div style={{
        background:C.surface, borderBottom:`1px solid ${C.border}`,
        padding:"0 32px", display:"flex", gap:4
      }}>
        {TABS.map(t => (
          <button key={t.id} onClick={() => !t.disabled && setTab(t.id)}
            disabled={t.disabled}
            style={{
              padding:"14px 18px", border:"none", background:"transparent",
              fontSize:13, fontWeight:600, cursor:t.disabled?"not-allowed":"pointer",
              color: tab===t.id ? C.blue : t.disabled ? C.textXs : C.textSm,
              borderBottom: tab===t.id ? `2px solid ${C.blue}` : "2px solid transparent",
              opacity: t.disabled ? .45 : 1,
              transition:"all .15s"
            }}>
            {t.label} {t.disabled && <span style={{ fontSize:10, background:"#F1F5F9", borderRadius:4, padding:"1px 5px", marginLeft:4 }}>SOON</span>}
          </button>
        ))}
      </div>

      {/* Content */}
      <div style={{ maxWidth:1200, margin:"0 auto", padding:"28px 32px" }}>
        {tab === "setup"  && <SetupTab cfg={cfg} setCfg={setCfg} uploadedFiles={uploadedFiles} uploadStatus={uploadStatus} onUpload={handleUpload} tEnd={tEnd} setTEnd={setTEnd} tIgnore={tIgnore} setTIgnore={setTIgnore} dt={dt} setDt={setDt} />}
        {tab === "single" && <SingleTab bounds={bounds} setBounds={setBounds} paramKeys={paramKeys} setParamKeys={setParamKeys} initPoints={initPoints} setInitPoints={setInitPoints} nIter={nIter} setNIter={setNIter} onStart={() => startJob("single")} jobRunning={polling} />}
        {tab === "multi"  && <MultiTab bounds={bounds} setBounds={setBounds} paramKeys={paramKeys} setParamKeys={setParamKeys} popSize={popSize} setPopSize={setPopSize} nGen={nGen} setNGen={setNGen} onStart={() => startJob("multi")} jobRunning={polling} />}
        {tab === "results"&& <ResultsTab jobData={jobData} jobId={jobId} polling={polling} />}
      </div>
    </div>
  );
}

// ── Setup Tab ──────────────────────────────────────────────────────────────
function SetupTab({ cfg, setCfg, uploadedFiles, uploadStatus, onUpload, tEnd, setTEnd, tIgnore, setTIgnore, dt, setDt }) {
  const CFG_GROUPS = [
    { title:"Cabin Mass & Inertia", keys:["m_c","I_xxc","I_yyc","hcp"] },
    { title:"Sprung Mass & Inertia", keys:["m_s","I_sxx","I_syy","I_sxy","hs"] },
    { title:"Geometry", keys:["a","b","lf","L12","L23","l_cf","l_cr","l_cfcg","l_crcg"] },
    { title:"Track Widths & Suspension", keys:["WT1","WT2","WT3","S_f","S_tf2","S_tf3","s1","s2"] },
    { title:"Cabin Suspension (K/C)", keys:["K_cfl","K_cfr","K_crl","K_crr","C_cfl","C_cfr","C_crl","C_crr"] },
    { title:"Axle Suspension (C)", keys:["C_2","C_3"] },
    { title:"Baumgarte Stabilization", keys:["baum_omega","baum_zeta"] },
    { title:"Misc", keys:["g"] },
  ];

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:24 }}>
      {/* CSV Upload */}
      <Card>
        <div style={{ fontSize:16, fontWeight:700, marginBottom:16, display:"flex", alignItems:"center", gap:8 }}>
          <span>📁</span> Axle Displacement CSV Files
          <Badge color={C.blue} bg={C.blueLt}>{Object.keys(uploadedFiles).length}/6 uploaded</Badge>
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:12 }}>
          {CSV_KEYS.map(({ key, label }) => {
            const status = uploadStatus[key];
            const uploaded = uploadedFiles[key];
            return (
              <label key={key} style={{
                border:`2px dashed ${uploaded ? C.green : C.border}`,
                borderRadius:10, padding:"14px 16px", cursor:"pointer",
                background: uploaded ? C.greenLt : "#FAFBFD",
                transition:"all .2s", display:"block"
              }}>
                <input type="file" accept=".csv" style={{ display:"none" }}
                  onChange={e => e.target.files[0] && onUpload(key, e.target.files[0])} />
                <div style={{ fontSize:12, fontWeight:700, color:C.text, marginBottom:4 }}>{label}</div>
                {uploaded
                  ? <div style={{ fontSize:11, color:C.green }}>✓ {uploaded}</div>
                  : <div style={{ fontSize:11, color:C.textXs }}>Click to upload CSV</div>}
                {status === "uploading" && <div style={{ fontSize:11, color:C.amber }}>Uploading…</div>}
                {status === "error"     && <div style={{ fontSize:11, color:C.red }}>Upload failed</div>}
              </label>
            );
          })}
        </div>
        <div style={{ marginTop:12, padding:"10px 14px", background:C.blueLt, borderRadius:8, fontSize:12, color:C.blue }}>
          ℹ️ CSV format: skip 2 header rows, column 1 = time (s), column 2 = displacement (m)
        </div>
      </Card>

      {/* Simulation settings */}
      <Card>
        <div style={{ fontSize:16, fontWeight:700, marginBottom:16 }}>⏱ Simulation Settings</div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:16 }}>
          <Input label="T_end (s)" value={tEnd} onChange={setTEnd} step={0.001} min={1} />
          <Input label="T_ignore (s)" value={tIgnore} onChange={setTIgnore} step={0.01} min={0} />
          <Input label="dt (s)" value={dt} onChange={setDt} step={0.0001} min={0.0001} max={0.01} />
        </div>
        <div style={{ marginTop:12, fontSize:11, color:C.textXs }}>
          Estimated time points: {Math.round(parseFloat(tEnd)/parseFloat(dt)).toLocaleString()}
        </div>
      </Card>

      {/* Vehicle Parameters */}
      {CFG_GROUPS.map(({ title, keys }) => (
        <Card key={title}>
          <div style={{ fontSize:14, fontWeight:700, marginBottom:14, color:C.text }}>{title}</div>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(180px,1fr))", gap:12 }}>
            {keys.map(k => (
              k in cfg &&
              <Input key={k} label={k} value={cfg[k] ?? ""} step="any"
                onChange={v => setCfg(c => ({...c, [k]: parseFloat(v) || v}))} />
            ))}
          </div>
        </Card>
      ))}
    </div>
  );
}

// ── Single Objective Tab ───────────────────────────────────────────────────
function SingleTab({ bounds, setBounds, paramKeys, setParamKeys, initPoints, setInitPoints, nIter, setNIter, onStart, jobRunning }) {
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:24 }}>
      <Card style={{ borderLeft:`4px solid ${C.blue}` }}>
        <div style={{ fontSize:16, fontWeight:700, marginBottom:8 }}>🎯 Bayesian Optimization</div>
        <div style={{ fontSize:13, color:C.textSm, marginBottom:20 }}>
          Minimizes combined 3-axis seat RMS: √(E[az²] + E[ax²] + E[ay²]) using Gaussian Process surrogate with Expected Improvement acquisition.
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16, maxWidth:360 }}>
          <Input label="Init Points" value={initPoints} onChange={setInitPoints} min={2} max={50} />
          <Input label="Iterations" value={nIter} onChange={setNIter} min={1} max={200} />
        </div>
        <div style={{ marginTop:12, fontSize:12, color:C.textXs }}>
          Total ODE evaluations: {parseInt(initPoints) + parseInt(nIter)}
        </div>
      </Card>

      <BoundsEditor bounds={bounds} setBounds={setBounds} paramKeys={paramKeys} setParamKeys={setParamKeys} />

      <div style={{ display:"flex", justifyContent:"flex-end" }}>
        <Btn variant="primary" size="lg" disabled={jobRunning} onClick={onStart}>
          {jobRunning ? "⏳ Running…" : "🚀 Start Optimization"}
        </Btn>
      </div>
    </div>
  );
}

// ── Multi Objective Tab ────────────────────────────────────────────────────
function MultiTab({ bounds, setBounds, paramKeys, setParamKeys, popSize, setPopSize, nGen, setNGen, onStart, jobRunning }) {
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:24 }}>
      <Card style={{ borderLeft:`4px solid ${C.purple}` }}>
        <div style={{ fontSize:16, fontWeight:700, marginBottom:8 }}>🌐 NSGA-II Multi-Objective</div>
        <div style={{ fontSize:13, color:C.textSm, marginBottom:20 }}>
          Simultaneously minimizes RMS_z (vertical), RMS_x (longitudinal), RMS_y (lateral) to produce a Pareto front of non-dominated solutions.
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16, maxWidth:360 }}>
          <Input label="Population Size" value={popSize} onChange={setPopSize} min={4} max={100} />
          <Input label="Generations" value={nGen} onChange={setNGen} min={1} max={50} />
        </div>
        <div style={{ marginTop:12, fontSize:12, color:C.textXs }}>
          Total ODE evaluations ≈ {parseInt(popSize) * (parseInt(nGen) + 1)}
        </div>
      </Card>

      <BoundsEditor bounds={bounds} setBounds={setBounds} paramKeys={paramKeys} setParamKeys={setParamKeys} />

      <div style={{ display:"flex", justifyContent:"flex-end" }}>
        <Btn variant="primary" size="lg" disabled={jobRunning} onClick={onStart}>
          {jobRunning ? "⏳ Running…" : "🚀 Start Optimization"}
        </Btn>
      </div>
    </div>
  );
}

// ── Bounds Editor ──────────────────────────────────────────────────────────
function BoundsEditor({ bounds, setBounds, paramKeys, setParamKeys }) {
  const updateBound = (key, idx, val) => {
    const b = [...(bounds[key] || [0, 1])];
    b[idx] = parseFloat(val) || 0;
    setBounds(prev => ({ ...prev, [key]: b }));
  };

  return (
    <Card>
      <div style={{ fontSize:16, fontWeight:700, marginBottom:16 }}>📐 Parameter Bounds</div>
      <div style={{ display:"grid", gap:10 }}>
        {Object.keys(bounds).map(key => {
          const meta = PARAM_META[key] || { label: key, unit: "" };
          const active = paramKeys.includes(key);
          const lo = bounds[key]?.[0] ?? 0;
          const hi = bounds[key]?.[1] ?? 1;
          return (
            <div key={key} style={{
              display:"grid", gridTemplateColumns:"24px 200px 1fr 1fr 60px",
              gap:10, alignItems:"center",
              padding:"8px 12px", borderRadius:8,
              background: active ? "#FAFBFF" : C.bg,
              border:`1px solid ${active ? C.blue+"44" : C.border}`,
            }}>
              <input type="checkbox" checked={active}
                onChange={e => setParamKeys(k => e.target.checked ? [...k, key] : k.filter(x=>x!==key))}
                style={{ cursor:"pointer" }} />
              <div>
                <div style={{ fontSize:12, fontWeight:600, color:active ? C.blue : C.textSm }}>{meta.label}</div>
                {meta.unit && <div style={{ fontSize:10, color:C.textXs }}>{meta.unit}</div>}
              </div>
              <Input label="Lower bound" value={lo} onChange={v => updateBound(key, 0, v)} step="any" />
              <Input label="Upper bound" value={hi} onChange={v => updateBound(key, 1, v)} step="any" />
              <Badge color={active?C.blue:C.textXs} bg={active?C.blueLt:"#F1F5F9"}>
                {active?"ON":"OFF"}
              </Badge>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

// ── Results Tab ────────────────────────────────────────────────────────────
function ResultsTab({ jobData, jobId, polling }) {
  const [activeResult, setActiveResult] = useState("summary");

  if (!jobId) {
    return (
      <Card style={{ textAlign:"center", padding:60 }}>
        <div style={{ fontSize:48, marginBottom:16 }}>📊</div>
        <div style={{ fontSize:18, fontWeight:700, color:C.textSm }}>No job running yet</div>
        <div style={{ fontSize:13, color:C.textXs, marginTop:8 }}>Go to Single or Multi tab to start an optimization</div>
      </Card>
    );
  }

  const log = jobData?.log || [];
  const iterLog = jobData?.iteration_log || [];
  const mode = jobData?.mode;

  // Build convergence data
  const convData = iterLog
    .filter(it => it.rms_total && it.rms_total < 90)
    .map((it, i) => ({
      iteration: i + 1,
      rms_total: parseFloat((it.rms_total||0).toFixed(5)),
      rms_z:     parseFloat((it.rms_z||0).toFixed(5)),
      rms_x:     parseFloat((it.rms_x||0).toFixed(5)),
      rms_y:     parseFloat((it.rms_y||0).toFixed(5)),
      best:      iterLog.slice(0,i+1).filter(x=>x.rms_total<90).reduce((a,b)=>a.rms_total<b.rms_total?a:b, {rms_total:99}).rms_total,
    }));

  // Normalised params for best solution
  const bp = jobData?.best_params;
  const norm = bp?.normalised || {};
  const normData = Object.entries(norm).map(([k,v]) => ({
    key: k, value: v, label: PARAM_META[k]?.label || k,
    physical: bp?.params?.[k]
  }));

  // Pareto front
  const pareto = jobData?.pareto_front || [];
  const paretoXY = pareto.map(p => ({ rms_z: p.rms_z, rms_x: p.rms_x, rms_y: p.rms_y, label: p.label || "" }));

  const RESULT_TABS = [
    { id:"summary",    label:"Summary" },
    { id:"convergence",label:"Convergence" },
    { id:"params",     label:"Best Params" },
    { id:"pareto",     label:"Pareto Front",  disabled: mode !== "multi" },
    { id:"log",        label:"Run Log" },
  ];

  const pct = jobData?.baseline_rms && jobData?.optimized_rms
    ? ((jobData.baseline_rms.rms_total - jobData.optimized_rms.rms_total) / jobData.baseline_rms.rms_total * 100)
    : null;

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:20 }}>
      {/* Status bar */}
      <Card style={{ padding:"14px 20px" }}>
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between" }}>
          <div style={{ display:"flex", alignItems:"center", gap:16 }}>
            <StatusDot status={jobData?.status || "running"} />
            <div style={{ fontSize:13, fontWeight:600 }}>Job {jobId?.slice(0,8)}</div>
            <Badge color={mode==="single"?C.blue:C.purple} bg={mode==="single"?C.blueLt:C.purpleLt}>
              {mode==="single" ? "BAYESIAN OPT" : "NSGA-II"}
            </Badge>
            <span style={{ fontSize:12, color:C.textXs }}>{jobData?.iteration_count || 0} evaluations completed</span>
          </div>
          {pct !== null && (
            <div style={{ display:"flex", alignItems:"center", gap:8 }}>
              <span style={{ fontSize:12, color:C.textSm }}>Improvement:</span>
              <span style={{ fontSize:20, fontWeight:800, color: pct>0?C.green:C.red }}>
                {pct > 0 ? "▼" : "▲"}{Math.abs(pct).toFixed(2)}%
              </span>
            </div>
          )}
        </div>
        {polling && (
          <div style={{ marginTop:10 }}>
            <div style={{ height:3, background:C.border, borderRadius:2, overflow:"hidden" }}>
              <div style={{ height:"100%", background:C.blue, width:"40%", borderRadius:2, animation:"loading 1.5s infinite" }} />
            </div>
            <style>{`@keyframes loading{0%{transform:translateX(-100%)}100%{transform:translateX(350%)}}`}</style>
          </div>
        )}
      </Card>

      {/* Sub-tabs */}
      <div style={{ display:"flex", gap:4, borderBottom:`1px solid ${C.border}`, paddingBottom:0 }}>
        {RESULT_TABS.map(t => !t.disabled && (
          <button key={t.id} onClick={() => setActiveResult(t.id)} style={{
            padding:"8px 16px", border:"none", background:"transparent",
            fontSize:12, fontWeight:600, cursor:"pointer",
            color: activeResult===t.id ? C.blue : C.textSm,
            borderBottom: activeResult===t.id ? `2px solid ${C.blue}` : "2px solid transparent",
          }}>{t.label}</button>
        ))}
      </div>

      {/* Summary */}
      {activeResult === "summary" && (
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:20 }}>
          <RmsCard label="Baseline Parameters" rms={jobData?.baseline_rms} color={C.textSm} />
          <RmsCard label="Optimized Parameters" rms={jobData?.optimized_rms} color={C.green} />
          {mode === "single" && bp && (
            <Card style={{ gridColumn:"span 2" }}>
              <div style={{ fontSize:14, fontWeight:700, marginBottom:14 }}>Best Parameters Found</div>
              <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(220px,1fr))", gap:10 }}>
                {Object.entries(bp.params || {}).map(([k,v]) => (
                  <div key={k} style={{ background:C.bg, borderRadius:8, padding:"10px 14px" }}>
                    <div style={{ fontSize:11, color:C.textXs }}>{PARAM_META[k]?.label || k}</div>
                    <div style={{ fontSize:16, fontWeight:700, color:C.blue }}>{typeof v==="number"?v.toFixed(4):v}</div>
                    {PARAM_META[k]?.unit && <div style={{ fontSize:10, color:C.textXs }}>{PARAM_META[k].unit}</div>}
                    {norm[k] !== undefined && (
                      <div style={{ marginTop:6 }}>
                        <div style={{ height:4, background:C.border, borderRadius:2 }}>
                          <div style={{ height:"100%", width:`${norm[k]*100}%`, background: (norm[k]<.05||norm[k]>.95)?C.red:C.blue, borderRadius:2 }} />
                        </div>
                        <div style={{ fontSize:9, color: (norm[k]<.05||norm[k]>.95)?C.red:C.textXs, marginTop:2 }}>
                          {(norm[k]*100).toFixed(0)}% in range {(norm[k]<.05||norm[k]>.95)?" ⚠ near boundary":""}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </Card>
          )}
          {mode === "multi" && pareto.length > 0 && (
            <Card style={{ gridColumn:"span 2" }}>
              <div style={{ fontSize:14, fontWeight:700, marginBottom:14 }}>Pareto Front Solutions</div>
              <div style={{ overflowX:"auto" }}>
                <table style={{ width:"100%", borderCollapse:"collapse", fontSize:12 }}>
                  <thead>
                    <tr style={{ background:C.bg }}>
                      <th style={{ padding:"8px 12px", textAlign:"left", color:C.textSm }}>Label</th>
                      <th style={{ padding:"8px 12px", textAlign:"right", color:C.textSm }}>RMS_z</th>
                      <th style={{ padding:"8px 12px", textAlign:"right", color:C.textSm }}>RMS_x</th>
                      <th style={{ padding:"8px 12px", textAlign:"right", color:C.textSm }}>RMS_y</th>
                      <th style={{ padding:"8px 12px", textAlign:"right", color:C.textSm }}>RMS_total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pareto.map((p, i) => (
                      <tr key={i} style={{ borderTop:`1px solid ${C.border}`, background: i===0?C.greenLt:"transparent" }}>
                        <td style={{ padding:"8px 12px", fontWeight:600, color:i===0?C.green:C.text }}>{p.label || `Pareto_${i+1}`}</td>
                        <td style={{ padding:"8px 12px", textAlign:"right" }}>{p.rms_z?.toFixed(5)}</td>
                        <td style={{ padding:"8px 12px", textAlign:"right" }}>{p.rms_x?.toFixed(5)}</td>
                        <td style={{ padding:"8px 12px", textAlign:"right" }}>{p.rms_y?.toFixed(5)}</td>
                        <td style={{ padding:"8px 12px", textAlign:"right", fontWeight:700 }}>{p.rms_total?.toFixed(5)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          )}
        </div>
      )}

      {/* Convergence */}
      {activeResult === "convergence" && (
        <div style={{ display:"flex", flexDirection:"column", gap:20 }}>
          <Card>
            <div style={{ fontSize:14, fontWeight:700, marginBottom:16 }}>RMS_total Convergence</div>
            {convData.length > 0 ? (
              <ResponsiveContainer width="100%" height={280}>
                <LineChart data={convData}>
                  <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
                  <XAxis dataKey="iteration" label={{ value:"Iteration", position:"insideBottom", offset:-4, fontSize:11 }} tick={{ fontSize:11 }} />
                  <YAxis tick={{ fontSize:11 }} label={{ value:"RMS (m/s²)", angle:-90, position:"insideLeft", fontSize:11 }} />
                  <Tooltip formatter={(v) => v?.toFixed(5)} />
                  <Legend />
                  <Line type="monotone" dataKey="rms_total" stroke={C.textXs} dot={false} strokeWidth={1} name="RMS_total" />
                  <Line type="monotone" dataKey="best" stroke={C.green} dot={false} strokeWidth={2} name="Best so far" strokeDasharray="6 2" />
                </LineChart>
              </ResponsiveContainer>
            ) : <div style={{ color:C.textXs, textAlign:"center", padding:40 }}>No data yet…</div>}
          </Card>
          <Card>
            <div style={{ fontSize:14, fontWeight:700, marginBottom:16 }}>Per-Axis RMS Over Iterations</div>
            {convData.length > 0 ? (
              <ResponsiveContainer width="100%" height={280}>
                <LineChart data={convData}>
                  <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
                  <XAxis dataKey="iteration" tick={{ fontSize:11 }} />
                  <YAxis tick={{ fontSize:11 }} />
                  <Tooltip formatter={(v) => v?.toFixed(5)} />
                  <Legend />
                  <Line type="monotone" dataKey="rms_z" stroke="#2563EB" dot={false} strokeWidth={1.5} name="RMS_z (vertical)" />
                  <Line type="monotone" dataKey="rms_x" stroke="#7C3AED" dot={false} strokeWidth={1.5} name="RMS_x (longit.)" />
                  <Line type="monotone" dataKey="rms_y" stroke="#0891B2" dot={false} strokeWidth={1.5} name="RMS_y (lateral)" />
                </LineChart>
              </ResponsiveContainer>
            ) : <div style={{ color:C.textXs, textAlign:"center", padding:40 }}>No data yet…</div>}
          </Card>
        </div>
      )}

      {/* Best Params */}
      {activeResult === "params" && (
        <Card>
          <div style={{ fontSize:14, fontWeight:700, marginBottom:16 }}>Parameter Normalised Position in Search Bounds</div>
          {normData.length > 0 ? (
            <>
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={normData} margin={{ top:20, right:20, bottom:60, left:10 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
                  <XAxis dataKey="label" tick={{ fontSize:10 }} angle={-30} textAnchor="end" interval={0} />
                  <YAxis domain={[0,1]} tick={{ fontSize:11 }} />
                  <Tooltip formatter={(v, n, props) => [`${(v*100).toFixed(1)}%  (${props.payload.physical?.toFixed(4)})`, "Position"]} />
                  <ReferenceLine y={0.05} stroke={C.red} strokeDasharray="4 2" />
                  <ReferenceLine y={0.95} stroke={C.amber} strokeDasharray="4 2" />
                  <Bar dataKey="value" fill={C.blue} radius={[4,4,0,0]}>
                    {normData.map((entry, i) => (
                      <rect key={i} fill={(entry.value<0.05||entry.value>0.95)?C.red:C.blue} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
              <div style={{ display:"flex", gap:16, marginTop:10, fontSize:11, color:C.textXs }}>
                <span style={{ color:C.red }}>── Near boundary (may need wider search)</span>
                <span style={{ color:C.amber }}>── Near upper bound</span>
              </div>
            </>
          ) : (
            mode === "multi" && pareto.length > 0 ? (
              <div style={{ color:C.textSm, fontSize:13 }}>See Pareto Front tab for multi-objective results</div>
            ) : (
              <div style={{ color:C.textXs, textAlign:"center", padding:40 }}>Waiting for results…</div>
            )
          )}
        </Card>
      )}

      {/* Pareto */}
      {activeResult === "pareto" && mode === "multi" && (
        <div style={{ display:"flex", flexDirection:"column", gap:20 }}>
          <Card>
            <div style={{ fontSize:14, fontWeight:700, marginBottom:16 }}>Pareto Front: RMS_z vs RMS_x</div>
            {paretoXY.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <ScatterChart>
                  <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
                  <XAxis dataKey="rms_z" name="RMS_z" label={{ value:"RMS_z vertical [m/s²]", position:"insideBottom", offset:-4, fontSize:11 }} tick={{ fontSize:11 }} />
                  <YAxis dataKey="rms_x" name="RMS_x" label={{ value:"RMS_x longit. [m/s²]", angle:-90, position:"insideLeft", fontSize:11 }} tick={{ fontSize:11 }} />
                  <Tooltip cursor={{ strokeDasharray:"3 3" }} formatter={(v)=>v?.toFixed(5)} />
                  <Scatter data={paretoXY} fill={C.purple} />
                </ScatterChart>
              </ResponsiveContainer>
            ) : <div style={{ color:C.textXs, textAlign:"center", padding:40 }}>No Pareto data yet…</div>}
          </Card>
          <Card>
            <div style={{ fontSize:14, fontWeight:700, marginBottom:16 }}>Per-Axis RMS Bar Chart (Pareto Solutions)</div>
            {pareto.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={pareto.map(p => ({
                  name: p.label || "P",
                  rms_z: parseFloat((p.rms_z||0).toFixed(5)),
                  rms_x: parseFloat((p.rms_x||0).toFixed(5)),
                  rms_y: parseFloat((p.rms_y||0).toFixed(5)),
                }))} margin={{ bottom:40 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
                  <XAxis dataKey="name" tick={{ fontSize:10 }} angle={-25} textAnchor="end" />
                  <YAxis tick={{ fontSize:11 }} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="rms_z" fill="#2563EB" name="RMS_z vertical" radius={[3,3,0,0]} />
                  <Bar dataKey="rms_x" fill="#7C3AED" name="RMS_x longit." radius={[3,3,0,0]} />
                  <Bar dataKey="rms_y" fill="#0891B2" name="RMS_y lateral" radius={[3,3,0,0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : <div style={{ color:C.textXs, textAlign:"center", padding:40 }}>No data…</div>}
          </Card>
        </div>
      )}

      {/* Log */}
      {activeResult === "log" && (
        <Card>
          <div style={{ fontSize:14, fontWeight:700, marginBottom:16 }}>Run Log</div>
          <div style={{
            background:"#0F172A", borderRadius:10, padding:16, height:480, overflowY:"auto",
            fontFamily:"'JetBrains Mono','Fira Code','Courier New',monospace", fontSize:12, color:"#E2E8F0"
          }}>
            {log.length === 0 && <div style={{ color:"#475569" }}>Waiting for logs…</div>}
            {log.map((entry, i) => {
              const colors = { info:"#7DD3FC", warn:"#FCD34D", error:"#FCA5A5", iteration:"#86EFAC" };
              return (
                <div key={i} style={{ marginBottom:3, color: colors[entry.type] || "#E2E8F0" }}>
                  <span style={{ color:"#475569" }}>[{String(i+1).padStart(3," ")}] </span>
                  {entry.msg}
                </div>
              );
            })}
          </div>
        </Card>
      )}
    </div>
  );
}
