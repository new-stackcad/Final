# Vehicle Dynamics Optimizer — LangGraph + React Dashboard

A production-grade optimization platform for vehicle suspension parameter tuning.
Uses LangGraph for workflow orchestration, Bayesian Optimization (single-objective),
and NSGA-II (multi-objective Pareto) with a bright React dashboard.

---

## Architecture

```
vehicle_opt/
├── backend/
│   ├── app.py            # FastAPI + LangGraph backend
│   └── requirements.txt
└── frontend/
    ├── index.html
    ├── package.json
    └── src/
        └── App.jsx       # Full React dashboard
```

### LangGraph Workflow

```
validate → baseline → [single_opt | multi_opt] → validate_best → END
```

Each node:
- `validate`: checks CSV files exist, cfg has required keys
- `baseline`: runs ODE with current cfg params to get reference RMS
- `single_opt`: Bayesian Optimization (bayes_opt) → minimizes combined 3-axis RMS
- `multi_opt`: NSGA-II (pymoo) → Pareto front of (rms_z, rms_x, rms_y)
- `validate_best`: final ODE run with best params for verified result

---

## Installation

### Backend

```bash
cd backend
pip install -r requirements.txt
```

Or individually:
```bash
pip install fastapi uvicorn[standard] python-multipart
pip install langgraph langchain-core
pip install bayesian-optimization
pip install pymoo
pip install numpy pandas scipy matplotlib
```

### Frontend

```bash
cd frontend
npm install
```

---

## Running

### 1. Start backend
```bash
cd backend
python app.py
# → http://localhost:8000
# → Swagger docs: http://localhost:8000/docs
```

### 2. Start frontend
```bash
cd frontend
npm run dev
# → http://localhost:5173
```

---

## Usage

### Setup Tab
1. **Upload all 6 axle CSV files** (Front LH/RH, Rear1 LH/RH, Rear2 LH/RH)
   - Format: skip 2 header rows, col1 = time [s], col2 = displacement [m]
2. **Set simulation parameters**: T_end, T_ignore, dt
3. **Review vehicle parameters** — all editable inline

### Single Objective Tab
- Uses Bayesian Optimization (Gaussian Process + Expected Improvement)
- Objective: minimize √(E[az²] + E[ax²] + E[ay²]) (ISO 2631-style 3-axis RMS)
- Set init_points (random exploration) and n_iter (BO iterations)
- Edit parameter bounds and select which params to optimize

### Multi Objective Tab
- Uses NSGA-II via pymoo
- Simultaneously minimizes (RMS_z, RMS_x, RMS_y) → Pareto front
- Set population size and number of generations
- Same bounds editor as single objective

### Results Tab
- **Summary**: side-by-side baseline vs optimized RMS, best params
- **Convergence**: RMS over iterations, best-so-far curve
- **Best Params**: normalised position chart — values near 0 or 1 may need wider bounds
- **Pareto Front**: scatter plot and bar chart (multi only)
- **Run Log**: live terminal output from backend

---

## API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | `/health` | Health check |
| POST | `/upload_csv` | Upload axle CSV file |
| POST | `/jobs` | Start optimization job |
| GET  | `/jobs/{id}` | Poll job status + results |
| GET  | `/jobs/{id}/iterations` | Full iteration log |
| GET  | `/jobs` | List all jobs |
| DELETE | `/jobs/{id}` | Delete job |
| GET  | `/default_config` | Get default vehicle config |

### POST /jobs payload
```json
{
  "mode": "single",                   // or "multi"
  "cfg": { "m_c": 862, ... },         // vehicle parameters
  "bounds": { "K_f": [210995, 843981], ... },
  "param_keys": ["K_f", "C_f", ...],
  "axle_csv_keys": {
    "axlefront_left_csv": "Displacement_1_FA_LH.csv",
    ...
  },
  "init_points": 8,                   // single obj only
  "n_iter": 30,                       // single obj only
  "pop_size": 10,                     // multi obj only
  "n_gen": 6,                         // multi obj only
  "t_end": 466.945,
  "t_ignore": 0.5,
  "dt": 0.001
}
```

---

## Notes

### Computation time
- Each ODE evaluation: ~60–300s depending on T_end and stiffness
- Single obj (8+30=38 evals): ~40min–3hrs
- Multi obj (10×6=60 evals): ~1–5hrs
- For testing: use T_end=10, dt=0.01 to validate the pipeline quickly

### Parameter boundary warnings
- If a best parameter is at norm < 0.05 or > 0.95, the true optimum may lie outside bounds
- The UI flags these in red on the normalised bar chart

### Adding new cases (extensibility)
- Upload different CSV files → same backend handles any road profile
- Modify `cfg` in the Setup tab for different vehicle configs (laden/unladen etc.)
- Bounds are fully configurable per run from the UI

### Geometric constraints
- Currently hardcoded for 6-DOF model with 2 geometric equality constraints
- The `geom_constraints` and `build_M_R` functions in `app.py` can be replaced
  for different models without changing the LangGraph workflow or frontend

---

## Troubleshooting

**"Missing CSV files" error**: Ensure all 6 CSV files are uploaded before starting
**ODE diverged**: Try tighter stiffness bounds (K_2, K_3) or increase Baumgarte omega
**pymoo not found**: `pip install pymoo` — required for multi-objective mode
**CORS errors**: Backend runs on port 8000, frontend on 5173; both must be running
**Memory**: Long simulations (T_end=466s, dt=0.001) require ~1–2GB RAM per eval
