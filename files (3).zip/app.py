"""
Vehicle Dynamics Optimization Backend
FastAPI + LangGraph orchestration for single and multi-objective optimization.
Supports the 6-DOF cabin + sprung mass model with configurable axle inputs.
"""

import os
import json
import time
import uuid
import asyncio
import traceback
import threading
from typing import Dict, List, Optional, Any, Annotated, TypedDict
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException, BackgroundTasks, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

# LangGraph
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages

# Optimization
from bayes_opt import BayesianOptimization

# Scipy / ODE
from numpy.linalg import solve as lin_solve
from scipy.integrate import solve_ivp
from scipy.optimize import least_squares

import warnings
warnings.filterwarnings("ignore")

# ─────────────────────────────────────────────────────────────────────────────
# App setup
# ─────────────────────────────────────────────────────────────────────────────
app = FastAPI(title="Vehicle Dynamics Optimizer", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = Path("uploads")
RESULTS_DIR = Path("results")
UPLOAD_DIR.mkdir(exist_ok=True)
RESULTS_DIR.mkdir(exist_ok=True)

# ─────────────────────────────────────────────────────────────────────────────
# In-memory job store
# ─────────────────────────────────────────────────────────────────────────────
jobs: Dict[str, Dict] = {}

# ─────────────────────────────────────────────────────────────────────────────
# Pydantic models
# ─────────────────────────────────────────────────────────────────────────────
class OptimizationRequest(BaseModel):
    mode: str = Field(..., description="'single' or 'multi'")
    cfg: Dict[str, Any] = Field(..., description="Vehicle configuration dict")
    bounds: Dict[str, List[float]] = Field(..., description="Parameter bounds {key: [lo, hi]}")
    param_keys: List[str] = Field(..., description="Parameters to optimize")
    axle_csv_keys: Dict[str, str] = Field(default={}, description="Mapping of cfg key -> uploaded filename")
    # Single-objective settings
    init_points: int = Field(default=8, ge=1, le=50)
    n_iter: int = Field(default=30, ge=1, le=200)
    # Multi-objective settings
    pop_size: int = Field(default=10, ge=4, le=100)
    n_gen: int = Field(default=6, ge=1, le=50)
    t_end: float = Field(default=466.945, gt=0)
    t_ignore: float = Field(default=0.5, ge=0)
    dt: float = Field(default=0.001, gt=0)

# ─────────────────────────────────────────────────────────────────────────────
# Physics engine (unchanged from original, fully self-contained)
# ─────────────────────────────────────────────────────────────────────────────
STATE_NAMES = ["z_c", "th_c", "ph_c", "z_s", "th_s", "ph_s"]
ZC, THC, PHC, ZS, THS, PHS = range(6)
DT_DEFAULT = 0.001


@dataclass
class TwoStageAsymmetricDamper:
    cs_minus: float
    asym_ratio: float
    gamma_c: float
    gamma_r: float
    alpha_c: float = -0.05
    alpha_r: float = 0.13

    def force(self, v_rel: float) -> float:
        c_plus = self.asym_ratio * self.cs_minus
        if v_rel < 0.0:
            if v_rel >= self.alpha_c:
                return self.cs_minus * v_rel
            else:
                return self.cs_minus * (self.alpha_c + self.gamma_c * (v_rel - self.alpha_c))
        else:
            if v_rel <= self.alpha_r:
                return c_plus * v_rel
            else:
                return c_plus * (self.alpha_r + self.gamma_r * (v_rel - self.alpha_r))


def load_track(csv_path: str):
    df = pd.read_csv(csv_path, skiprows=2, header=None)
    t = pd.to_numeric(df.iloc[:, 0], errors="coerce").values
    z = pd.to_numeric(df.iloc[:, 1], errors="coerce").values
    mask = np.isfinite(t) & np.isfinite(z)
    return t[mask].astype(float), z[mask].astype(float)


def make_linear_interp(x, y):
    x = np.asarray(x)
    y = np.asarray(y)
    def f(xq):
        xq = np.asarray(xq)
        xq_c = np.clip(xq, x[0], x[-1])
        idx = np.clip(np.searchsorted(x, xq_c) - 1, 0, len(x) - 2)
        x0, x1 = x[idx], x[idx + 1]
        y0, y1 = y[idx], y[idx + 1]
        w = (xq_c - x0) / np.maximum(x1 - x0, 1e-12)
        return y0 * (1 - w) + y1 * w
    return f


@dataclass
class RoadSignals:
    f1L: Any
    f1R: Any
    f2L: Any
    f2R: Any
    f3L: Any
    f3R: Any

    def axle_inputs(self, t, cfg):
        zr1L, zr1R = self.f1L(t), self.f1R(t)
        zr2L, zr2R = self.f2L(t), self.f2R(t)
        zr3L, zr3R = self.f3L(t), self.f3R(t)
        z1f = 0.5 * (zr1L + zr1R)
        z2  = 0.5 * (zr2L + zr2R)
        z3  = 0.5 * (zr3L + zr3R)
        ph_f = (zr1L - zr1R) / cfg["WT1"]
        ph2  = (zr2L - zr2R) / cfg["WT2"]
        ph3  = (zr3L - zr3R) / cfg["WT3"]
        return float(z1f), float(ph_f), float(z2), float(ph2), float(z3), float(ph3)

    def axle_input_rates(self, t, cfg, dt=DT_DEFAULT):
        p = self.axle_inputs(t + dt, cfg)
        m = self.axle_inputs(t - dt, cfg)
        return tuple((a - b) / (2.0 * dt) for a, b in zip(p, m))


def build_road_signals(cfg) -> RoadSignals:
    t1L, z1L = load_track(cfg["axlefront_left_csv"])
    t1R, z1R = load_track(cfg["axlefront_right_csv"])
    t2L, z2L = load_track(cfg["axlerear1_left_csv"])
    t2R, z2R = load_track(cfg["axlerear1_right_csv"])
    t3L, z3L = load_track(cfg["axlerear2_left_csv"])
    t3R, z3R = load_track(cfg["axlerear2_right_csv"])
    return RoadSignals(
        make_linear_interp(t1L, z1L), make_linear_interp(t1R, z1R),
        make_linear_interp(t2L, z2L), make_linear_interp(t2R, z2R),
        make_linear_interp(t3L, z3L), make_linear_interp(t3R, z3R),
    )


def geom_constraints(q, t, cfg, road):
    z_s, th_s, ph_s = q[ZS], q[THS], q[PHS]
    _, _, z2, ph2, z3, ph3 = road.axle_inputs(t, cfg)
    l2 = cfg["L12"]
    l3 = cfg["L12"] + cfg["L23"]
    S2, S3 = cfg["S_tf2"], cfg["S_tf3"]
    sl2, sl3 = cfg["s1"], cfg["s2"]
    bL2, bL3 = cfg["beta_L2"], cfg["beta_L3"]
    g2 = z_s + l2*th_s + S2*ph_s - sl2*np.sin(bL2 - th_s) - (z2 + 0.5*cfg["WT2"]*ph2)
    g3 = z_s + l3*th_s + S3*ph_s - sl3*np.sin(bL3 - th_s) - (z3 + 0.5*cfg["WT3"]*ph3)
    gq = np.array([g2, g3], dtype=float)
    G = np.zeros((2, 6), dtype=float)
    G[0, ZS] = 1.0; G[0, THS] = l2 + sl2*np.cos(bL2 - th_s); G[0, PHS] = S2
    G[1, ZS] = 1.0; G[1, THS] = l3 + sl3*np.cos(bL3 - th_s); G[1, PHS] = S3
    return gq, G


def build_M_R(q, v, t, cfg, road):
    z_c, th_c, ph_c, z_s, th_s, ph_s = q
    dz_c, dth_c, dph_c, dz_s, dth_s, dph_s = v

    z1f, ph_f, z2, ph2, z3, ph3 = road.axle_inputs(t, cfg)
    dz1f, dph_f, dz2, dph2, dz3, dph3 = road.axle_input_rates(t, cfg)

    phi_NRS2 = (cfg["beta_L2"]*cfg["L_DL2"] - cfg["beta_R2"]*cfg["L_DR2"]) / max(cfg["S_tf2"], 1e-6)
    phi_NRS3 = (cfg["beta_L3"]*cfg["L_DL3"] - cfg["beta_R3"]*cfg["L_DR3"]) / max(cfg["S_tf3"], 1e-6)

    m_c, I_xxc, I_yyc = cfg["m_c"], cfg["I_xxc"], cfg["I_yyc"]
    m_s, I_sxx, I_syy, I_sxy = cfg["m_s"], cfg["I_sxx"], cfg["I_syy"], cfg["I_sxy"]
    S1, S2, S3 = cfg["S_f"], cfg["S_tf2"], cfg["S_tf3"]
    a, b = cfg["a"], cfg["b"]
    hs, g = cfg["hs"], cfg["g"]
    l_cfcg, l_crcg, l_cf, l_cr = cfg["l_cfcg"], cfg["l_crcg"], cfg["l_cf"], cfg["l_cr"]
    lf = cfg["lf"]; hcp = cfg["hcp"]
    l2 = cfg["L12"]; l3 = cfg["L12"] + cfg["L23"]
    beta_L2, beta_R2 = cfg["beta_L2"], cfg["beta_R2"]
    beta_L3, beta_R3 = cfg["beta_L3"], cfg["beta_R3"]
    L_DL2, L_DR2, L_DL3, L_DR3 = cfg["L_DL2"], cfg["L_DR2"], cfg["L_DL3"], cfg["L_DR3"]
    Kcfl, Kcfr, Kcrl, Kcrr = cfg["K_cfl"], cfg["K_cfr"], cfg["K_crl"], cfg["K_crr"]
    Ccfl, Ccfr, Ccrl, Ccrr = cfg["C_cfl"], cfg["C_cfr"], cfg["C_crl"], cfg["C_crr"]
    K_f, C_f = cfg["K_f"], cfg["C_f"]
    K_2, C_2 = cfg["K_2"], cfg["C_2"]
    K_3, C_3 = cfg["K_3"], cfg["C_3"]

    M = np.zeros((6, 6), dtype=float)
    M[ZC, ZC] = m_c; M[THC, THC] = I_yyc; M[PHC, PHC] = I_xxc
    M[ZS, ZS] = m_s; M[THS, THS] = I_syy
    M[THS, PHS] = I_sxy; M[PHS, THS] = I_sxy
    M[PHS, PHS] = I_sxx + m_s * hs**2

    damp = TwoStageAsymmetricDamper(
        cs_minus=cfg["cs_minus"], asym_ratio=cfg["asym_ratio"],
        gamma_c=cfg["gamma_c"], gamma_r=cfg["gamma_r"],
        alpha_c=-0.05, alpha_r=0.13,
    )
    v_f = dz_s - lf * dth_s - dz1f
    F_df = C_f * damp.force(v_f)

    Csum = Ccfl + Ccfr + Ccrl + Ccrr
    Ksum = Kcfl + Kcfr + Kcrl + Kcrr

    R = np.zeros(6, dtype=float)

    R[ZC] = (
        Csum*(dz_c-dz_s) + Ksum*(z_c-z_s)
        - (Ccfl*l_cfcg+Ccfr*l_cfcg-Ccrl*l_crcg-Ccrr*l_crcg)*dth_c
        - (-Ccfl*l_cf-Ccfr*l_cf-Ccrl*l_cr-Ccrr*l_cr)*dth_s
        - (-Ccfl*b+Ccfr*a-Ccrl*b+Ccrr*a)*dph_c
        - (Ccfl*b-Ccfr*a+Ccrl*b-Ccrr*a)*dph_s
        - (Kcfl*l_cfcg+Kcfr*l_cfcg-Kcrl*l_crcg-Kcrr*l_crcg)*th_c
        - (-Kcfl*l_cf-Kcfr*l_cf-Kcrl*l_cr-Kcrr*l_cr)*th_s
        - (-Kcfl*b+Kcfr*a-Kcrl*b+Kcrr*a)*ph_c
        - (Kcfl*b-Kcfr*a+Kcrl*b-Kcrr*a)*ph_s
    )
    R[THC] = (
        -(Ccfl*l_cfcg+Ccfr*l_cfcg-Ccrl*l_crcg-Ccrr*l_crcg)*dz_c
        -(-Ccfl*l_cfcg-Ccfr*l_cfcg-Ccrl*l_crcg-Ccrr*l_crcg)*dz_s
        -(Kcfl*l_cfcg+Kcfr*l_cfcg-Kcrl*l_crcg-Kcrr*l_crcg)*z_c
        -(-Kcfl*l_cfcg-Kcfr*l_cfcg-Kcrl*l_crcg-Kcrr*l_crcg)*z_s
        -(-Ccfl*l_cfcg**2-Ccfr*l_cfcg**2-Ccrl*l_crcg**2-Ccrr*l_crcg**2)*dth_c
        -(Ccfl*l_cfcg*l_cf+Ccfr*l_cfcg*l_cf-Ccrl*l_crcg*l_cr-Ccrr*l_crcg*l_cr)*dth_s
        -(-Ccfl*l_cfcg*b+Ccfr*l_cfcg*a-Ccrl*l_crcg*b+Ccrr*l_crcg*a)*dph_c
        -(Ccfl*l_cfcg*b-Ccfr*l_cfcg*a+Ccrl*l_crcg*b-Ccrr*l_crcg*a)*dph_s
        -(-Kcfl*l_cfcg**2-Kcfr*l_cfcg**2-Kcrl*l_crcg**2-Kcrr*l_crcg**2+m_c*g*hcp)*th_c
        -(Kcfl*l_cfcg*l_cf+Kcfr*l_cfcg*l_cf-Kcrl*l_crcg*l_cr-Kcrr*l_crcg*l_cr)*th_s
        -(-Kcfl*l_cfcg*b+Kcfr*l_cfcg*a-Kcrl*l_crcg*b+Kcrr*l_crcg*a)*ph_c
        -(Kcfl*l_cfcg*b-Kcfr*l_cfcg*a+Kcrl*l_crcg*b-Kcrr*l_crcg*a)*ph_s
    )
    R[PHC] = (
        -(-Ccfl*b+Ccfr*a-Ccrl*b+Ccrr*a)*dz_c
        -(Ccfl*b-Ccfr*a+Ccrl*b-Ccrr*a)*dz_s
        -(-Kcfl*b+Kcfr*a-Kcrl*b+Kcrr*a)*z_c
        -(Kcfl*b-Kcfr*a+Kcrl*b-Kcrr*a)*z_s
        -(-Ccfl*l_cfcg*b-Ccfr*l_cfcg*a+Ccrl*l_crcg*b+Ccrr*l_crcg*a)*dth_c
        -(Ccfl*l_cfcg*b+Ccfr*l_cfcg*a-Ccrl*l_crcg*b-Ccrr*l_crcg*a)*dth_s
        -(-Ccfl*b**2+Ccfr*a**2-Ccrl*b**2+Ccrr*a**2)*dph_c
        -(Ccfl*b**2-Ccfr*a**2+Ccrl*b**2-Ccrr*a**2)*dph_s
        -(-Kcfl*l_cfcg*b-Kcfr*l_cfcg*a+Kcrl*l_crcg*b+Kcrr*l_crcg*a)*th_c
        -(Kcfl*l_cfcg*b+Kcfr*l_cfcg*a-Kcrl*l_crcg*b-Kcrr*l_crcg*a)*th_s
        -(-Kcfl*b**2+Kcfr*a**2-Kcrl*b**2+Kcrr*a**2)*ph_c
        -(Kcfl*b**2-Kcfr*a**2+Kcrl*b**2-Kcrr*a**2)*ph_s
    )
    R[ZS] = (
        -(Ccfl+Ccfr+Ccrl+Ccrr)*dz_c
        -(-Ccfl*l_cfcg-Ccfr*l_cfcg+Ccrl*l_crcg+Ccrr*l_crcg)*dth_c
        -(-Ccfl-Ccfr-Ccrl-Ccrr)*dz_s
        -(Ccfl*l_cf+Ccfr*l_cf+Ccrl*l_cr+Ccrr*l_cr)*dth_s
        -(Kcfl+Kcfr+Kcrl+Kcrr)*z_c
        -(-Kcfl*l_cfcg-Kcfr*l_cfcg+Kcrl*l_crcg+Kcrr*l_crcg)*th_c
        -(-Kcfl-Kcfr-Kcrl-Kcrr)*z_s
        -(Kcfl*l_cf+Kcfr*l_cf+Kcrl*l_cr+Kcrr*l_cr)*th_s
        + K_f*(z_s-lf*th_s-z1f) + F_df
        + K_2*(z_s-z2-beta_L2*L_DL2-beta_R2*L_DR2+l2*th_s) + C_2*(dz_s-dz2+l2*dth_s)
        + K_3*(z_s-z3-beta_L3*L_DL3-beta_R3*L_DR3+l3*th_s) + C_3*(dz_s-dz3+l3*dth_s)
    )
    R[THS] = (
        -(Ccfl*l_cfcg+Ccfr*l_cfcg-Ccrl*l_crcg-Ccrr*l_crcg)*dz_c
        -(-Ccfl*l_cfcg**2-Ccfr*l_cfcg**2-Ccrl*l_crcg**2-Ccrr*l_crcg**2)*dth_c
        -(-Ccfl*l_cf-Ccfr*l_cf-Ccrl*l_cr-Ccrr*l_cr)*dz_s
        -(Ccfl*l_cfcg*l_cf+Ccfr*l_cfcg*l_cf-Ccrl*l_crcg*l_cr-Ccrr*l_crcg*l_cr)*dth_s
        -(Kcfl*l_cf+Kcfr*l_cf+Kcrl*l_cr+Kcrr*l_cr)*z_c
        -(-Kcfl*l_cfcg*l_cf-Kcfr*l_cfcg*l_cf+Kcrl*l_crcg*l_cr+Kcrr*l_crcg*l_cr)*th_c
        -(-Kcfl*l_cf-Kcfr*l_cf-Kcrl*l_cr-Kcrr*l_cr)*z_s
        -(Kcfl*l_cf**2+Kcfr*l_cf**2+Kcrl*l_cr**2+Kcrr*l_cr**2)*th_s
        - lf*(K_f*(z_s-lf*th_s-z1f) + F_df)
        + l2*(K_2*(z_s-z2-beta_L2*L_DL2-beta_R2*L_DR2+l2*th_s) + C_2*(dz_s-dz2+l2*dth_s))
        + l3*(K_3*(z_s-z3-beta_L3*L_DL3-beta_R3*L_DR3+l3*th_s) + C_3*(dz_s-dz3+l3*dth_s))
    )
    k_tf = 0.5*K_f*S1**2; K_r1 = 0.5*K_2*S2**2; K_r2 = 0.5*K_3*S3**2
    C_tf = 0.5*C_f*S1**2; C_r1 = 0.5*C_2*S2**2; C_r2 = 0.5*C_3*S3**2
    R[PHS] = -(
        m_s*g*hs*ph_s
        - k_tf*(ph_s-ph_f) - C_tf*(dph_s-dph_f)
        - K_r1*(ph_s-ph2-phi_NRS2) - C_r1*(dph_s-dph2)
        - K_r2*(ph_s-ph3-phi_NRS3) - C_r2*(dph_s-dph3)
    )
    return M, R


def rhs_first_order(t, x, cfg, road):
    q, v = x[:6], x[6:]
    M, R = build_M_R(q, v, t, cfg, road)
    gq, G = geom_constraints(q, t, cfg, road)
    w, zeta = cfg["baum_omega"], cfg["baum_zeta"]
    gamma = w**2 * gq + 2*zeta*w * (G @ v)
    nc = G.shape[0]
    A = np.zeros((6 + nc, 6 + nc))
    b_vec = np.zeros(6 + nc)
    A[:6, :6] = M; A[:6, 6:] = G.T; A[6:, :6] = G
    b_vec[:6] = -R; b_vec[6:] = -gamma
    sol = lin_solve(A, b_vec)
    xdot = np.zeros_like(x)
    xdot[:6] = v; xdot[6:] = sol[:6]
    return xdot


def static_equilibrium_state(cfg, road):
    t0 = 0.0
    def F(y):
        q, lam = y[:6], y[6:]
        M, R = build_M_R(q, np.zeros(6), t0, cfg, road)
        gq, G = geom_constraints(q, t0, cfg, road)
        return np.hstack([R + G.T @ lam, 1e3 * gq])
    lsq = least_squares(F, np.zeros(8), method="trf", loss="soft_l1",
                        xtol=1e-12, ftol=1e-12, gtol=1e-12, max_nfev=800)
    if lsq.success:
        return np.hstack([lsq.x[:6], np.zeros(6)])
    # Fallback
    cfg_r = dict(cfg)
    for k in ["C_2", "C_3", "C_cfl", "C_cfr", "C_crl", "C_crr"]:
        cfg_r[k] *= 20
    sol = solve_ivp(lambda t, x: rhs_first_order(t, x, cfg_r, road),
                    (0.0, 3.0), np.zeros(12), method="Radau", rtol=1e-7, atol=1e-9)
    q0 = sol.y[:6, -1]
    return np.hstack([q0, np.zeros(6)])


def run_ode(params, cfg_base, t_eval):
    cfg = {**cfg_base, **params}
    road = build_road_signals(cfg)
    x0 = static_equilibrium_state(cfg, road)
    sol = solve_ivp(
        fun=lambda t, x: rhs_first_order(t, x, cfg, road),
        t_span=(float(t_eval[0]), float(t_eval[-1])),
        y0=x0, t_eval=t_eval,
        method="Radau", max_step=0.01, rtol=1e-6, atol=1e-8,
    )
    if sol.status != 0 or not np.all(np.isfinite(sol.y)):
        raise RuntimeError(f"ODE failed: {sol.message}")
    rows = []
    for i, t in enumerate(sol.t):
        x = sol.y[:, i]; q = x[:6]; v = x[6:]
        qdd = rhs_first_order(t, x, cfg, road)[6:]
        row = {"t": t}
        for j, name in enumerate(STATE_NAMES):
            row[name] = q[j]; row[f"qd_{name}"] = v[j]; row[f"qdd_{name}"] = qdd[j]
        rows.append(row)
    return pd.DataFrame(rows)


def compute_seat_rms(df, cfg, t_ignore):
    mask = df["t"] >= t_ignore
    h = cfg.get("hcp", 0.1)
    az = df.loc[mask, "qdd_z_c"].values
    ax = -h * df.loc[mask, "qdd_th_c"].values
    ay = h * df.loc[mask, "qdd_ph_c"].values
    return {
        "rms_z":     float(np.sqrt(np.mean(az**2))),
        "rms_x":     float(np.sqrt(np.mean(ax**2))),
        "rms_y":     float(np.sqrt(np.mean(ay**2))),
        "rms_total": float(np.sqrt(np.mean(az**2) + np.mean(ax**2) + np.mean(ay**2))),
    }


# ─────────────────────────────────────────────────────────────────────────────
# LangGraph state
# ─────────────────────────────────────────────────────────────────────────────
class OptState(TypedDict):
    job_id: str
    mode: str
    cfg: Dict
    bounds: Dict
    param_keys: List[str]
    t_eval: Any
    t_ignore: float
    init_points: int
    n_iter: int
    pop_size: int
    n_gen: int
    iteration_log: List[Dict]
    best_params: Optional[Dict]
    pareto_front: Optional[List[Dict]]
    baseline_rms: Optional[Dict]
    optimized_rms: Optional[Dict]
    status: str
    error: Optional[str]


# ─────────────────────────────────────────────────────────────────────────────
# LangGraph nodes
# ─────────────────────────────────────────────────────────────────────────────
def node_validate(state: OptState) -> OptState:
    """Validate cfg has all required keys and CSV files exist."""
    required_csv = [
        "axlefront_left_csv", "axlefront_right_csv",
        "axlerear1_left_csv", "axlerear1_right_csv",
        "axlerear2_left_csv", "axlerear2_right_csv",
    ]
    cfg = state["cfg"]
    missing = [k for k in required_csv if not cfg.get(k) or not Path(cfg[k]).exists()]
    if missing:
        return {**state, "status": "error", "error": f"Missing/invalid CSV files: {missing}"}
    required_params = [
        "m_c","I_xxc","I_yyc","m_s","I_sxx","I_syy","I_sxy",
        "K_f","C_f","K_2","K_3","baum_omega","baum_zeta","g","hcp"
    ]
    missing_p = [k for k in required_params if k not in cfg]
    if missing_p:
        return {**state, "status": "error", "error": f"Missing cfg keys: {missing_p}"}
    
    jobs[state["job_id"]]["log"].append({"type":"info","msg":"Validation passed ✓"})
    return {**state, "status": "running"}


def node_baseline(state: OptState) -> OptState:
    """Run ODE with baseline (current CFG) parameters."""
    if state["status"] == "error":
        return state
    try:
        jobs[state["job_id"]]["log"].append({"type":"info","msg":"Computing baseline RMS..."})
        baseline_p = {k: state["cfg"][k] for k in state["param_keys"] if k in state["cfg"]}
        df = run_ode(baseline_p, state["cfg"], state["t_eval"])
        rms = compute_seat_rms(df, state["cfg"], state["t_ignore"])
        jobs[state["job_id"]]["baseline_rms"] = rms
        jobs[state["job_id"]]["log"].append({
            "type":"info",
            "msg":f"Baseline RMS total={rms['rms_total']:.4f} z={rms['rms_z']:.4f} x={rms['rms_x']:.4f} y={rms['rms_y']:.4f}"
        })
        return {**state, "baseline_rms": rms}
    except Exception as e:
        return {**state, "status": "error", "error": f"Baseline failed: {str(e)}\n{traceback.format_exc()}"}


def node_single_objective(state: OptState) -> OptState:
    """Bayesian optimization (single objective: combined RMS)."""
    if state["status"] == "error":
        return state

    iteration_log = []
    job = jobs[state["job_id"]]
    job["log"].append({"type":"info","msg":f"Starting Bayesian Optimization: {state['init_points']} init + {state['n_iter']} iterations"})

    pbounds = {k: tuple(state["bounds"][k]) for k in state["param_keys"]}

    def objective(**kwargs):
        params = {k: kwargs[k] for k in state["param_keys"]}
        try:
            df = run_ode(params, state["cfg"], state["t_eval"])
            rms = compute_seat_rms(df, state["cfg"], state["t_ignore"])
            val = -rms["rms_total"]
            entry = {**params, **rms, "target": val, "iteration": len(iteration_log)+1}
            iteration_log.append(entry)
            job["iteration_log"] = iteration_log
            job["log"].append({
                "type": "iteration",
                "msg": f"Iter {len(iteration_log)}: RMS_total={rms['rms_total']:.4f}",
                "rms": rms,
                "iteration": len(iteration_log),
            })
            return val
        except Exception as e:
            entry = {**params, "rms_total": 99.0, "target": -99.0, "iteration": len(iteration_log)+1, "error": str(e)}
            iteration_log.append(entry)
            job["iteration_log"] = iteration_log
            return -99.0

    optimizer = BayesianOptimization(f=objective, pbounds=pbounds, random_state=42, verbose=0)
    optimizer.maximize(init_points=state["init_points"], n_iter=state["n_iter"])

    best = optimizer.max
    best_params = best["params"]
    # Normalised position
    normalised = {}
    for k, v in best_params.items():
        lo, hi = state["bounds"][k]
        normalised[k] = round((v - lo) / (hi - lo), 4)

    job["log"].append({"type":"info","msg":f"Optimization complete. Best RMS total={-best['target']:.4f}"})

    return {**state,
            "best_params": {"params": best_params, "normalised": normalised, "rms_total": -best["target"]},
            "iteration_log": iteration_log}


def node_multi_objective(state: OptState) -> OptState:
    """NSGA-II multi-objective optimization (rms_z, rms_x, rms_y)."""
    if state["status"] == "error":
        return state
    try:
        from pymoo.algorithms.moo.nsga2 import NSGA2
        from pymoo.core.problem import ElementwiseProblem
        from pymoo.operators.crossover.sbx import SBX
        from pymoo.operators.mutation.pm import PM
        from pymoo.operators.sampling.rnd import FloatRandomSampling
        from pymoo.optimize import minimize as pymoo_minimize
        from pymoo.util.nds.non_dominated_sorting import NonDominatedSorting
    except ImportError:
        return {**state, "status": "error", "error": "pymoo not installed. Run: pip install pymoo"}

    job = jobs[state["job_id"]]
    iteration_log = []
    param_keys = state["param_keys"]
    xl = np.array([state["bounds"][k][0] for k in param_keys])
    xu = np.array([state["bounds"][k][1] for k in param_keys])

    job["log"].append({"type":"info","msg":f"Starting NSGA-II: pop={state['pop_size']} gen={state['n_gen']}"})

    class Problem(ElementwiseProblem):
        def __init__(self):
            super().__init__(n_var=len(param_keys), n_obj=3, xl=xl, xu=xu)
        def _evaluate(self, x, out, *args, **kwargs):
            params = {k: float(x[i]) for i, k in enumerate(param_keys)}
            try:
                df = run_ode(params, state["cfg"], state["t_eval"])
                rms = compute_seat_rms(df, state["cfg"], state["t_ignore"])
                fz, fx, fy = rms["rms_z"], rms["rms_x"], rms["rms_y"]
                entry = {**params, **rms, "iteration": len(iteration_log)+1}
                iteration_log.append(entry)
                job["iteration_log"] = iteration_log
                job["log"].append({
                    "type":"iteration",
                    "msg":f"Iter {len(iteration_log)}: z={fz:.4f} x={fx:.4f} y={fy:.4f}",
                    "rms": rms, "iteration": len(iteration_log),
                })
                out["F"] = [fz, fx, fy]
            except Exception as e:
                out["F"] = [99.0, 99.0, 99.0]
                job["log"].append({"type":"warn","msg":f"ODE failed: {str(e)[:100]}"})

    problem = Problem()
    algorithm = NSGA2(
        pop_size=state["pop_size"],
        sampling=FloatRandomSampling(),
        crossover=SBX(prob=0.9, eta=15),
        mutation=PM(eta=20),
        eliminate_duplicates=True,
    )
    result = pymoo_minimize(problem, algorithm, ("n_gen", state["n_gen"]), seed=42, verbose=False)

    X, F = result.X, result.F
    pareto = []
    for i in range(len(X)):
        row = {k: float(X[i, j]) for j, k in enumerate(param_keys)}
        row["rms_z"] = float(F[i, 0])
        row["rms_x"] = float(F[i, 1])
        row["rms_y"] = float(F[i, 2])
        row["rms_total"] = float(np.sqrt(F[i,0]**2 + F[i,1]**2 + F[i,2]**2))
        pareto.append(row)
    pareto.sort(key=lambda r: r["rms_total"])
    if pareto:
        best = pareto[0]
        job["log"].append({"type":"info","msg":f"NSGA-II done. Pareto size={len(pareto)} Best total={best['rms_total']:.4f}"})

    return {**state, "pareto_front": pareto, "iteration_log": iteration_log}


def node_validate_best(state: OptState) -> OptState:
    """Re-run ODE with best params to get final validated RMS."""
    if state["status"] == "error":
        return state
    try:
        job = jobs[state["job_id"]]
        if state["mode"] == "single" and state.get("best_params"):
            params = state["best_params"]["params"]
        elif state["mode"] == "multi" and state.get("pareto_front") and state["pareto_front"]:
            pk = state["param_keys"]
            params = {k: state["pareto_front"][0][k] for k in pk}
        else:
            return state

        job["log"].append({"type":"info","msg":"Validating best parameters with final ODE run..."})
        df = run_ode(params, state["cfg"], state["t_eval"])
        rms = compute_seat_rms(df, state["cfg"], state["t_ignore"])
        job["optimized_rms"] = rms
        job["log"].append({
            "type":"info",
            "msg":f"Validated RMS total={rms['rms_total']:.4f} z={rms['rms_z']:.4f} x={rms['rms_x']:.4f} y={rms['rms_y']:.4f}"
        })
        return {**state, "optimized_rms": rms, "status": "done"}
    except Exception as e:
        return {**state, "status": "error", "error": f"Validation failed: {str(e)}"}


def route_mode(state: OptState) -> str:
    if state["status"] == "error":
        return "end"
    return state["mode"]


# ─────────────────────────────────────────────────────────────────────────────
# Build LangGraph
# ─────────────────────────────────────────────────────────────────────────────
def build_graph():
    g = StateGraph(OptState)
    g.add_node("validate",      node_validate)
    g.add_node("baseline",      node_baseline)
    g.add_node("single_opt",    node_single_objective)
    g.add_node("multi_opt",     node_multi_objective)
    g.add_node("validate_best", node_validate_best)

    g.set_entry_point("validate")
    g.add_edge("validate", "baseline")
    g.add_conditional_edges("baseline", route_mode, {
        "single": "single_opt",
        "multi":  "multi_opt",
        "end":    END,
    })
    g.add_edge("single_opt",    "validate_best")
    g.add_edge("multi_opt",     "validate_best")
    g.add_edge("validate_best", END)
    return g.compile()

graph = build_graph()


# ─────────────────────────────────────────────────────────────────────────────
# Background runner
# ─────────────────────────────────────────────────────────────────────────────
def run_graph_background(job_id: str, initial_state: OptState):
    try:
        final = graph.invoke(initial_state)
        jobs[job_id].update({
            "status": final.get("status", "done"),
            "best_params": final.get("best_params"),
            "pareto_front": final.get("pareto_front"),
            "optimized_rms": final.get("optimized_rms"),
            "baseline_rms": final.get("baseline_rms"),
            "error": final.get("error"),
            "iteration_log": final.get("iteration_log", []),
        })
    except Exception as e:
        jobs[job_id].update({
            "status": "error",
            "error": str(e) + "\n" + traceback.format_exc(),
        })


# ─────────────────────────────────────────────────────────────────────────────
# API routes
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/health")
def health():
    return {"status": "ok", "version": "1.0.0"}


@app.post("/upload_csv")
async def upload_csv(file: UploadFile = File(...)):
    """Upload an axle displacement CSV file."""
    safe_name = Path(file.filename).name
    dest = UPLOAD_DIR / safe_name
    content = await file.read()
    dest.write_bytes(content)
    return {"filename": safe_name, "path": str(dest.resolve()), "size": len(content)}


@app.post("/jobs")
def create_job(req: OptimizationRequest, background_tasks: BackgroundTasks):
    """Create and start an optimization job."""
    job_id = str(uuid.uuid4())

    # Resolve CSV paths: replace cfg keys with uploaded file paths
    cfg = dict(req.cfg)
    for cfg_key, filename in req.axle_csv_keys.items():
        full_path = str((UPLOAD_DIR / filename).resolve())
        if not Path(full_path).exists():
            raise HTTPException(400, f"Uploaded file not found: {filename}")
        cfg[cfg_key] = full_path

    t_eval = np.arange(0.0, req.t_end + req.dt, req.dt)

    initial_state: OptState = {
        "job_id": job_id,
        "mode": req.mode,
        "cfg": cfg,
        "bounds": req.bounds,
        "param_keys": req.param_keys,
        "t_eval": t_eval,
        "t_ignore": req.t_ignore,
        "init_points": req.init_points,
        "n_iter": req.n_iter,
        "pop_size": req.pop_size,
        "n_gen": req.n_gen,
        "iteration_log": [],
        "best_params": None,
        "pareto_front": None,
        "baseline_rms": None,
        "optimized_rms": None,
        "status": "pending",
        "error": None,
    }

    jobs[job_id] = {
        "job_id": job_id,
        "mode": req.mode,
        "status": "running",
        "log": [],
        "iteration_log": [],
        "baseline_rms": None,
        "optimized_rms": None,
        "best_params": None,
        "pareto_front": None,
        "error": None,
        "created_at": time.time(),
    }

    thread = threading.Thread(target=run_graph_background, args=(job_id, initial_state), daemon=True)
    thread.start()

    return {"job_id": job_id, "status": "running"}


@app.get("/jobs/{job_id}")
def get_job(job_id: str):
    """Poll job status and results."""
    if job_id not in jobs:
        raise HTTPException(404, "Job not found")
    job = jobs[job_id]
    return {
        "job_id": job_id,
        "status": job.get("status", "running"),
        "mode": job.get("mode"),
        "log": job.get("log", [])[-50:],  # last 50 log entries
        "iteration_count": len(job.get("iteration_log", [])),
        "baseline_rms": job.get("baseline_rms"),
        "optimized_rms": job.get("optimized_rms"),
        "best_params": job.get("best_params"),
        "pareto_front": job.get("pareto_front"),
        "error": job.get("error"),
    }


@app.get("/jobs/{job_id}/iterations")
def get_iterations(job_id: str):
    if job_id not in jobs:
        raise HTTPException(404, "Job not found")
    return {"iterations": jobs[job_id].get("iteration_log", [])}


@app.get("/jobs")
def list_jobs():
    return [{"job_id": jid, "status": j["status"], "mode": j["mode"],
             "created_at": j["created_at"]} for jid, j in jobs.items()]


@app.delete("/jobs/{job_id}")
def delete_job(job_id: str):
    if job_id not in jobs:
        raise HTTPException(404, "Job not found")
    del jobs[job_id]
    return {"deleted": job_id}


@app.get("/default_config")
def default_config():
    """Return the default vehicle configuration (without CSV paths)."""
    return {
        "cfg": {
            "s1": 0.6277, "s2": 0.6305,
            "WT1": 0.814, "WT2": 1.047, "WT3": 1.047,
            "m_c": 862.0, "I_xxc": 516.6, "I_yyc": 1045.0,
            "M_1f": 600.0, "M_2": 1075.0, "M_3": 840.0,
            "I_xx1": 650.0, "I_xx2": 1200.0, "I_xx3": 1100.0,
            "S_tf2": 1.043, "S_tf3": 1.043, "S_f": 0.814,
            "C_cfl": 5035.0, "C_cfr": 5035.0, "C_crl": 3400.0, "C_crr": 3400.0,
            "K_cfl": 49050.0, "K_cfr": 49050.0, "K_crl": 24525.0, "K_crr": 24525.0,
            "C_2": 2000.0, "C_3": 2000.0,
            "L_DL2": 0.6211, "L_DR2": 0.6211,
            "L_DL3": 0.6251, "L_DR3": 0.6251,
            "beta_L2": 0.1693, "beta_R2": 0.1693,
            "beta_L3": 0.17453, "beta_R3": 0.17453,
            "a": 0.9, "b": 1.080,
            "l_cfcg": 0.871, "l_crcg": 1.087, "hcp": 0.1,
            "lf": 5.05, "L12": 0.54, "L23": 1.96,
            "l_cf": 6.458, "l_cr": 4.5,
            "m_s": 22485.0, "I_syy": 103787.0, "I_sxx": 8598.0, "I_sxy": 763.0,
            "hs": 0.68,
            "K_f": 474257.0, "C_f": 15000.0, "K_2": 1077620.0, "K_3": 1077620.0,
            "g": 9.81,
            "cs_minus": 0.3, "asym_ratio": 3.0, "gamma_c": 0.12, "gamma_r": 0.09,
            "baum_omega": 10.0, "baum_zeta": 1.0,
        },
        "bounds": {
            "K_f":       [210995.44,  843981.76],
            "C_f":       [10074.274068, 40297.09627],
            "K_2":       [319253.848, 6464890.422],
            "K_3":       [357114.712,  7231572.918],
            "cs_minus":  [0.2,  0.4],
            "asym_ratio":[2.3,  4.0],
            "gamma_c":   [0.08, 0.16],
            "gamma_r":   [0.08, 0.10],
        },
        "param_keys": ["K_f","C_f","K_2","K_3","cs_minus","asym_ratio","gamma_c","gamma_r"],
        "axle_csv_keys": {
            "axlefront_left_csv":  "Displacement_1_FA_LH.csv",
            "axlefront_right_csv": "Displacement_2_FA_RH.csv",
            "axlerear1_left_csv":  "Displacement_3_RA1_LH.csv",
            "axlerear1_right_csv": "Displacement_4_RA1_RH.csv",
            "axlerear2_left_csv":  "Displacement_5_RA2_LH.csv",
            "axlerear2_right_csv": "Displacement_6_RA2_RH.csv",
        }
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=False)
