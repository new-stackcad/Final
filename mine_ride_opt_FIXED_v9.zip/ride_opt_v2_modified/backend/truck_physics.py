"""
truck_physics.py
================
Exact physics from the working standalone NSGA-II script.
Used by solver.py instead of the generic ODE runner.
"""
from __future__ import annotations
import time
import numpy as np
import pandas as pd
from dataclasses import dataclass
from numpy.linalg import solve as lin_solve
from scipy.integrate import solve_ivp
from scipy.optimize import least_squares
from typing import Callable, Dict, Tuple


# ── State indices ─────────────────────────────────────────────────────────
STATE_NAMES = ["z_c", "th_c", "ph_c", "z_s", "th_s", "ph_s"]
ZC, THC, PHC, ZS, THS, PHS = range(6)

DT = 0.001


# ── Two-stage asymmetric damper ───────────────────────────────────────────
@dataclass
class TwoStageAsymmetricDamper:
    cs_minus: float
    asym_ratio: float
    gamma_c: float
    gamma_r: float
    alpha_c: float = -0.05
    alpha_r: float =  0.13

    def force(self, v_rel: float) -> float:
        c_plus = self.asym_ratio * self.cs_minus
        if v_rel < 0.0:
            if v_rel >= self.alpha_c:
                return self.cs_minus * v_rel
            return self.cs_minus * (self.alpha_c + self.gamma_c * (v_rel - self.alpha_c))
        else:
            if v_rel <= self.alpha_r:
                return c_plus * v_rel
            return c_plus * (self.alpha_r + self.gamma_r * (v_rel - self.alpha_r))


# ── Road signals ──────────────────────────────────────────────────────────
def _make_interp(x: np.ndarray, y: np.ndarray) -> Callable:
    x = np.asarray(x, float); y = np.asarray(y, float)
    def f(xq):
        xq   = np.asarray(xq, float)
        xq_c = np.clip(xq, x[0], x[-1])
        idx  = np.clip(np.searchsorted(x, xq_c) - 1, 0, len(x) - 2)
        w    = (xq_c - x[idx]) / np.maximum(x[idx+1] - x[idx], 1e-12)
        return y[idx] * (1 - w) + y[idx+1] * w
    return f


@dataclass
class RoadSignals:
    f1L: Callable; f1R: Callable
    f2L: Callable; f2R: Callable
    f3L: Callable; f3R: Callable

    def axle_inputs(self, t, cfg):
        zr1L, zr1R = self.f1L(t), self.f1R(t)
        zr2L, zr2R = self.f2L(t), self.f2R(t)
        zr3L, zr3R = self.f3L(t), self.f3R(t)
        z1f  = 0.5*(zr1L+zr1R);  z2 = 0.5*(zr2L+zr2R);  z3 = 0.5*(zr3L+zr3R)
        ph_f = (zr1L-zr1R)/cfg["WT1"]
        ph2  = (zr2L-zr2R)/cfg["WT2"]
        ph3  = (zr3L-zr3R)/cfg["WT3"]
        return float(z1f), float(ph_f), float(z2), float(ph2), float(z3), float(ph3)

    def axle_input_rates(self, t, cfg, dt=DT):
        p = self.axle_inputs(t+dt, cfg)
        m = self.axle_inputs(t-dt, cfg)
        return tuple((a-b)/(2*dt) for a, b in zip(p, m))


def build_truck_road_signals(cfg: Dict) -> RoadSignals:
    import pandas as _pd
    def _load(path):
        df = _pd.read_csv(path, skiprows=2, header=None)
        t  = _pd.to_numeric(df.iloc[:,0], errors="coerce").values
        z  = _pd.to_numeric(df.iloc[:,1], errors="coerce").values
        mask = np.isfinite(t) & np.isfinite(z)
        return t[mask].astype(float), z[mask].astype(float)

    t1L,z1L = _load(cfg["axlefront_left_csv"])
    t1R,z1R = _load(cfg["axlefront_right_csv"])
    t2L,z2L = _load(cfg["axlerear1_left_csv"])
    t2R,z2R = _load(cfg["axlerear1_right_csv"])
    t3L,z3L = _load(cfg["axlerear2_left_csv"])
    t3R,z3R = _load(cfg["axlerear2_right_csv"])
    return RoadSignals(
        _make_interp(t1L,z1L), _make_interp(t1R,z1R),
        _make_interp(t2L,z2L), _make_interp(t2R,z2R),
        _make_interp(t3L,z3L), _make_interp(t3R,z3R),
    )


# ── Geometry constraints ──────────────────────────────────────────────────
def geom_constraints(q, t, cfg, road: RoadSignals):
    z_s, th_s, ph_s = q[ZS], q[THS], q[PHS]
    _, _, z2, ph2, z3, ph3 = road.axle_inputs(t, cfg)
    l2 = cfg["L12"];  l3 = cfg["L12"] + cfg["L23"]
    S2, S3 = cfg["S_tf2"], cfg["S_tf3"]
    s1, s2 = cfg["s1"], cfg["s2"]
    bL2, bL3 = cfg["beta_L2"], cfg["beta_L3"]

    g1 = z_s + l2*th_s + S2*ph_s - s1*np.sin(bL2-th_s) - (z2 + 0.5*cfg["WT2"]*ph2)
    g2 = z_s + l3*th_s + S3*ph_s - s2*np.sin(bL3-th_s) - (z3 + 0.5*cfg["WT3"]*ph3)

    gq = np.array([g1, g2], float)
    G  = np.zeros((2, 6), float)
    G[0, ZS]=1.0; G[0, THS]=l2+s1*np.cos(bL2-th_s); G[0, PHS]=S2
    G[1, ZS]=1.0; G[1, THS]=l3+s2*np.cos(bL3-th_s); G[1, PHS]=S3
    return gq, G


# ── Mass matrix + force vector ────────────────────────────────────────────
def build_M_R(q, v, t, cfg, road: RoadSignals):
    z_c,th_c,ph_c,z_s,th_s,ph_s       = q
    dz_c,dth_c,dph_c,dz_s,dth_s,dph_s = v

    z1f,ph_f,z2,ph2,z3,ph3           = road.axle_inputs(t, cfg)
    dz1f,dph_f,dz2,dph2,dz3,dph3     = road.axle_input_rates(t, cfg)

    phi_NRS2 = (cfg["beta_L2"]*cfg["L_DL2"]-cfg["beta_R2"]*cfg["L_DR2"]) / max(cfg["S_tf2"],1e-6)
    phi_NRS3 = (cfg["beta_L3"]*cfg["L_DL3"]-cfg["beta_R3"]*cfg["L_DR3"]) / max(cfg["S_tf3"],1e-6)

    m_c,I_xxc,I_yyc = cfg["m_c"],cfg["I_xxc"],cfg["I_yyc"]
    m_s,I_sxx,I_syy,I_sxy = cfg["m_s"],cfg["I_sxx"],cfg["I_syy"],cfg["I_sxy"]
    S1,S2,S3 = cfg["S_f"],cfg["S_tf2"],cfg["S_tf3"]
    a,b      = cfg["a"],cfg["b"]
    hs,g     = cfg["hs"],cfg["g"]
    l_cfcg,l_crcg,l_cf,l_cr = cfg["l_cfcg"],cfg["l_crcg"],cfg["l_cf"],cfg["l_cr"]
    lf = cfg["lf"]; hcp = cfg["hcp"]
    l2 = cfg["L12"]; l3 = cfg["L12"]+cfg["L23"]
    bL2,bR2,bL3,bR3 = cfg["beta_L2"],cfg["beta_R2"],cfg["beta_L3"],cfg["beta_R3"]
    L_DL2,L_DR2,L_DL3,L_DR3 = cfg["L_DL2"],cfg["L_DR2"],cfg["L_DL3"],cfg["L_DR3"]
    Kcfl,Kcfr,Kcrl,Kcrr = cfg["K_cfl"],cfg["K_cfr"],cfg["K_crl"],cfg["K_crr"]
    Ccfl,Ccfr,Ccrl,Ccrr = cfg["C_cfl"],cfg["C_cfr"],cfg["C_crl"],cfg["C_crr"]
    K_f,C_f = cfg["K_f"],cfg["C_f"]
    K_2,C_2 = cfg["K_2"],cfg["C_2"]
    K_3,C_3 = cfg["K_3"],cfg["C_3"]

    M = np.zeros((6,6))
    M[ZC,ZC]=m_c; M[THC,THC]=I_yyc; M[PHC,PHC]=I_xxc
    M[ZS,ZS]=m_s; M[THS,THS]=I_syy
    M[THS,PHS]=I_sxy; M[PHS,THS]=I_sxy
    M[PHS,PHS]=I_sxx+m_s*hs**2

    damp = TwoStageAsymmetricDamper(
        cs_minus=cfg["cs_minus"], asym_ratio=cfg["asym_ratio"],
        gamma_c=cfg["gamma_c"],   gamma_r=cfg["gamma_r"])
    v_f  = dz_s - lf*dth_s - dz1f
    F_df = C_f * damp.force(v_f)

    R = np.zeros(6)
    R[ZC] = (
        (Ccfl+Ccfr+Ccrl+Ccrr)*(dz_c-dz_s) + (Kcfl+Kcfr+Kcrl+Kcrr)*(z_c-z_s)
        - (Ccfl*l_cfcg+Ccfr*l_cfcg-Ccrl*l_crcg-Ccrr*l_crcg)*dth_c
        - (-Ccfl*l_cf-Ccfr*l_cf-Ccrl*l_cr-Ccrr*l_cr)*dth_s
        - (-Ccfl*b+Ccfr*a-Ccrl*b+Ccrr*a)*dph_c
        - (Ccfl*b-Ccfr*a+Ccrl*b-Ccrr*a)*dph_s
        - (Kcfl*l_cfcg+Kcfr*l_cfcg-Kcrl*l_crcg-Kcrr*l_crcg)*th_c
        - (-Kcfl*l_cf-Kcfr*l_cf-Kcrl*l_cr-Kcrr*l_cr)*th_s
        - (-Kcfl*b+Kcfr*a-Kcrl*b+Kcrr*a)*ph_c
        - (Kcfl*b-Kcfr*a+Kcrl*b-Kcrr*a)*ph_s)
    R[THC] = (
        -(Ccfl*l_cfcg+Ccfr*l_cfcg-Ccrl*l_crcg-Ccrr*l_crcg)*dz_c
        -(-Ccfl*l_cfcg-Ccfr*l_cfcg-Ccrl*l_crcg-Ccrr*l_crcg)*dz_s
        -(Kcfl*l_cfcg+Kcfr*l_cfcg-Kcrl*l_crcg-Kcrr*l_crcg)*z_c
        -(-Kcfl*l_cfcg-Kcfr*l_cfcg-Kcrl*l_crcg-Kcrr*l_crcg)*z_s
        -(-Ccfl*l_cfcg**2-Ccfr*l_cfcg**2-Ccrl*l_crcg**2-Ccrr*l_crcg**2)*dth_c
        -(Ccfl*l_cfcg*l_cf+Ccfr*l_cfcg*l_cf-Ccrl*l_crcg*l_cr-Ccrr*l_crcg*l_cr)*dth_s
        -(-Ccfl*l_cfcg*b+Ccfr*l_cfcg*a-Ccrl*l_crcg*b+Ccrr*l_crcg*a)*dph_c
        -(Ccfl*l_cfcg*b-Ccfr*l_cfcg*a+Ccrl*l_crcg*b-Ccrr*l_crcg*a)*dph_s
        -(-Kcfl*l_cfcg**2-Kcfr*l_cfcg**2-Kcrl*l_crcg**2-Kcrr*l_crcg**2+m_c*g*hcp)*th_c
        -(Kcfl*l_cfcg*l_cf+Kcfr*l_cfcg*l_cf-Kcrl*l_crcg*l_cr-Kcrr*l_crcg*l_cr)*th_s
        -(-Kcfl*l_cfcg*b+Kcfr*l_cfcg*a-Kcrl*l_crcg*b+Kcrr*l_crcg*a)*ph_c
        -(Kcfl*l_cfcg*b-Kcfr*l_cfcg*a+Kcrl*l_crcg*b-Kcrr*l_crcg*a)*ph_s)
    R[PHC] = -(
        (-Ccfl*b+Ccfr*a-Ccrl*b+Ccrr*a)*dz_c
        +(Ccfl*b-Ccfr*a+Ccrl*b-Ccrr*a)*dz_s
        +(-Ccfl*l_cfcg*b-Ccfr*l_cfcg*a+Ccrl*l_crcg*b+Ccrr*l_crcg*a)*dth_c
        +(Ccfl*l_cfcg*b+Ccfr*l_cfcg*a-Ccrl*l_crcg*b-Ccrr*l_crcg*a)*dth_s
        +(-Ccfl*b**2+Ccfr*a**2-Ccrl*b**2+Ccrr*a**2)*dph_c
        +(Ccfl*b**2-Ccfr*a**2+Ccrl*b**2-Ccrr*a**2)*dph_s
        +(-Kcfl*l_cfcg*b-Kcfr*l_cfcg*a+Kcrl*l_crcg*b+Kcrr*l_crcg*a)*th_c
        +(Kcfl*l_cfcg*b+Kcfr*l_cfcg*a-Kcrl*l_crcg*b-Kcrr*l_crcg*a)*th_s
        +(-Kcfl*b**2+Kcfr*a**2-Kcrl*b**2+Kcrr*a**2)*ph_c
        +(Kcfl*b**2-Kcfr*a**2+Kcrl*b**2-Kcrr*a**2)*ph_s)
    R[ZS] = (
        -(Ccfl+Ccfr+Ccrl+Ccrr)*dz_c
        -(-Ccfl*l_cfcg-Ccfr*l_cfcg+Ccrl*l_crcg+Ccrr*l_crcg)*dth_c
        -(-Ccfl-Ccfr-Ccrl-Ccrr)*dz_s
        -(Ccfl*l_cf+Ccfr*l_cf+Ccrl*l_cr+Ccrr*l_cr)*dth_s
        -(Kcfl+Kcfr+Kcrl+Kcrr)*z_c
        -(-Kcfl*l_cfcg-Kcfr*l_cfcg+Kcrl*l_crcg+Kcrr*l_crcg)*th_c
        -(-Kcfl-Kcfr-Kcrl-Kcrr)*z_s
        -(Kcfl*l_cf+Kcfr*l_cf+Kcrl*l_cr+Kcrr*l_cr)*th_s
        + K_f*(z_s-lf*th_s-z1f) + F_df
        + K_2*(z_s-z2-bL2*L_DL2-bR2*L_DR2+l2*th_s) + C_2*(dz_s-dz2+l2*dth_s)
        + K_3*(z_s-z3-bL3*L_DL3-bR3*L_DR3+l3*th_s) + C_3*(dz_s-dz3+l3*dth_s))
    R[THS] = (
        -(Ccfl*l_cfcg+Ccfr*l_cfcg-Ccrl*l_crcg-Ccrr*l_crcg)*dz_c
        -(-Ccfl*l_cfcg**2-Ccfr*l_cfcg**2-Ccrl*l_crcg**2-Ccrr*l_crcg**2)*dth_c
        -(-Ccfl*l_cf-Ccfr*l_cf-Ccrl*l_cr-Ccrr*l_cr)*dz_s
        -(Ccfl*l_cfcg*l_cf+Ccfr*l_cfcg*l_cf-Ccrl*l_crcg*l_cr-Ccrr*l_crcg*l_cr)*dth_s
        -(Kcfl*l_cf+Kcfr*l_cf+Kcrl*l_cr+Kcrr*l_cr)*z_c
        -(-Kcfl*l_cfcg*l_cf-Kcfr*l_cfcg*l_cf+Kcrl*l_crcg*l_cr+Kcrr*l_crcg*l_cr)*th_c
        -(-Kcfl*l_cf-Kcfr*l_cf-Kcrl*l_cr-Kcrr*l_cr)*z_s
        -(Kcfl*l_cf**2+Kcfr*l_cf**2+Kcrl*l_cr**2+Kcrr*l_cr**2)*th_s
        - lf*(K_f*(z_s-lf*th_s-z1f) + F_df)
        + l2*(K_2*(z_s-z2-bL2*L_DL2-bR2*L_DR2+l2*th_s)+C_2*(dz_s-dz2+l2*dth_s))
        + l3*(K_3*(z_s-z3-bL3*L_DL3-bR3*L_DR3+l3*th_s)+C_3*(dz_s-dz3+l3*dth_s)))
    k_tf=0.5*K_f*S1**2; C_tf=0.5*C_f*S1**2
    K_r1=0.5*K_2*S2**2; C_r1=0.5*C_2*S2**2
    K_r2=0.5*K_3*S3**2; C_r2=0.5*C_3*S3**2
    R[PHS] = -(
        m_s*g*hs*ph_s
        - k_tf*(ph_s-ph_f) - C_tf*(dph_s-dph_f)
        - K_r1*(ph_s-ph2-phi_NRS2) - C_r1*(dph_s-dph2)
        - K_r2*(ph_s-ph3-phi_NRS3) - C_r2*(dph_s-dph3))
    return M, R


# ── First-order RHS (exact copy from working script) ─────────────────────
def rhs_first_order(t, x, cfg, road: RoadSignals):
    q, v = x[:6], x[6:]
    M, R = build_M_R(q, v, t, cfg, road)
    gq, G = geom_constraints(q, t, cfg, road)
    w, zeta = cfg["baum_omega"], cfg["baum_zeta"]
    gamma = w**2 * gq + 2*zeta*w * (G @ v)
    nc = G.shape[0]
    A = np.zeros((6+nc, 6+nc))
    b_vec = np.zeros(6+nc)
    A[:6,:6]=M; A[:6,6:]=G.T; A[6:,:6]=G
    b_vec[:6]=-R; b_vec[6:]=-gamma
    sol = lin_solve(A, b_vec)
    xdot = np.zeros_like(x)
    xdot[:6] = v; xdot[6:] = sol[:6]
    return xdot


# ── Static equilibrium (exact copy from working script) ──────────────────
def truck_static_equilibrium(cfg: Dict, road: RoadSignals) -> np.ndarray:
    t0 = 0.0
    def F(y):
        q, lam = y[:6], y[6:]
        M, R   = build_M_R(q, np.zeros(6), t0, cfg, road)
        gq, G  = geom_constraints(q, t0, cfg, road)
        return np.hstack([R + G.T @ lam, 1e3*gq])

    lsq = least_squares(F, np.zeros(8), method="trf", loss="soft_l1",
                        xtol=1e-12, ftol=1e-12, gtol=1e-12, max_nfev=800)
    if lsq.success:
        return np.hstack([lsq.x[:6], np.zeros(6)])

    # Fallback: dynamic relaxation
    cfg_r = dict(cfg)
    for k in ["C_2","C_3","C_cfl","C_cfr","C_crl","C_crr"]:
        cfg_r[k] *= 20
    sol = solve_ivp(lambda t,x: rhs_first_order(t,x,cfg_r,road),
                    (0.0,3.0), np.zeros(12), method="Radau", rtol=1e-7, atol=1e-9)
    return np.hstack([sol.y[:6,-1], np.zeros(6)])


# ── Main run function (called by solver.py) ───────────────────────────────
def truck_run_one_case(params: Dict, cfg_base: Dict, road: RoadSignals,
                       t_eval: np.ndarray, log_cb=None) -> pd.DataFrame:
    def _log(m):
        if log_cb: log_cb(m)

    cfg = {**cfg_base, **params}
    _log("Computing static equilibrium …")
    x0 = truck_static_equilibrium(cfg, road)
    _log(f"x0 = {np.round(x0[:6],4).tolist()}")

    t0, tf = float(t_eval[0]), float(t_eval[-1])
    _log(f"Integrating (12 states, Radau) T=[{t0:.2f}, {tf:.2f}] s")
    wall = time.time()

    sol = solve_ivp(
        fun=lambda t, x: rhs_first_order(t, x, cfg, road),
        t_span=(t0, tf),
        y0=x0,
        t_eval=t_eval,
        method="Radau",
        max_step=0.01,
        rtol=1e-6,
        atol=1e-8,
    )
    elapsed = time.time() - wall
    _log(f"Done — success={sol.success}  nfev={sol.nfev}  wall={elapsed:.1f}s")

    if sol.status != 0 or not np.all(np.isfinite(sol.y)):
        raise RuntimeError(f"ODE failed: {sol.message}")

    rows = []
    for i, t in enumerate(sol.t):
        x  = sol.y[:, i]
        q  = x[:6]; v = x[6:]
        qdd = rhs_first_order(t, x, cfg, road)[6:]
        row = {"t": t}
        for j, name in enumerate(STATE_NAMES):
            row[name] = q[j]; row[f"qd_{name}"] = v[j]; row[f"qdd_{name}"] = qdd[j]
        rows.append(row)
    return pd.DataFrame(rows)


# ── RMS computation (exact copy from working script) ──────────────────────
def truck_compute_rms(df: pd.DataFrame, t_ignore: float = 0.5, hcp: float = 0.1):
    mask = df["t"] >= t_ignore
    az  = df.loc[mask, "qdd_z_c"].values
    ax_ = -hcp * df.loc[mask, "qdd_th_c"].values
    ay  =  hcp * df.loc[mask, "qdd_ph_c"].values
    return {
        "rms_z":     float(np.sqrt(np.mean(az**2))),
        "rms_x":     float(np.sqrt(np.mean(ax_**2))),
        "rms_y":     float(np.sqrt(np.mean(ay**2))),
        "rms_total": float(np.sqrt(np.mean(az**2 + ax_**2 + ay**2))),
    }
